<?php $__env->startSection('title', 'Admin Panel'); ?>
<?php $__env->startSection('head', 'Admin Panel'); ?>

<?php $__env->startSection('content'); ?>
  <div class="container">
    <?php echo $__env->make('partials.msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.errormsg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row mb-4">
        <div class="col-md-6 my-2">
            <h4><i class="fa fa-users"></i> Latest users registered</h4>
                
                    <table class="table table-primary">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Registered</th>
                            </tr>
                        </thead>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->created_at->diffForHumans()); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                      
                    </table>
        </div>

        <div class="col-md-6 my-2">
            <h4><i class="fa fa-desktop"></i> Latest records</h4>
                
                    <table class="table table-primary">
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>Added</th>
                            </tr>
                        </thead>
                        <?php $__empty_1 = true; $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($link->title); ?></td>
                                <td><?php echo e($link->created_at->diffForHumans()); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="2">No record found.</td>
                            </tr>
                        <?php endif; ?>                        
                    </table>
        </div>

        <div class="col-md-6 my-2">
            <h4><i class="fa fa-cubes"></i> Categories</h4>
                
                    <table class="table table-primary">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Modified</th>
                            </tr>
                        </thead>
                        <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($category->name); ?> <span class="badge-light badge-pill"><?php echo e($category->links()->count()); ?></span></td>
                                <td><?php echo e($category->created_at->diffForHumans()); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="2">No category is created yet.</td>
                        </tr>
                        <?php endif; ?>                        
                    </table>
                
        </div>
        
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.adminmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppi\htdocs\LinkDir\resources\views/admin/admin_panel.blade.php ENDPATH**/ ?>