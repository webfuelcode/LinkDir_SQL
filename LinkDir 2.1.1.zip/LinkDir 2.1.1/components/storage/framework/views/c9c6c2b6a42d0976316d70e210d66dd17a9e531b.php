

<?php $__env->startSection('title', 'Categories'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-9 order-md-last">
                <div class="pb-2">
                    <h2>
                        Lists
                    </h2>
                    
                </div>
                <div class="">
                    <?php $__empty_1 = true; $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="card bg-light border-0 mb-2">                                
                                <div class="card-body row">
                                    <div class="col-2">
                                        <?php if($link->icon): ?>
                                            <img src="<?php echo e(asset('images')); ?>/icon/<?php echo e($link->icon); ?>" alt="" class="img-fluid rounded">
                                        <?php else: ?>
                                            <img src="<?php echo e(asset('images')); ?>/default/icon.png" alt="" class="img-fluid rounded">
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-10">
                                        <h5><i class="fa fa-hand-o-right"></i> <a href="<?php echo e(route('link.show', $link->slug)); ?>"><?php echo e($link->title); ?></a></h5>
                                        <p class="card-text">
                                            <?php echo e(substr($link->description, 0, 150)); ?>

                                        </p>
                                    </div>
                                </div>                              
                            </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                Currently, there are no records.
                            
                    <?php endif; ?>
                    
                </div>
                <?php echo e($links->links()); ?>

            </div>
            <div class="col-md-3">
                <h2 class="pb-2">
                    Categories
                </h2>
                
                <ul class="list-group">
                    <a class="list-group-item <?php echo e(Request::is('link') ? 'active' : ''); ?>" href="<?php echo e(route('link.index')); ?>">View all</a>
                    <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            
                        <a class="list-group-item d-flex justify-content-between align-item-center <?php echo e(Request::is('category/' . $category->slug) ? 'active' : ''); ?>" href="<?php echo e(route('category.show', $category->name)); ?>"><?php echo e($category->name); ?> <span class="badge badge-light"><?php echo e($category->links->count()); ?></span></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    There are no categories yet.
                        
                    <?php endif; ?>
                </ul>

                <div class="p-4">
                    <?php echo $admin->sideads; ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppi\htdocs\LinkDir\resources\views/links/category.blade.php ENDPATH**/ ?>