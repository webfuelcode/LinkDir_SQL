<!-- Modal for edit button on review header -->
<div class="modal fade" id="editcm<?php echo e($rated->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
      <div class="modal-content">
          <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Edit comment</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
              </button>
          </div>          
          
          <form action="<?php echo e(route('comment.update', $rated->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
              <div class="modal-body form-group">
                
                <div class="star-edit">
                    <?php for($i = 5; $i > 0; $i--): ?>
                        <?php if($i > $rated->stars): ?>
                          <input type="radio" name="stars" id="r-<?php echo e($i); ?>" value="<?php echo e($i); ?>">
                          <label for="r-<?php echo e($i); ?>" class="fa fa-star"><?php echo e($i); ?></label>
                        <?php else: ?>
                          <input type="radio" name="stars" id="r<?php echo e($i); ?>" value="<?php echo e($i); ?>" <?php if($i == $rated->stars): ?>
                              checked
                          <?php endif; ?>>
                          <label for="r-<?php echo e($i); ?>" class="fa fa-star"><?php echo e($i); ?></label>
                        <?php endif; ?>
                    <?php endfor; ?>
                  
                  
                    <header></header>
                    <input type="hidden" name="link_id" value="<?php echo e($link->id); ?>">
                    <textarea name="body" id="" cols="30" rows="10" class="form-control"><?php echo e($rated->body); ?></textarea>
                </div>
              </div>
              <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                  <button type="submit" class="btn btn-primary">Save changes</button>
              </div>
          </form>                              
                  
          
      </div>
  </div>
</div><?php /**PATH C:\xamppi\htdocs\LinkDir\resources\views/links/modal/comment_edit.blade.php ENDPATH**/ ?>