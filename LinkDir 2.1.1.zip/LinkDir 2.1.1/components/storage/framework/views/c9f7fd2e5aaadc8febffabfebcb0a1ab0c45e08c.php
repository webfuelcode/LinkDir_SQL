

<?php $__env->startSection('title', 'Support'); ?>
<?php $__env->startSection('head', 'Support'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        
        <div class="card-body">
            <h4 class="card-title">Thanks for the interest!</h4>
            <p></p>
            <p>Hope, you are doing good with <span class="text-success">LinkDir</span>, a simple and useful link directory.</p>
            <p>Please support to continue this script. Anything will help a lot.</p>
            <div class="text-center">
                <p><i class="fa fa-dollar fa-2x"></i> <i class="fa fa-btc fa-2x"></i></p>
                <p><a class="btn btn-success" href="http://sendmebux.wall-spot.com" target="_blank" rel="noopener noreferrer">Donate</a></p>
            </div>
        </div>
    </div>

    <div class="row py-4 px-5 justify-content-between text-light">
        <div class="col-md-6">
            <div class="card bg-info text-center p-4">
                Hostinger provides low cost shared hosting. Get free SSL and domain name. <a class="btn btn-light" href="http://www.wall-spot.com/likes/hostinger/" target="_blank" rel="noopener noreferrer">Get it here</a>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card bg-info text-center p-4">
                Hostgator a pretty popular for large project. Occasionally they have offers. <a class="btn btn-light" href="http://www.wall-spot.com/likes/hostgator/" target="_blank" rel="noopener noreferrer">Get it here</a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.adminmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppi\htdocs\LinkDir\resources\views/admin/supports.blade.php ENDPATH**/ ?>