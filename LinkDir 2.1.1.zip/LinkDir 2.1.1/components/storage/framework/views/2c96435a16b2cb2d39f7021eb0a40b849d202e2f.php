<div class="card my-3">
  <div class="card-header d-flex justify-content-between">
    <div>
      <?php for($i = 0; $i < 5; $i++): ?>
          <?php if($displaystars > $i): ?>
            
              <?php if(is_float($link->star) && $displaystars == $i+1 && $displaystars > $link->star): ?>
                  <i class="fa fa-star-half-o text-warning"></i>
              <?php else: ?>
                  <i class="fa fa-star text-warning"></i>
              <?php endif; ?>
          <?php else: ?>
              <i class="fa fa-star"></i>
          <?php endif; ?>
      <?php endfor; ?>
      <?php echo e($link->star); ?>

      (Based on <?php echo e($ratecount); ?> ratings)
    </div>

    <?php if(auth()->guard()->check()): ?>
      <?php if($rated): ?>
        <a href="#" data-toggle="modal" data-target="#editcm<?php echo e($rated->id); ?>">Edit review</a>
        <?php echo $__env->make('links.modal.comment_editrated', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php else: ?>
        <a href="#" data-toggle="modal" data-target="#postcm">Post review</a>
      <?php endif; ?>
      <?php echo $__env->make('links.modal.comment_post', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
  </div>
  <div class="card-body">
    <div class="row">
      <div class="col-md-3">
        <i class="fa fa-star text-warning"></i>
        <i class="fa fa-star text-warning"></i>
        <i class="fa fa-star text-warning"></i>
        <i class="fa fa-star text-warning"></i>
        <i class="fa fa-star text-warning"></i>
      </div>
      <div class="col-md-7">
        <div class="progress my-2">
          <div class="progress-bar bg-success" role="progressbar" aria-valuenow="<?php echo e($s5); ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo e($s5); ?>%"></div>
        </div>
      </div>
      <div class="col-md-2">
        <?php echo e($c5); ?> vote
      </div>
    </div>
    <div class="row">
      <div class="col-md-3">
        <i class="fa fa-star text-warning"></i>
        <i class="fa fa-star text-warning"></i>
        <i class="fa fa-star text-warning"></i>
        <i class="fa fa-star text-warning"></i>
        <i class="fa fa-star"></i>
      </div>
      <div class="col-md-7">
        <div class="progress my-2">
          <div class="progress-bar bg-success" role="progressbar" aria-valuenow="<?php echo e($s4); ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo e($s4); ?>%"></div>
        </div>
      </div>
      <div class="col-md-2">
        <?php echo e($c4); ?> vote
      </div>
    </div>
    <div class="row">
      <div class="col-md-3">
        <i class="fa fa-star text-warning"></i>
        <i class="fa fa-star text-warning"></i>
        <i class="fa fa-star text-warning"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
      </div>
      <div class="col-md-7">
        <div class="progress my-2">
          <div class="progress-bar" role="progressbar" aria-valuenow="<?php echo e($s3); ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo e($s3); ?>%"></div>
        </div>
      </div>
      <div class="col-md-2">
        <?php echo e($c3); ?> vote
      </div>
    </div>
    <div class="row">
      <div class="col-md-3">
        <i class="fa fa-star text-warning"></i>
        <i class="fa fa-star text-warning"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
      </div>
      <div class="col-md-7">
        <div class="progress my-2">
          <div class="progress-bar bg-danger" role="progressbar" aria-valuenow="<?php echo e($s2); ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo e($s2); ?>%"></div>
        </div>
      </div>
      <div class="col-md-2">
        <?php echo e($c2); ?> vote
      </div>
    </div>
    <div class="row">
      <div class="col-md-3">
        <i class="fa fa-star text-warning"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
        <i class="fa fa-star"></i>
      </div>
      <div class="col-md-7">
        <div class="progress my-2">
          <div class="progress-bar bg-danger" role="progressbar" aria-valuenow="<?php echo e($s1); ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo e($s1); ?>%"></div>
        </div>
      </div>
      <div class="col-md-2">
        <?php echo e($c1); ?> vote
      </div>
    </div>
  </div>
</div>

<div class="card">
  <h6 class="card-header bg-info text-white">
    Member's review
  </h6>

  <?php $__empty_1 = true; $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
  <div class="card bg-light <?php echo e($loop->last ? '' : 'mb-1'); ?> border-0">
    <div class="card-body">
      <div class="row">
        <div class="col-md-3">
            <div>
              <a href="<?php echo e(route('users.show', $comment->user->name)); ?>"><?php echo e($comment->user->name); ?></a>
            </div>
            

            <?php for($i = 0; $i < 5; $i++): ?>
            <?php if(round($comment->stars) > $i): ?>
              
                <?php if(is_float($comment->stars) && round($comment->stars) == $i+1): ?>
                    <i class="fa fa-star-half-o text-warning"></i>
                <?php else: ?>
                    <i class="fa fa-star text-warning"></i>
                <?php endif; ?>
            <?php else: ?>
                <i class="fa fa-star"></i>
            <?php endif; ?>
        <?php endfor; ?>
        </div>
        <div class="col-md-9">
            <div><?php echo e($comment->body); ?></div>
            <div class="d-flex align-items-center">
              <small>
                <?php if($comment->created_at == $comment->updated_at): ?>
                  <strong>Posted:</strong> <?php echo e($comment->created_at->diffForHumans()); ?>

                <?php else: ?>
                  <strong>Updated:</strong> <?php echo e($comment->updated_at->diffForHumans()); ?>

                <?php endif; ?>
              </small>
              <?php if(auth()->guard()->check()): ?>
                <?php if(Auth::id() == $comment->user_id): ?>
                  <button type="submit" class="btn btn-success btn-sm badge m-1" data-toggle="modal" data-target="#editcm<?php echo e($comment->id); ?>">Edit</button>
                  <button type="submit" class="btn btn-danger btn-sm badge m-1" data-toggle="modal" data-target="#deletecm<?php echo e($comment->id); ?>">Delete</button>

                  <?php echo $__env->make('links.modal.comment_edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                  <?php echo $__env->make('links.modal.comment_delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>
              <?php endif; ?>
          </div>
        </div>
      </div>
    </div>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <div class="text-info p-3">No ratings has recorded yet. Be the first to rate it.</div>
  <?php endif; ?>
</div>

<div class="mt-1">
  <?php echo e($comments->links()); ?>

</div><?php /**PATH C:\xamppi\htdocs\LinkDir\resources\views/partials/star_comments.blade.php ENDPATH**/ ?>