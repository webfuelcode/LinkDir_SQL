@if (session('message'))
    <div class="alert alert-success">
        {{ session('message') }}
    </div>        
@endif

<script>
    window.setTimeout(function() {
    $(".alert-success").fadeTo(500, 0).slideUp(500, function(){
        $(this).remove(); 
    });
}, 5000);
</script>