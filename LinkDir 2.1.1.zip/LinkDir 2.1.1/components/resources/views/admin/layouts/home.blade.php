<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="title_left">
        <h3>Fixed Footer <small> Just add class <strong>footer_fixed</strong></small></h3>
        @forelse ($categories as $category)
            {{ $category->name }}
        @empty
            There is no category yet.
        @endforelse
      </div>
    </div>
  </div>
</div>