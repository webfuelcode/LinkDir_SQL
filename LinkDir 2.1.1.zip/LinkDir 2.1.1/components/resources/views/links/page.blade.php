@extends('layouts.app')

@section('title', $page->title)

@section('content')
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <h3>{{ $page->title }}</h3>
                <p>{!! nl2br($page->description) !!}</p>
            </div>
        </div>
    </div>
@endsection