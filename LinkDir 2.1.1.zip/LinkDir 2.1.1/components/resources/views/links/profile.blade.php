@extends('layouts.app')

@section('title')
    {{$user->name}}'s posts
@endsection

@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                {!! $admin->leaderads !!}
                @forelse ($user->links as $item)
                    @include('partials.item_list')
                @empty
                    <div class="card bg-warning">
                        <div class="card-body">
                            No records are here.
                        </div>
                    </div>
                @endforelse
            </div>
            <div class="col-md-4">
                <div class="px-4">
                    {!! $admin->sideads !!}
                </div>
            </div>
        </div>
        
    </div>
@endsection