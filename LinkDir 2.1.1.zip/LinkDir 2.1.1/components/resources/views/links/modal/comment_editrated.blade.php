<!-- Modal for edit button on review header -->
<div class="modal fade" id="editcm{{$rated->id}}" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
      <div class="modal-content">
          <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Update</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
              </button>
          </div>          
          
          <form action="{{route('comment.update', $rated->id)}}" method="POST">
            @csrf
            @method('PUT')
              <div class="modal-body form-group">
                
                <fieldset class="rating p-2">
                    @for ($i = 5; $i > 0; $i--)
                        @if ($i > $rated->stars)
                          <input type="radio" id="star{{$i}}" name="stars" value="{{$i}}" />
                          <label class = "full" for="star{{$i}}" title="{{$i}} stars"></label>
                        @else
                          <input type="radio" id="star{{$i}}" name="stars" value="{{$i}}" @if ($i == $rated->stars) checked @endif />
                          <label class = "full" for="star{{$i}}" title="{{$i}} stars"></label>
                        @endif
                    @endfor
                </fieldset>

                <input type="hidden" name="link_id" value="{{$link->id}}">
                <textarea name="body" rows="7" class="form-control">{{$rated->body}}</textarea>
              </div>
              <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                  <button type="submit" class="btn btn-primary">Save changes</button>
              </div>
          </form>                              
                  
          {{-- </form> --}}
      </div>
  </div>
</div>