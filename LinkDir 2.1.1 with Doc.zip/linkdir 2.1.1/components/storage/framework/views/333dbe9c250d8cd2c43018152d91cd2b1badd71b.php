

<?php $__env->startSection('title', $link->title); ?>
<?php $__env->startSection('linkrel'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/star-comment.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/stars.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('headad'); ?>
    <div class="py-2 text-center bg-light">
        <?php echo $admin->leaderads; ?>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        
        <?php echo $__env->make('partials.msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        

        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <h4 class="card-header bg-light">
                        <?php echo e($link->title); ?>

                    </h4>
                    <div class="card-body">
                        <p class="card-text">
                            <?php echo nl2br($link->description); ?>

                        </p>
                        
                        <div class="card-text">
                            <div></p><strong>Website:</strong> <a href="<?php echo e($link->url); ?>" target="_blank"><?php echo e($link->url); ?></a></div>
                            <div><strong>Phone No.:</strong> <?php echo e($link->phone); ?></div>
                            <div><strong>Email:</strong> <?php echo e($link->email); ?></div>
                            <div><strong>Address:</strong> <?php echo e($link->address); ?></div>
                        </div>
                        <div class="card-link">
                            <strong>In category:</strong> <a href="<?php echo e(route('category.show', $link->category->name ?? 'Un')); ?>"><?php echo e($link->category->name ?? 'Uncategorized'); ?></a>
                            <strong>Page views:</strong> <?php echo e($link->views); ?>

                        </div>
                    </div>
                </div>

                
                <?php echo $__env->make('partials.star_comments', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body pt-4">
                        <?php if($link->icon): ?>
                            <img src="<?php echo e(asset('images')); ?>/icon/<?php echo e($link->icon); ?>" alt="" class="img-fluid rounded">
                        <?php else: ?>
                            <img src="<?php echo e(asset('images')); ?>/default/icon.png" alt="" class="img-fluid rounded">
                        <?php endif; ?>
                        
                        <ul class="list-unstyled mb-0 mt-2">
                            <li><strong>Website:</strong> <?php echo e($link->url); ?></li>
                        </ul>
                    </div>
                    <?php if(auth()->guard()->check()): ?>
                        <?php if(auth()->user()->id == $link->user_id || auth()->user()->type == 'Owner' || auth()->user()->type == 'Admin'): ?>
                            
                        
                        <div class="card-footer">
                            
                            <div class="actions form-inline">
                                <a href="<?php echo e(route('link.edit', $link->slug)); ?>" class="btn btn-success btn-sm badge form-group m-1">Edit</a>

                                <button type="submit" class="btn btn-danger badge m-1" data-toggle="modal" data-target="#delete<?php echo e($link->id); ?>">Delete</button>
                                <?php echo $__env->make('links.modal.post_delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                
                            </div>
                            
                        </div>
                        
                        <?php endif; ?>
                        <?php endif; ?>

                </div>
                <div class="p-4">
                    <?php echo $admin->sideads; ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppi\htdocs\LinkDir\resources\views/links/single.blade.php ENDPATH**/ ?>