<!-- Modal for edit button on review header -->
<div class="modal fade" id="editcm<?php echo e($rated->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
      <div class="modal-content">
          <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Update</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
              </button>
          </div>          
          
          <form action="<?php echo e(route('comment.update', $rated->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
              <div class="modal-body form-group">
                
                <fieldset class="rating p-2">
                    <?php for($i = 5; $i > 0; $i--): ?>
                        <?php if($i > $rated->stars): ?>
                          <input type="radio" id="star<?php echo e($i); ?>" name="stars" value="<?php echo e($i); ?>" />
                          <label class = "full" for="star<?php echo e($i); ?>" title="<?php echo e($i); ?> stars"></label>
                        <?php else: ?>
                          <input type="radio" id="star<?php echo e($i); ?>" name="stars" value="<?php echo e($i); ?>" <?php if($i == $rated->stars): ?> checked <?php endif; ?> />
                          <label class = "full" for="star<?php echo e($i); ?>" title="<?php echo e($i); ?> stars"></label>
                        <?php endif; ?>
                    <?php endfor; ?>
                </fieldset>

                <input type="hidden" name="link_id" value="<?php echo e($link->id); ?>">
                <textarea name="body" rows="7" class="form-control"><?php echo e($rated->body); ?></textarea>
              </div>
              <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                  <button type="submit" class="btn btn-primary">Save changes</button>
              </div>
          </form>                              
                  
          
      </div>
  </div>
</div><?php /**PATH C:\xamppi\htdocs\LinkDir\resources\views/links/modal/comment_editrated.blade.php ENDPATH**/ ?>