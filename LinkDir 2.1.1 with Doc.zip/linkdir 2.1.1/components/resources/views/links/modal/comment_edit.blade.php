<!-- Modal for edit button on review header -->
<div class="modal fade" id="editcm{{$rated->id}}" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
      <div class="modal-content">
          <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Edit comment</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
              </button>
          </div>          
          
          <form action="{{route('comment.update', $rated->id)}}" method="POST">
            @csrf
            @method('PUT')
              <div class="modal-body form-group">
                
                <div class="star-edit">
                    @for ($i = 5; $i > 0; $i--)
                        @if ($i > $rated->stars)
                          <input type="radio" name="stars" id="r-{{$i}}" value="{{$i}}">
                          <label for="r-{{$i}}" class="fa fa-star">{{$i}}</label>
                        @else
                          <input type="radio" name="stars" id="r{{$i}}" value="{{$i}}" @if ($i == $rated->stars)
                              checked
                          @endif>
                          <label for="r-{{$i}}" class="fa fa-star">{{$i}}</label>
                        @endif
                    @endfor
                  
                  
                    <header></header>
                    <input type="hidden" name="link_id" value="{{$link->id}}">
                    <textarea name="body" id="" cols="30" rows="10" class="form-control">{{$rated->body}}</textarea>
                </div>
              </div>
              <div class="modal-footer">
                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                  <button type="submit" class="btn btn-primary">Save changes</button>
              </div>
          </form>                              
                  
          {{-- </form> --}}
      </div>
  </div>
</div>