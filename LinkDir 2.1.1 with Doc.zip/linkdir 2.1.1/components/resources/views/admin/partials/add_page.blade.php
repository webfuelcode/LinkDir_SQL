<!-- Modal for edit -->
<div class="modal fade" id="modaladd" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Add new page</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            
            
                <form action="{{route('page.store')}}" method="POST">
                        @csrf
                    <div class="modal-body row">
                        <div class="form-group col-md-8">
                            <label for="category_id">Page title: <small>Character required is minimum 4</small></label>
                            <input type="text" class="form-control" name="title" placeholder="Enter the title">
                        </div>                        
                        <div class="form-group col-md-4">
                            <label for="visibility">Visibility: <small class="text-warning">Show page in footer menu?</small></label>
                            <select name="visibility" class="custom-select">
                              <option selected="">Select a category</option>
                              
                                <option value="yes">Yes</option>
                                <option value="no">No</option>
                              
                            </select>
                        </div>
                        <div class="form-group col-md-12">
                            <label for="category_id">Description: <small>Character required is minimum 50</small></label>
                            <textarea class="form-control" name="description" rows="10" placeholder="Description here..."></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save changes</button>
                    </div>                              
                    
                </form>
            
            
        </div>
    </div>
</div>