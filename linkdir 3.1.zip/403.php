<?php
/**
 * linkdir - 403 Forbidden Page
 */

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

$pageTitle = 'Access Denied (403)';
require_once __DIR__ . '/includes/header.php';
?>

<div class="container my-5 py-5 text-center">
    <div class="row justify-content-center">
        <div class="col-md-7 col-lg-6">
            <i class="bi bi-shield-x text-danger opacity-75" style="font-size: 5rem;"></i>
            <h1 class="display-5 fw-bold text-dark mt-3">403 - Access Denied</h1>
            <p class="lead text-muted mb-4">
                You do not have administrative permission to access this protected area.
            </p>

            <div class="d-flex justify-content-center gap-3">
                <a href="/" class="btn btn-outline-secondary">Go to Homepage</a>
                <a href="/dashboard" class="btn btn-primary">My Dashboard</a>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
