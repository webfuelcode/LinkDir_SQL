<?php
/**
 * linkdir - Category Listings Page
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

$db = get_db();
$slug = trim($_GET['slug'] ?? '');

if ($slug === '') {
    header('Location: /businesses');
    exit;
}

// Fetch category details
$catStmt = $db->prepare("SELECT id, name, slug, description, icon FROM categories WHERE slug = ? AND status = 'active' LIMIT 1");
$catStmt->execute([$slug]);
$category = $catStmt->fetch();

if (!$category) {
    http_response_code(404);
    $pageTitle = 'Category Not Found';
    require_once __DIR__ . '/../404.php';
    exit;
}

// Fetch approved businesses in this category
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = ITEMS_PER_PAGE;
$offset = ($page - 1) * $perPage;

$countStmt = $db->prepare("SELECT COUNT(*) FROM businesses WHERE category_id = ? AND status = 'approved'");
$countStmt->execute([$category['id']]);
$totalItems = (int)$countStmt->fetchColumn();
$totalPages = ceil($totalItems / $perPage);

$bizStmt = $db->prepare("
    SELECT b.id, b.business_name, b.slug, b.logo, b.about, b.state, b.country, b.created_at,
           c.name as category_name, c.slug as category_slug,
           COALESCE(AVG(r.rating), 0) as avg_rating,
           COUNT(r.id) as review_count
    FROM businesses b
    JOIN categories c ON b.category_id = c.id
    LEFT JOIN reviews r ON r.business_id = b.id AND r.status = 'approved'
    WHERE b.category_id = ? AND b.status = 'approved'
    GROUP BY b.id, b.business_name, b.slug, b.logo, b.about, b.state, b.country, b.created_at, c.name, c.slug
    ORDER BY b.created_at DESC
    LIMIT {$perPage} OFFSET {$offset}
");
$bizStmt->execute([$category['id']]);
$businesses = $bizStmt->fetchAll();

$pageTitle = $category['name'] . ' - Business Listings';
$pageDescription = !empty($category['description']) ? $category['description'] : 'Browse top-rated ' . $category['name'] . ' on linkdir.';

require_once __DIR__ . '/../includes/header.php';
?>

<div class="bg-light border-bottom py-4 mb-4">
    <div class="container">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb small mb-2">
                <li class="breadcrumb-item"><a href="/" class="text-decoration-none">Home</a></li>
                <li class="breadcrumb-item"><a href="/businesses" class="text-decoration-none">Directory</a></li>
                <li class="breadcrumb-item active" aria-current="page"><?= e($category['name']) ?></li>
            </ol>
        </nav>
        <div class="d-flex align-items-center gap-3">
            <div class="fs-1 text-primary">
                <i class="bi <?= e($category['icon']) ?>"></i>
            </div>
            <div>
                <h1 class="h3 fw-bold mb-1"><?= e($category['name']) ?></h1>
                <?php if (!empty($category['description'])): ?>
                    <p class="text-muted small mb-0"><?= e($category['description']) ?></p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div class="container mb-5">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h5 class="fw-bold mb-0">
            <?= number_format($totalItems) ?> <?= ($totalItems === 1 ? 'business' : 'businesses') ?> in this category
        </h5>
        <a href="/dashboard/business/add" class="btn btn-outline-primary btn-sm">
            <i class="bi bi-plus-lg me-1"></i>List in <?= e($category['name']) ?>
        </a>
    </div>

    <?php if (!empty($businesses)): ?>
        <div class="row g-4">
            <?php foreach ($businesses as $biz): ?>
                <?php require __DIR__ . '/../includes/business-card.php'; ?>
            <?php endforeach; ?>
        </div>

        <?php if ($totalPages > 1): ?>
            <nav class="mt-4" aria-label="Category pagination">
                <ul class="pagination justify-content-center">
                    <li class="page-item <?= ($page <= 1 ? 'disabled' : '') ?>">
                        <a class="page-link" href="/category/<?= e($slug) ?>?page=<?= $page - 1 ?>">&laquo; Previous</a>
                    </li>
                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <li class="page-item <?= ($page == $i ? 'active' : '') ?>">
                            <a class="page-link" href="/category/<?= e($slug) ?>?page=<?= $i ?>"><?= $i ?></a>
                        </li>
                    <?php endfor; ?>
                    <li class="page-item <?= ($page >= $totalPages ? 'disabled' : '') ?>">
                        <a class="page-link" href="/category/<?= e($slug) ?>?page=<?= $page + 1 ?>">Next &raquo;</a>
                    </li>
                </ul>
            </nav>
        <?php endif; ?>
    <?php else: ?>
        <div class="card text-center p-5 border-dashed bg-white">
            <i class="bi <?= e($category['icon']) ?> text-muted fs-1 mb-2"></i>
            <h5 class="fw-bold">No businesses listed in <?= e($category['name']) ?> yet</h5>
            <p class="text-muted small">Are you in this line of work? Claim the first spot in this category!</p>
            <div>
                <a href="/dashboard/business/add" class="btn btn-primary btn-sm">Add Your Business</a>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
