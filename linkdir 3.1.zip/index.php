<?php
/**
 * linkdir - Modern Home Page
 */

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/includes/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

$pageTitle = 'Find Trusted Businesses & Services';
$pageDescription = 'Search and discover verified businesses, service providers, and customer reviews on linkdir.';

$db = get_db();

// 1. Fetch active categories with business count
$catStmt = $db->query("
    SELECT c.id, c.name, c.slug, c.description, c.icon, COUNT(b.id) as business_count
    FROM categories c
    LEFT JOIN businesses b ON b.category_id = c.id AND b.status = 'approved'
    WHERE c.status = 'active'
    GROUP BY c.id, c.name, c.slug, c.description, c.icon
    ORDER BY business_count DESC, c.name ASC
    LIMIT 8
");
$popularCategories = $catStmt->fetchAll();

// 2. Fetch featured / recently added approved businesses with rating stats (no city)
$bizStmt = $db->query("
    SELECT b.id, b.business_name, b.slug, b.logo, b.about, b.state, b.country, b.created_at,
           c.name as category_name, c.slug as category_slug,
           COALESCE(AVG(r.rating), 0) as avg_rating,
           COUNT(r.id) as review_count
    FROM businesses b
    JOIN categories c ON b.category_id = c.id
    LEFT JOIN reviews r ON r.business_id = b.id AND r.status = 'approved'
    WHERE b.status = 'approved'
    GROUP BY b.id, b.business_name, b.slug, b.logo, b.about, b.state, b.country, b.created_at, c.name, c.slug
    ORDER BY b.created_at DESC
    LIMIT 6
");
$recentBusinesses = $bizStmt->fetchAll();

// Schema.org WebSite SearchAction
$jsonLd = [
    '@context' => 'https://schema.org',
    '@type' => 'WebSite',
    'name' => SITE_NAME,
    'description' => SITE_TAGLINE,
    'url' => (!empty($_SERVER['HTTP_HOST']) ? 'https://' . $_SERVER['HTTP_HOST'] : '/'),
    'potentialAction' => [
        '@type' => 'SearchAction',
        'target' => '/businesses?q={search_term_string}',
        'query-input' => 'required name=search_term_string'
    ]
];

require_once __DIR__ . '/includes/header.php';
?>

<!-- Modern Search Hero Section -->
<section class="search-hero">
    <div class="container">
        <div class="row justify-content-center text-center mb-4">
            <div class="col-lg-8">
                <div class="d-inline-flex align-items-center gap-2 px-3 py-1 mb-3 rounded-pill bg-white border shadow-xs">
                    <span class="badge bg-primary-subtle text-primary rounded-pill px-2 py-1 small fw-bold">Verified</span>
                    <span class="text-secondary small fw-medium">Community-Driven Business &amp; Service Directory</span>
                </div>
                <h1 class="display-5 fw-bold text-dark mb-3 tracking-tight">Discover Trusted Services &amp; Businesses</h1>
                <p class="lead text-muted fs-6 mb-0 mx-auto" style="max-width: 620px;">
                    Find verified service providers, skilled professionals, contractors, and local businesses with transparent customer reviews.
                </p>
            </div>
        </div>

        <div class="row justify-content-center">
            <div class="col-lg-8 col-md-10">
                <form action="/businesses" method="GET" class="search-hero-box p-2">
                    <div class="row g-2 align-items-center">
                        <div class="col-md-7">
                            <div class="input-group border-0">
                                <span class="input-group-text bg-transparent border-0 text-muted ps-3">
                                    <i class="bi bi-search fs-5 text-primary"></i>
                                </span>
                                <input type="text" name="q" class="form-control border-0 bg-transparent shadow-none ps-2" placeholder="Search by business name or service..." aria-label="Search keyword" autofocus>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <select name="category" class="form-select border-0 bg-transparent shadow-none text-secondary">
                                <option value="">All Categories</option>
                                <?php foreach ($popularCategories as $c): ?>
                                    <option value="<?= e($c['slug']) ?>"><?= e($c['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-2 text-end">
                            <button type="submit" class="btn btn-primary w-100 py-2">
                                <span>Search</span>
                            </button>
                        </div>
                    </div>
                </form>

                <!-- Quick Category Shortcuts -->
                <div class="d-flex align-items-center justify-content-center flex-wrap gap-2 mt-3 small text-muted">
                    <span class="fw-semibold text-secondary small">Trending:</span>
                    <?php 
                    $previewCats = array_slice($popularCategories, 0, 4);
                    foreach ($previewCats as $pc): 
                    ?>
                        <a href="/category/<?= e($pc['slug']) ?>" class="badge bg-white text-secondary border px-2.5 py-1.5 text-decoration-none rounded-pill shadow-xs hover-primary">
                            <?= e($pc['name']) ?>
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</section>

<div class="container my-5">
    <?= flash_render() ?>

    <!-- Top Leaderboard Banner -->
    <?= render_ad('leaderboard_top', 'mb-5') ?>

    <!-- Browse Categories -->
    <section class="mb-5">
        <div class="d-flex justify-content-between align-items-end mb-4">
            <div>
                <span class="badge bg-primary-subtle text-primary border border-primary-subtle px-2.5 py-1 rounded-pill small mb-2 fw-semibold">Categories</span>
                <h2 class="h3 fw-bold mb-1">Explore by Industry</h2>
                <p class="text-muted small mb-0">Browse businesses organized by verified specialty and service type.</p>
            </div>
            <a href="/businesses" class="btn btn-outline-secondary btn-sm">
                <span>View All</span>
                <i class="bi bi-arrow-right"></i>
            </a>
        </div>

        <div class="row g-3">
            <?php foreach ($popularCategories as $cat): ?>
                <div class="col-6 col-md-4 col-lg-3">
                    <a href="/category/<?= e($cat['slug']) ?>" class="card h-100 p-3 category-card text-center d-flex flex-column align-items-center justify-content-center">
                        <div class="category-icon mb-2">
                            <i class="bi <?= e($cat['icon']) ?>"></i>
                        </div>
                        <h6 class="fw-bold mb-1 text-truncate w-100 text-dark"><?= e($cat['name']) ?></h6>
                        <span class="text-muted small"><?= (int)$cat['business_count'] ?> <?= ((int)$cat['business_count'] === 1 ? 'listing' : 'listings') ?></span>
                    </a>
                </div>
            <?php endforeach; ?>
        </div>
    </section>

    <!-- Recent Listings -->
    <section class="mb-5">
        <div class="d-flex justify-content-between align-items-end mb-4">
            <div>
                <span class="badge bg-primary-subtle text-primary border border-primary-subtle px-2.5 py-1 rounded-pill small mb-2 fw-semibold">New Additions</span>
                <h2 class="h3 fw-bold mb-1">Recently Listed Businesses</h2>
                <p class="text-muted small mb-0">Verified service providers, shops, and specialists added recently.</p>
            </div>
            <a href="/businesses?sort=newest" class="btn btn-outline-secondary btn-sm">
                <span>Browse All</span>
                <i class="bi bi-arrow-right"></i>
            </a>
        </div>

        <?php if (!empty($recentBusinesses)): ?>
            <div class="row g-4">
                <?php foreach ($recentBusinesses as $biz): ?>
                    <?php require __DIR__ . '/includes/business-card.php'; ?>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="card p-5 text-center bg-white border-1">
                <div class="category-icon mx-auto mb-3" style="width: 54px; height: 54px;">
                    <i class="bi bi-buildings fs-4"></i>
                </div>
                <h5 class="text-dark fw-bold mb-1">No businesses listed yet</h5>
                <p class="text-muted small mb-3">Be the first to publish your business or service provider to our directory!</p>
                <div>
                    <a href="/dashboard/business/add" class="btn btn-primary btn-sm">
                        <i class="bi bi-plus-lg"></i>
                        <span>Add First Listing</span>
                    </a>
                </div>
            </div>
        <?php endif; ?>
    </section>

    <!-- Business Owner Call to Action -->
    <section class="card border-0 p-4 p-md-5 rounded-4 mb-4" style="background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%); color: #ffffff;">
        <div class="row g-4 align-items-center">
            <div class="col-lg-8">
                <span class="badge bg-primary text-white rounded-pill px-3 py-1 mb-2 fw-semibold small">Grow Your Presence</span>
                <h3 class="fw-bold mb-2 text-white">Do you provide a service or run a business?</h3>
                <p class="text-slate-300 text-light opacity-75 mb-0 lh-base">
                    Get discovered by clients actively looking for your expertise. It takes less than two minutes to submit your listing with contact information, portfolio details, website link, and verified customer reviews.
                </p>
            </div>
            <div class="col-lg-4 text-lg-end">
                <a href="<?= auth_check() ? '/dashboard/business/add' : '/register' ?>" class="btn btn-primary btn-lg">
                    <i class="bi bi-plus-circle"></i>
                    <span>List Your Business Now</span>
                </a>
            </div>
        </div>
    </section>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
