<?php
/**
 * linkdir - User Profile & Password Settings
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';

auth_require_login();
$user = auth_user();
$db = get_db();

$nameErrors = [];
$passErrors = [];

// Handle Name Update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action_name'])) {
    csrf_require();
    $newName = trim($_POST['name'] ?? '');

    if (empty($newName)) {
        $nameErrors[] = 'Name cannot be empty.';
    } elseif (mb_strlen($newName) > 100) {
        $nameErrors[] = 'Name is too long.';
    }

    if (empty($nameErrors)) {
        $stmt = $db->prepare("UPDATE users SET name = ? WHERE id = ?");
        $stmt->execute([$newName, $user['id']]);

        // Refresh session
        $_SESSION['user']['name'] = $newName;
        $user['name'] = $newName;

        flash_set('success', 'Profile name updated successfully.');
        header('Location: /dashboard/profile');
        exit;
    }
}

// Handle Password Change
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action_password'])) {
    csrf_require();
    $currentPassword = $_POST['current_password'] ?? '';
    $newPassword = $_POST['new_password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';

    // Fetch user hash
    $stmt = $db->prepare("SELECT password_hash FROM users WHERE id = ? LIMIT 1");
    $stmt->execute([$user['id']]);
    $dbHash = $stmt->fetchColumn();

    if (!password_verify($currentPassword, $dbHash)) {
        $passErrors[] = 'Current password is incorrect.';
    }

    if (empty($newPassword) || strlen($newPassword) < 8) {
        $passErrors[] = 'New password must be at least 8 characters long.';
    }

    if ($newPassword !== $confirmPassword) {
        $passErrors[] = 'New passwords do not match.';
    }

    if (empty($passErrors)) {
        $newHash = password_hash($newPassword, PASSWORD_DEFAULT);
        $updateStmt = $db->prepare("UPDATE users SET password_hash = ? WHERE id = ?");
        $updateStmt->execute([$newHash, $user['id']]);

        flash_set('success', 'Password updated successfully.');
        header('Location: /dashboard/profile');
        exit;
    }
}

$pageTitle = 'Account Profile & Settings';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="bg-light border-bottom py-4 mb-4">
    <div class="container">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb small mb-1">
                <li class="breadcrumb-item"><a href="/" class="text-decoration-none">Home</a></li>
                <li class="breadcrumb-item"><a href="/dashboard" class="text-decoration-none">Dashboard</a></li>
                <li class="breadcrumb-item active" aria-current="page">Account Settings</li>
            </ol>
        </nav>
        <h1 class="h3 fw-bold mb-0">Account Settings</h1>
    </div>
</div>

<div class="container mb-5">
    <?= flash_render() ?>

    <div class="row g-4">
        <!-- Profile Info -->
        <div class="col-md-6">
            <div class="card shadow-sm border-1 p-4 h-100">
                <h5 class="fw-bold mb-3 border-bottom pb-2">Profile Information</h5>

                <?php if (!empty($nameErrors)): ?>
                    <div class="alert alert-danger mb-3 py-2 small">
                        <ul class="mb-0 ps-3">
                            <?php foreach ($nameErrors as $err): ?>
                                <li><?= e($err) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form action="/dashboard/profile" method="POST">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action_name" value="1">

                    <div class="mb-3">
                        <label class="form-label small fw-semibold text-muted">Email Address</label>
                        <input type="text" class="form-control" value="<?= e($user['email']) ?>" readonly disabled>
                        <div class="form-text small">Email cannot be changed directly.</div>
                    </div>

                    <div class="mb-3">
                        <label for="name" class="form-label small fw-semibold text-muted">Display Name / Representative Name</label>
                        <input type="text" class="form-control" id="name" name="name" value="<?= e($user['name']) ?>" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label small fw-semibold text-muted">Account Role</label>
                        <div>
                            <span class="badge <?= ($user['role'] === 'admin' ? 'bg-danger' : 'bg-secondary') ?> px-2 py-1">
                                <?= ucfirst(e($user['role'])) ?>
                            </span>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary btn-sm px-3">
                        Save Profile Name
                    </button>
                </form>
            </div>
        </div>

        <!-- Change Password -->
        <div class="col-md-6">
            <div class="card shadow-sm border-1 p-4 h-100">
                <h5 class="fw-bold mb-3 border-bottom pb-2">Security &amp; Password</h5>

                <?php if (!empty($passErrors)): ?>
                    <div class="alert alert-danger mb-3 py-2 small">
                        <ul class="mb-0 ps-3">
                            <?php foreach ($passErrors as $err): ?>
                                <li><?= e($err) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form action="/dashboard/profile" method="POST">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action_password" value="1">

                    <div class="mb-3">
                        <label for="current_password" class="form-label small fw-semibold text-muted">Current Password</label>
                        <input type="password" class="form-control" id="current_password" name="current_password" required autocomplete="current-password">
                    </div>

                    <div class="mb-3">
                        <label for="new_password" class="form-label small fw-semibold text-muted">New Password (min. 8 characters)</label>
                        <input type="password" class="form-control" id="new_password" name="new_password" required autocomplete="new-password" minlength="8">
                    </div>

                    <div class="mb-3">
                        <label for="confirm_password" class="form-label small fw-semibold text-muted">Confirm New Password</label>
                        <input type="password" class="form-control" id="confirm_password" name="confirm_password" required autocomplete="new-password" minlength="8">
                    </div>

                    <button type="submit" class="btn btn-outline-primary btn-sm px-3">
                        Change Password
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
