<?php
/**
 * linkdir - User's Reviews Management
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';

auth_require_login();
$user = auth_user();
$db = get_db();

// Fetch reviews submitted by this user
$stmt = $db->prepare("
    SELECT r.*, b.business_name, b.slug as business_slug, b.state, b.country
    FROM reviews r
    JOIN businesses b ON r.business_id = b.id
    WHERE r.user_id = ?
    ORDER BY r.created_at DESC
");
$stmt->execute([$user['id']]);
$reviews = $stmt->fetchAll();

$pageTitle = 'My Reviews';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="bg-light border-bottom py-4 mb-4">
    <div class="container">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb small mb-1">
                <li class="breadcrumb-item"><a href="/" class="text-decoration-none">Home</a></li>
                <li class="breadcrumb-item"><a href="/dashboard" class="text-decoration-none">Dashboard</a></li>
                <li class="breadcrumb-item active" aria-current="page">My Reviews</li>
            </ol>
        </nav>
        <h1 class="h3 fw-bold mb-0">My Submitted Reviews</h1>
    </div>
</div>

<div class="container mb-5">
    <?= flash_render() ?>

    <div class="card shadow-sm border-1">
        <div class="card-header bg-white py-3">
            <h5 class="fw-bold mb-0">Reviews Written by You (<?= count($reviews) ?>)</h5>
        </div>

        <div class="card-body p-0">
            <?php if (!empty($reviews)): ?>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>Business</th>
                                <th>Rating</th>
                                <th>Your Feedback</th>
                                <th>Date</th>
                                <th>Status</th>
                                <th class="text-end">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($reviews as $rev): ?>
                                <tr id="user-review-row-<?= (int)$rev['id'] ?>">
                                    <td>
                                        <strong>
                                            <a href="/business/<?= e($rev['business_slug']) ?>" class="text-decoration-none text-dark">
                                                <?= e($rev['business_name']) ?>
                                            </a>
                                        </strong>
                                        <?php if (!empty($rev['country'])): ?>
                                            <div class="text-muted small"><?= e($rev['country']) ?></div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?= render_stars((float)$rev['rating'], false) ?>
                                    </td>
                                    <td class="small" style="max-width: 320px;">
                                        <?= e($rev['review_text']) ?>
                                    </td>
                                    <td class="small text-muted">
                                        <?= format_date($rev['created_at']) ?>
                                    </td>
                                    <td>
                                        <?php if ($rev['status'] === 'approved'): ?>
                                            <span class="badge badge-status-approved">Published</span>
                                        <?php elseif ($rev['status'] === 'pending'): ?>
                                            <span class="badge badge-status-pending">Under Review</span>
                                        <?php else: ?>
                                            <span class="badge badge-status-rejected">Rejected</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-end">
                                        <button class="btn btn-outline-danger btn-sm"
                                                hx-post="/actions/review.php?action=delete&id=<?= (int)$rev['id'] ?>"
                                                hx-confirm="Are you sure you want to delete your review for <?= e($rev['business_name']) ?>?"
                                                hx-target="#user-review-row-<?= (int)$rev['id'] ?>"
                                                hx-swap="outerHTML">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="text-center p-5 text-muted">
                    <i class="bi bi-chat-left-quote fs-1 mb-2 d-block"></i>
                    <h5 class="fw-bold text-dark">No reviews written yet</h5>
                    <p class="small mb-3">You haven't posted any reviews. Explore the directory and share your experiences!</p>
                    <a href="/businesses" class="btn btn-outline-primary btn-sm">Explore Businesses</a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
