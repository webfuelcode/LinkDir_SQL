<?php
/**
 * linkdir - Add Business Listing
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';

auth_require_login();
$user = auth_user();
$db = get_db();

// Check user listing allowance
$limitInfo = get_user_listing_limit_info($user);

// Fetch categories
$catStmt = $db->query("SELECT id, name FROM categories WHERE status = 'active' ORDER BY name ASC");
$categories = $catStmt->fetchAll();

$errors = [];
$formData = [
    'business_name' => '',
    'category_id'   => '',
    'website_url'   => '',
    'phone'         => '',
    'email'         => '',
    'address'       => '',
    'state'         => '',
    'country'       => 'United States',
    'about'         => '',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_require();

    // Re-verify limit on submission
    if ($limitInfo['is_reached']) {
        $errors[] = 'You have reached the maximum allowed limit of ' . $limitInfo['limit'] . ' business listings for standard accounts.';
    }

    $formData['business_name'] = trim($_POST['business_name'] ?? '');
    $formData['category_id']   = (int)($_POST['category_id'] ?? 0);
    $formData['website_url']   = trim($_POST['website_url'] ?? '');
    $formData['phone']         = trim($_POST['phone'] ?? '');
    $formData['email']         = trim($_POST['email'] ?? '');
    $formData['address']       = trim($_POST['address'] ?? '');
    $formData['state']         = '';
    $formData['country']       = trim($_POST['country'] ?? 'United States');
    $formData['about']         = trim($_POST['about'] ?? '');

    // Validation
    if (empty($formData['business_name'])) {
        $errors[] = 'Business or service name is required.';
    } elseif (mb_strlen($formData['business_name']) > 150) {
        $errors[] = 'Business name is too long (max 150 characters).';
    }

    if (empty($formData['category_id'])) {
        $errors[] = 'Please select a valid business category.';
    }

    if (empty($formData['about'])) {
        $errors[] = 'About description is required.';
    } elseif (mb_strlen($formData['about']) < 20) {
        $errors[] = 'Please provide a more descriptive about section (at least 20 characters).';
    }

    if (!empty($formData['email']) && !filter_var($formData['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'The contact email address is not valid.';
    }

    if (!empty($formData['website_url']) && !filter_var($formData['website_url'], FILTER_VALIDATE_URL)) {
        $errors[] = 'Website URL must be a valid web address (e.g. https://example.com).';
    }

    // Logo upload handling
    $logoFilename = null;
    if (!empty($_FILES['logo']['name'])) {
        try {
            $logoFilename = handle_image_upload($_FILES['logo']);
        } catch (Exception $e) {
            $errors[] = $e->getMessage();
        }
    }

    // Insert business
    if (empty($errors)) {
        try {
            // Generate unique slug
            $baseSlug = slugify($formData['business_name']);
            $slug = $baseSlug;
            $counter = 1;

            $slugStmt = $db->prepare("SELECT id FROM businesses WHERE slug = ? LIMIT 1");
            while (true) {
                $slugStmt->execute([$slug]);
                if (!$slugStmt->fetch()) {
                    break;
                }
                $counter++;
                $slug = $baseSlug . '-' . $counter;
            }

            // Determine approval status
            $initialStatus = 'pending';
            if (!REQUIRE_BUSINESS_APPROVAL || auth_is_admin()) {
                $initialStatus = 'approved';
            }

            $stmt = $db->prepare("
                INSERT INTO businesses (
                    user_id, category_id, business_name, slug, website_url, logo, about,
                    phone, email, address, city, state, country, status, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, '', ?, ?, ?, CURRENT_TIMESTAMP)
            ");
            $stmt->execute([
                $user['id'],
                $formData['category_id'],
                $formData['business_name'],
                $slug,
                $formData['website_url'] ?: null,
                $logoFilename,
                $formData['about'],
                $formData['phone'] ?: null,
                $formData['email'] ?: null,
                $formData['address'] ?: null,
                $formData['state'],
                $formData['country'],
                $initialStatus
            ]);

            if ($initialStatus === 'approved') {
                flash_set('success', 'Your business listing has been published!');
            } else {
                flash_set('info', 'Your listing has been submitted and is waiting for administrator approval.');
            }

            header('Location: /dashboard');
            exit;
        } catch (PDOException $e) {
            error_log('Add Business Error: ' . $e->getMessage());
            $errors[] = 'A database error occurred while saving your listing. Please try again.';
        }
    }
}

$pageTitle = 'Add Your Business';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="bg-light border-bottom py-4 mb-4">
    <div class="container">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-2">
            <div>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb small mb-1">
                        <li class="breadcrumb-item"><a href="/" class="text-decoration-none">Home</a></li>
                        <li class="breadcrumb-item"><a href="/dashboard" class="text-decoration-none">Dashboard</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Add Business</li>
                    </ol>
                </nav>
                <h1 class="h3 fw-bold mb-0">List Your Business or Service</h1>
            </div>
            <div>
                <?php if ($limitInfo['is_unlimited']): ?>
                    <span class="badge bg-light text-secondary border px-3 py-2">
                        <i class="bi bi-infinity me-1"></i>Unlimited Listing Allowance
                    </span>
                <?php else: ?>
                    <span class="badge <?= $limitInfo['is_reached'] ? 'bg-danger-subtle text-danger border border-danger-subtle' : 'bg-primary-subtle text-primary border border-primary-subtle' ?> px-3 py-2">
                        <i class="bi bi-speedometer2 me-1"></i>Allowance: <?= $limitInfo['count'] ?> of <?= $limitInfo['limit'] ?> used
                    </span>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div class="container mb-5">
    <div class="row justify-content-center">
        <div class="col-lg-9">
            <?php if (!empty($errors)): ?>
                <div class="alert alert-danger mb-4">
                    <ul class="mb-0 ps-3 small">
                        <?php foreach ($errors as $err): ?>
                            <li><?= e($err) ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <?php if ($limitInfo['is_reached']): ?>
                <!-- Limit Reached Notice -->
                <div class="card border-warning border-2 shadow-sm p-4 p-md-5 text-center">
                    <div class="mb-3">
                        <span class="d-inline-flex align-items-center justify-content-center rounded-circle bg-warning-subtle text-warning" style="width: 72px; height: 72px;">
                            <i class="bi bi-exclamation-triangle-fill fs-1"></i>
                        </span>
                    </div>
                    <h3 class="fw-bold text-dark mb-2">Listing Entry Limit Reached</h3>
                    <p class="text-secondary mx-auto mb-4" style="max-width: 600px;">
                        You have already created <strong><?= $limitInfo['count'] ?></strong> of <strong><?= $limitInfo['limit'] ?></strong> allowed business listings for your account. Under our directory policies, each standard registered member may add up to <?= $limitInfo['limit'] ?> listings.
                    </p>

                    <div class="p-3 bg-light rounded border mx-auto mb-4 text-start" style="max-width: 500px;">
                        <div class="fw-semibold text-dark small mb-1">What can you do?</div>
                        <ul class="small text-muted mb-0 ps-3">
                            <li>Manage, update, or remove an existing listing in your dashboard.</li>
                            <li>If you operate multiple branches or enterprise brands, contact our team to request a limit increase.</li>
                        </ul>
                    </div>

                    <div class="d-flex flex-wrap justify-content-center gap-2">
                        <a href="/dashboard" class="btn btn-primary px-4 py-2 fw-semibold">
                            <i class="bi bi-speedometer2 me-1"></i>Return to My Dashboard
                        </a>
                        <a href="/page/contact-us" class="btn btn-outline-secondary px-4 py-2">
                            <i class="bi bi-envelope me-1"></i>Contact Support
                        </a>
                    </div>
                </div>
            <?php else: ?>
                <div class="card shadow-sm border-1 p-4 p-md-5">
                    <form action="/dashboard/business/add" method="POST" enctype="multipart/form-data">
                        <?= csrf_field() ?>

                        <!-- Basic Info -->
                        <h5 class="fw-bold mb-3 border-bottom pb-2">1. Business Profile</h5>

                    <div class="row g-3 mb-4">
                        <div class="col-md-8">
                            <label for="business_name" class="form-label small fw-semibold text-muted">Business / Service Name *</label>
                            <input type="text" class="form-control" id="business_name" name="business_name" value="<?= e($formData['business_name']) ?>" required placeholder="e.g. Apex Electrical Solutions">
                        </div>

                        <div class="col-md-4">
                            <label for="category_id" class="form-label small fw-semibold text-muted">Category *</label>
                            <select class="form-select" id="category_id" name="category_id" required>
                                <option value="">Select category...</option>
                                <?php foreach ($categories as $cat): ?>
                                    <option value="<?= (int)$cat['id'] ?>" <?= ($formData['category_id'] == $cat['id'] ? 'selected' : '') ?>>
                                        <?= e($cat['name']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <div class="form-text small"><i class="bi bi-shield-check text-primary me-1"></i>Curated by directory administrators</div>
                        </div>

                        <div class="col-12">
                            <label for="about" class="form-label small fw-semibold text-muted">About Business / Service *</label>
                            <textarea class="form-control" id="about" name="about" rows="5" required placeholder="Describe your services, credentials, history, and what sets you apart..."><?= e($formData['about']) ?></textarea>
                            <div class="form-text small">Plain text formatting. Maximum 3,000 characters.</div>
                        </div>

                        <div class="col-12">
                            <label for="logo" class="form-label small fw-semibold text-muted">Business Logo / Featured Image</label>
                            <input type="file" class="form-control" id="logo" name="logo" accept="image/jpeg,image/png,image/webp">
                            <div class="form-text small">Allowed formats: JPG, PNG, WebP (max 2 MB). Automatically resized to 800×800.</div>
                        </div>
                    </div>

                    <!-- Contact Details -->
                    <h5 class="fw-bold mb-3 border-bottom pb-2">2. Contact Information</h5>

                    <div class="row g-3 mb-4">
                        <div class="col-md-6">
                            <label for="phone" class="form-label small fw-semibold text-muted">Contact Phone Number</label>
                            <input type="tel" class="form-control" id="phone" name="phone" value="<?= e($formData['phone']) ?>" placeholder="e.g. (555) 234-5678">
                        </div>

                        <div class="col-md-6">
                            <label for="email" class="form-label small fw-semibold text-muted">Public Contact Email</label>
                            <input type="email" class="form-control" id="email" name="email" value="<?= e($formData['email']) ?>" placeholder="e.g. contact@apexelectrical.com">
                        </div>

                        <div class="col-12">
                            <label for="website_url" class="form-label small fw-semibold text-muted">Website URL</label>
                            <input type="url" class="form-control" id="website_url" name="website_url" value="<?= e($formData['website_url']) ?>" placeholder="https://www.example.com">
                        </div>
                    </div>

                    <!-- Location -->
                    <h5 class="fw-bold mb-3 border-bottom pb-2">3. Location</h5>

                    <div class="row g-3 mb-4">
                        <div class="col-md-7">
                            <label for="address" class="form-label small fw-semibold text-muted">Street Address</label>
                            <input type="text" class="form-control" id="address" name="address" value="<?= e($formData['address']) ?>" placeholder="123 Market St, Suite 400">
                        </div>

                        <div class="col-md-5">
                            <label for="country" class="form-label small fw-semibold text-muted">Country *</label>
                            <input type="text" class="form-control" id="country" name="country" value="<?= e($formData['country']) ?>" required>
                        </div>
                    </div>

                    <div class="d-flex justify-content-between align-items-center pt-3 border-top">
                        <a href="/dashboard" class="btn btn-outline-secondary">Cancel</a>
                        <button type="submit" class="btn btn-primary px-4 py-2 fw-semibold">
                            <i class="bi bi-check-lg me-1"></i> Submit Listing
                        </button>
                    </div>
                </form>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
