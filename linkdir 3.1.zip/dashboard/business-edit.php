<?php
/**
 * linkdir - Edit Business Listing
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';

auth_require_login();
$user = auth_user();
$db = get_db();

$bizId = (int)($_GET['id'] ?? 0);
if ($bizId <= 0) {
    header('Location: /dashboard');
    exit;
}

// Fetch business and verify ownership
$stmt = $db->prepare("SELECT * FROM businesses WHERE id = ? LIMIT 1");
$stmt->execute([$bizId]);
$biz = $stmt->fetch();

if (!$biz) {
    flash_set('danger', 'Listing not found.');
    header('Location: /dashboard');
    exit;
}

// Strict ownership check (or administrator)
if ($biz['user_id'] != $user['id'] && !auth_is_admin()) {
    http_response_code(403);
    die('Forbidden: You do not have permission to modify this business listing.');
}

// Fetch categories
$catStmt = $db->query("SELECT id, name FROM categories WHERE status = 'active' ORDER BY name ASC");
$categories = $catStmt->fetchAll();

$errors = [];
$formData = [
    'business_name' => $biz['business_name'],
    'category_id'   => $biz['category_id'],
    'website_url'   => $biz['website_url'] ?? '',
    'phone'         => $biz['phone'] ?? '',
    'email'         => $biz['email'] ?? '',
    'address'       => $biz['address'] ?? '',
    'state'         => $biz['state'],
    'country'       => $biz['country'],
    'about'         => $biz['about'],
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_require();

    $formData['business_name'] = trim($_POST['business_name'] ?? '');
    $formData['category_id']   = (int)($_POST['category_id'] ?? 0);
    $formData['website_url']   = trim($_POST['website_url'] ?? '');
    $formData['phone']         = trim($_POST['phone'] ?? '');
    $formData['email']         = trim($_POST['email'] ?? '');
    $formData['address']       = trim($_POST['address'] ?? '');
    $formData['state']         = '';
    $formData['country']       = trim($_POST['country'] ?? 'United States');
    $formData['about']         = trim($_POST['about'] ?? '');

    // Validation
    if (empty($formData['business_name'])) {
        $errors[] = 'Business or service name is required.';
    } elseif (mb_strlen($formData['business_name']) > 150) {
        $errors[] = 'Business name is too long (max 150 characters).';
    }

    if (empty($formData['category_id'])) {
        $errors[] = 'Please select a valid business category.';
    }

    if (empty($formData['about'])) {
        $errors[] = 'About description is required.';
    } elseif (mb_strlen($formData['about']) < 20) {
        $errors[] = 'Please provide a more descriptive about section (at least 20 characters).';
    }

    if (!empty($formData['email']) && !filter_var($formData['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'The contact email address is not valid.';
    }

    if (!empty($formData['website_url']) && !filter_var($formData['website_url'], FILTER_VALIDATE_URL)) {
        $errors[] = 'Website URL must be a valid web address (e.g. https://example.com).';
    }

    // Logo update
    $newLogo = $biz['logo'];
    if (!empty($_FILES['logo']['name'])) {
        try {
            $newLogo = handle_image_upload($_FILES['logo']);
        } catch (Exception $e) {
            $errors[] = $e->getMessage();
        }
    }

    if (empty($errors)) {
        try {
            $updateStmt = $db->prepare("
                UPDATE businesses SET
                    category_id = ?,
                    business_name = ?,
                    website_url = ?,
                    logo = ?,
                    about = ?,
                    phone = ?,
                    email = ?,
                    address = ?,
                    city = '',
                    state = ?,
                    country = ?,
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
            ");
            $updateStmt->execute([
                $formData['category_id'],
                $formData['business_name'],
                $formData['website_url'] ?: null,
                $newLogo,
                $formData['about'],
                $formData['phone'] ?: null,
                $formData['email'] ?: null,
                $formData['address'] ?: null,
                $formData['state'],
                $formData['country'],
                $bizId
            ]);

            flash_set('success', 'Business listing updated successfully.');
            header('Location: /business/' . urlencode($biz['slug']));
            exit;
        } catch (PDOException $e) {
            error_log('Edit Business Error: ' . $e->getMessage());
            $errors[] = 'A database error occurred while updating the listing.';
        }
    }
}

$pageTitle = 'Edit Business - ' . $biz['business_name'];
require_once __DIR__ . '/../includes/header.php';
?>

<div class="bg-light border-bottom py-4 mb-4">
    <div class="container">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb small mb-1">
                <li class="breadcrumb-item"><a href="/" class="text-decoration-none">Home</a></li>
                <li class="breadcrumb-item"><a href="/dashboard" class="text-decoration-none">Dashboard</a></li>
                <li class="breadcrumb-item active" aria-current="page">Edit Listing</li>
            </ol>
        </nav>
        <h1 class="h3 fw-bold mb-0">Edit Business Listing</h1>
    </div>
</div>

<div class="container mb-5">
    <div class="row justify-content-center">
        <div class="col-lg-9">
            <div class="card shadow-sm border-1 p-4 p-md-5">
                <?php if (!empty($errors)): ?>
                    <div class="alert alert-danger mb-4">
                        <ul class="mb-0 ps-3 small">
                            <?php foreach ($errors as $err): ?>
                                <li><?= e($err) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form action="/dashboard/business/edit/<?= (int)$biz['id'] ?>" method="POST" enctype="multipart/form-data">
                    <?= csrf_field() ?>

                    <h5 class="fw-bold mb-3 border-bottom pb-2">1. Business Profile</h5>

                    <div class="row g-3 mb-4">
                        <div class="col-md-8">
                            <label for="business_name" class="form-label small fw-semibold text-muted">Business / Service Name *</label>
                            <input type="text" class="form-control" id="business_name" name="business_name" value="<?= e($formData['business_name']) ?>" required>
                        </div>

                        <div class="col-md-4">
                            <label for="category_id" class="form-label small fw-semibold text-muted">Category *</label>
                            <select class="form-select" id="category_id" name="category_id" required>
                                <?php foreach ($categories as $cat): ?>
                                    <option value="<?= (int)$cat['id'] ?>" <?= ($formData['category_id'] == $cat['id'] ? 'selected' : '') ?>>
                                        <?= e($cat['name']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <div class="form-text small"><i class="bi bi-shield-check text-primary me-1"></i>Curated by directory administrators</div>
                        </div>

                        <div class="col-12">
                            <label for="about" class="form-label small fw-semibold text-muted">About Business / Service *</label>
                            <textarea class="form-control" id="about" name="about" rows="5" required><?= e($formData['about']) ?></textarea>
                        </div>

                        <div class="col-12">
                            <label for="logo" class="form-label small fw-semibold text-muted">Replace Business Logo (optional)</label>
                            <div class="d-flex align-items-center gap-3 mb-2">
                                <?php if (!empty($biz['logo'])): ?>
                                    <img src="/uploads/businesses/<?= e($biz['logo']) ?>" alt="Current Logo" class="business-logo-thumb">
                                    <span class="small text-muted">Current image on file. Upload a new file below only to replace it.</span>
                                <?php endif; ?>
                            </div>
                            <input type="file" class="form-control" id="logo" name="logo" accept="image/jpeg,image/png,image/webp">
                            <div class="form-text small">JPG, PNG, WebP up to 2 MB. Resized automatically.</div>
                        </div>
                    </div>

                    <h5 class="fw-bold mb-3 border-bottom pb-2">2. Contact Information</h5>

                    <div class="row g-3 mb-4">
                        <div class="col-md-6">
                            <label for="phone" class="form-label small fw-semibold text-muted">Contact Phone Number</label>
                            <input type="tel" class="form-control" id="phone" name="phone" value="<?= e($formData['phone']) ?>">
                        </div>

                        <div class="col-md-6">
                            <label for="email" class="form-label small fw-semibold text-muted">Public Contact Email</label>
                            <input type="email" class="form-control" id="email" name="email" value="<?= e($formData['email']) ?>">
                        </div>

                        <div class="col-12">
                            <label for="website_url" class="form-label small fw-semibold text-muted">Website URL</label>
                            <input type="url" class="form-control" id="website_url" name="website_url" value="<?= e($formData['website_url']) ?>">
                        </div>
                    </div>

                    <h5 class="fw-bold mb-3 border-bottom pb-2">3. Location</h5>

                    <div class="row g-3 mb-4">
                        <div class="col-md-7">
                            <label for="address" class="form-label small fw-semibold text-muted">Street Address</label>
                            <input type="text" class="form-control" id="address" name="address" value="<?= e($formData['address']) ?>">
                        </div>

                        <div class="col-md-5">
                            <label for="country" class="form-label small fw-semibold text-muted">Country *</label>
                            <input type="text" class="form-control" id="country" name="country" value="<?= e($formData['country']) ?>" required>
                        </div>
                    </div>

                    <div class="d-flex justify-content-between align-items-center pt-3 border-top">
                        <a href="/dashboard" class="btn btn-outline-secondary">Cancel</a>
                        <button type="submit" class="btn btn-primary px-4 py-2 fw-semibold">
                            <i class="bi bi-check-lg me-1"></i> Save Changes
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
