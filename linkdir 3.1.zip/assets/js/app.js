/**
 * linkdir - Vanilla JS Enhancements & HTMX Configuration
 */

document.addEventListener('DOMContentLoaded', () => {
    // 1. Configure HTMX to automatically inject CSRF token into all AJAX requests
    if (typeof htmx !== 'undefined') {
        document.body.addEventListener('htmx:configRequest', (event) => {
            const tokenMeta = document.querySelector('meta[name="csrf-token"]');
            if (tokenMeta && tokenMeta.content) {
                event.detail.headers['X-CSRF-Token'] = tokenMeta.content;
            }
        });

        // Scroll to top of list if pagination triggers
        document.body.addEventListener('htmx:afterOnLoad', (event) => {
            if (event.detail.target && (event.detail.target.id === 'businesses-list' || event.detail.target.id === 'businesses-results')) {
                const searchCard = document.getElementById('search-filter-card') || document.getElementById('filter-form');
                if (searchCard) {
                    searchCard.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }
            }
        });
    }

    // 2. Initialize Bootstrap Tooltips if available
    if (typeof bootstrap !== 'undefined' && bootstrap.Tooltip) {
        const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        tooltipTriggerList.map((tooltipTriggerEl) => new bootstrap.Tooltip(tooltipTriggerEl));
    }

    // 3. Auto-dismiss success alert banners after 5 seconds
    const autoAlerts = document.querySelectorAll('.alert-auto-dismiss');
    autoAlerts.forEach((alertEl) => {
        setTimeout(() => {
            if (typeof bootstrap !== 'undefined' && bootstrap.Alert) {
                const bsAlert = new bootstrap.Alert(alertEl);
                bsAlert.close();
            } else {
                alertEl.remove();
            }
        }, 5000);
    });
});
