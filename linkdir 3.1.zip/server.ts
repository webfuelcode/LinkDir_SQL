import http from 'node:http';
import { spawn, execSync, ChildProcess } from 'node:child_process';
import path from 'node:path';

const PHP_PORT = 8088;
const PORT = 3000;
let phpProcess: ChildProcess | null = null;

function ensurePhpInstalled() {
  try {
    execSync('which php', { stdio: 'ignore' });
  } catch {
    console.log('PHP not found, installing php-cli, php-sqlite3, php-mbstring...');
    try {
      execSync('yes N | DEBIAN_FRONTEND=noninteractive apt-get update && yes N | DEBIAN_FRONTEND=noninteractive apt-get install -y -o Dpkg::Options::="--force-confdef" -o Dpkg::Options::="--force-confold" php-cli php-sqlite3 php-mbstring', { stdio: 'inherit' });
    } catch (e) {
      console.error('Failed to auto-install PHP:', e);
    }
  }
}

function startPhpServer() {
  ensurePhpInstalled();
  console.log(`Starting PHP built-in server on 127.0.0.1:${PHP_PORT}...`);
  phpProcess = spawn('php', ['-S', `127.0.0.1:${PHP_PORT}`, 'router.php'], {
    stdio: 'inherit',
    cwd: process.cwd(),
  });

  phpProcess.on('error', (err) => {
    console.error('Failed to start PHP server:', err);
  });

  phpProcess.on('exit', (code, signal) => {
    console.warn(`PHP server exited with code ${code}, signal ${signal}. Restarting in 1s...`);
    setTimeout(startPhpServer, 1000);
  });
}

startPhpServer();

process.on('exit', () => {
  if (phpProcess) phpProcess.kill();
});
process.on('SIGINT', () => {
  if (phpProcess) phpProcess.kill();
  process.exit();
});
process.on('SIGTERM', () => {
  if (phpProcess) phpProcess.kill();
  process.exit();
});

// Proxy HTTP requests on port 3000 directly to the PHP application server
const server = http.createServer((clientReq, clientRes) => {
  const options = {
    hostname: '127.0.0.1',
    port: PHP_PORT,
    path: clientReq.url,
    method: clientReq.method,
    headers: {
      ...clientReq.headers,
      host: clientReq.headers.host || `localhost:${PORT}`,
      'x-forwarded-host': clientReq.headers.host || `localhost:${PORT}`,
      'x-forwarded-for': clientReq.socket.remoteAddress || '127.0.0.1',
      'x-forwarded-proto': 'http',
    },
  };

  const proxyReq = http.request(options, (proxyRes) => {
    clientRes.writeHead(proxyRes.statusCode || 200, proxyRes.headers);
    proxyRes.pipe(clientRes, { end: true });
  });

  proxyReq.on('error', (err) => {
    console.error('Proxy routing error:', err.message);
    if (!clientRes.headersSent) {
      clientRes.writeHead(502, { 'Content-Type': 'text/html; charset=utf-8' });
      clientRes.end(`
        <!DOCTYPE html>
        <html>
        <head><title>Starting linkdir...</title><meta http-equiv="refresh" content="2"></head>
        <body style="font-family: sans-serif; display: flex; align-items: center; justify-content: center; height: 80vh; flex-direction: column;">
          <h2>Starting linkdir Application Server...</h2>
          <p>Please wait a moment while PHP initializes. Page will refresh automatically.</p>
        </body>
        </html>
      `);
    }
  });

  clientReq.pipe(proxyReq, { end: true });
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`linkdir proxy listening on http://0.0.0.0:${PORT} -> forwarding to PHP 127.0.0.1:${PHP_PORT}`);
});
