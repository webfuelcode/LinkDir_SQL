<?php
/**
 * linkdir - User Registration
 */

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/includes/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/csrf.php';
require_once __DIR__ . '/includes/captcha.php';

// Redirect if already logged in
if (auth_check()) {
    header('Location: /dashboard');
    exit;
}

$errors = [];
$name = trim($_POST['name'] ?? '');
$email = trim($_POST['email'] ?? '');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_require();

    // 1. Honeypot check
    if (!honeypot_verify()) {
        $errors[] = 'Spam submission detected.';
    }

    // 2. Math CAPTCHA verification
    $captchaAnswer = $_POST['captcha_challenge'] ?? '';
    if (!captcha_verify($captchaAnswer)) {
        $errors[] = 'Human verification answer was incorrect or expired. Please solve the challenge below.';
    }

    // 3. Rate limiting check
    $ip = get_client_ip();
    $rateKey = 'register_' . $ip;
    if (!rate_limit_check($rateKey, 10, 3600)) {
        $errors[] = 'Too many registration attempts. Please wait an hour and try again.';
    }

    // 4. Validate fields
    $password = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';

    if (empty($name)) {
        $errors[] = 'Full name is required.';
    } elseif (mb_strlen($name) > 100) {
        $errors[] = 'Name is too long (maximum 100 characters).';
    }

    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'A valid email address is required.';
    } elseif (mb_strlen($email) > 190) {
        $errors[] = 'Email is too long.';
    }

    if (empty($password)) {
        $errors[] = 'Password is required.';
    } elseif (strlen($password) < 8) {
        $errors[] = 'Password must be at least 8 characters long.';
    }

    if ($password !== $confirmPassword) {
        $errors[] = 'Passwords do not match.';
    }

    // 5. Database registration
    if (empty($errors)) {
        $db = get_db();

        // Check duplicate email
        $checkStmt = $db->prepare("SELECT id FROM users WHERE email = ? LIMIT 1");
        $checkStmt->execute([$email]);
        if ($checkStmt->fetch()) {
            $errors[] = 'An account with this email address already exists. Try logging in instead.';
        } else {
            try {
                $hash = password_hash($password, PASSWORD_DEFAULT);
                $insStmt = $db->prepare("
                    INSERT INTO users (name, email, password_hash, role, status, created_at)
                    VALUES (?, ?, ?, 'user', 'active', CURRENT_TIMESTAMP)
                ");
                $insStmt->execute([$name, $email, $hash]);
                $newUserId = (int)$db->lastInsertId();

                rate_limit_record($rateKey, 3600);

                // Auto-login new user
                $newUser = [
                    'id'    => $newUserId,
                    'name'  => $name,
                    'email' => $email,
                    'role'  => 'user'
                ];
                auth_login($newUser);

                flash_set('success', 'Welcome to linkdir! Your account has been created.');
                header('Location: /dashboard');
                exit;
            } catch (PDOException $e) {
                error_log('Registration Error: ' . $e->getMessage());
                $errors[] = 'An unexpected error occurred while creating your account. Please try again.';
            }
        }
    }
}

$pageTitle = 'Create an Account';
$pageDescription = 'Register on linkdir to submit and manage your business listings or write verified reviews.';
require_once __DIR__ . '/includes/header.php';
?>

<div class="container my-5">
    <div class="row justify-content-center">
        <div class="col-md-7 col-lg-5">
            <div class="card shadow-sm border-1 p-4 p-md-5">
                <div class="text-center mb-4">
                    <i class="bi bi-person-plus text-primary fs-1"></i>
                    <h1 class="h3 fw-bold mt-2 mb-1">Create an Account</h1>
                    <p class="text-muted small">Manage your business listings and customer reviews</p>
                </div>

                <?= flash_render() ?>

                <?php if (!empty($errors)): ?>
                    <div class="alert alert-danger mb-4">
                        <ul class="mb-0 ps-3 small">
                            <?php foreach ($errors as $err): ?>
                                <li><?= e($err) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form action="/register" method="POST">
                    <?= csrf_field() ?>
                    <?= honeypot_field() ?>

                    <div class="mb-3">
                        <label for="name" class="form-label small fw-semibold text-muted">Full Name or Representative Name</label>
                        <input type="text" class="form-control" id="name" name="name" value="<?= e($name) ?>" required autocomplete="name" placeholder="Jane Doe">
                    </div>

                    <div class="mb-3">
                        <label for="email" class="form-label small fw-semibold text-muted">Email Address</label>
                        <input type="email" class="form-control" id="email" name="email" value="<?= e($email) ?>" required autocomplete="email" placeholder="jane@example.com">
                    </div>

                    <div class="mb-3">
                        <label for="password" class="form-label small fw-semibold text-muted">Password (min. 8 characters)</label>
                        <input type="password" class="form-control" id="password" name="password" required autocomplete="new-password" minlength="8" placeholder="••••••••">
                    </div>

                    <div class="mb-3">
                        <label for="confirm_password" class="form-label small fw-semibold text-muted">Confirm Password</label>
                        <input type="password" class="form-control" id="confirm_password" name="confirm_password" required autocomplete="new-password" minlength="8" placeholder="••••••••">
                    </div>

                    <?= captcha_field() ?>

                    <button type="submit" class="btn btn-primary w-100 py-2 fw-semibold">
                        Register Account
                    </button>
                </form>

                <div class="text-center mt-4 pt-3 border-top small text-muted">
                    Already have an account? <a href="/login" class="text-primary text-decoration-none fw-semibold">Log in here</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
