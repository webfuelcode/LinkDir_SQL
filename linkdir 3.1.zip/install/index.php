<?php
/**
 * linkdir - Installation & Environment Health Wizard
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

$db = get_db();
$message = '';
$messageType = '';

// Handle Seeding / Setup trigger
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action_seed'])) {
    try {
        // Run sqlite schema bootstrap only if sqlite is active
        if (DB_DRIVER === 'sqlite') {
            bootstrap_sqlite_schema($db);
        }

        // Check if admin user exists
        $chkAdmin = $db->prepare("SELECT id FROM users WHERE email = ? LIMIT 1");
        $chkAdmin->execute(['admin@linkdir.local']);
        if (!$chkAdmin->fetch()) {
            $adminPass = password_hash('AdminPass123!', PASSWORD_DEFAULT);
            $db->prepare("INSERT INTO users (name, email, password_hash, role, status, created_at) VALUES ('Site Administrator', 'admin@linkdir.local', ?, 'admin', 'active', CURRENT_TIMESTAMP)")
               ->execute([$adminPass]);
        }

        // Check if regular demo user exists
        $chkUser = $db->prepare("SELECT id FROM users WHERE email = ? LIMIT 1");
        $chkUser->execute(['user@linkdir.local']);
        if (!$chkUser->fetch()) {
            $userPass = password_hash('UserPass123!', PASSWORD_DEFAULT);
            $db->prepare("INSERT INTO users (name, email, password_hash, role, status, created_at) VALUES ('Sarah Jenkins', 'user@linkdir.local', ?, 'user', 'active', CURRENT_TIMESTAMP)")
               ->execute([$userPass]);
        }

        // Check if sample businesses exist
        $bizCount = (int)$db->query("SELECT COUNT(*) FROM businesses")->fetchColumn();
        if ($bizCount === 0) {
            $sampleBiz = [
                [
                    'user_id' => 1,
                    'category_id' => 2, // Home & Trade Services
                    'business_name' => 'Highland Heating & Air Conditioning',
                    'slug' => 'highland-heating-air-conditioning',
                    'website_url' => 'https://example.com/highland-hvac',
                    'about' => "Highland Heating & Air Conditioning provides 24/7 residential and light commercial HVAC maintenance, heat pump installations, and duct cleaning across Austin and Travis County. Family-owned and operated with over 18 years of licensed experience.",
                    'phone' => '(512) 555-0192',
                    'email' => 'service@highlandhvac.local',
                    'address' => '4402 Industrial Blvd, Suite B',
                    'city' => 'Austin',
                    'state' => 'TX',
                    'country' => 'United States',
                    'status' => 'approved'
                ],
                [
                    'user_id' => 2,
                    'category_id' => 1, // Restaurants & Dining
                    'business_name' => 'Saffron Table Bistro',
                    'slug' => 'saffron-table-bistro',
                    'website_url' => 'https://example.com/saffron-table',
                    'about' => "Artisanal Mediterranean dining featuring organic wood-fired flatbreads, house-made pastas, and local wine pairings. Perfect for casual lunches or celebratory family dinners.",
                    'phone' => '(512) 555-8821',
                    'email' => 'reservations@saffrontable.local',
                    'address' => '118 E 6th Street',
                    'city' => 'Austin',
                    'state' => 'TX',
                    'country' => 'United States',
                    'status' => 'approved'
                ],
                [
                    'user_id' => 1,
                    'category_id' => 3, // Health & Medical
                    'business_name' => 'Barton Springs Family Dental Care',
                    'slug' => 'barton-springs-family-dental-care',
                    'website_url' => 'https://example.com/bartondental',
                    'about' => "Comprehensive dental care for adults and children. Services include teeth cleanings, painless cavity fillings, invisalign orthodontics, and cosmetic teeth whitening.",
                    'phone' => '(512) 555-3419',
                    'email' => 'hello@bartondental.local',
                    'address' => '2201 S Lamar Blvd',
                    'city' => 'Austin',
                    'state' => 'TX',
                    'country' => 'United States',
                    'status' => 'approved'
                ],
                [
                    'user_id' => 2,
                    'category_id' => 4, // Automotive Services
                    'business_name' => 'Precision European Auto Repair',
                    'slug' => 'precision-european-auto-repair',
                    'website_url' => 'https://example.com/precisionauto',
                    'about' => "ASE-certified technicians specializing in BMW, Audi, Mercedes-Benz, and Volkswagen service. Brake diagnostics, transmission fluid flushes, oil changes, and electrical troubleshooting.",
                    'phone' => '(512) 555-9014',
                    'email' => 'techs@precisioneuro.local',
                    'address' => '8204 Research Blvd',
                    'city' => 'Austin',
                    'state' => 'TX',
                    'country' => 'United States',
                    'status' => 'approved'
                ],
                [
                    'user_id' => 1,
                    'category_id' => 5, // Professional & Legal
                    'business_name' => 'Summit Hill Financial Planning',
                    'slug' => 'summit-hill-financial-planning',
                    'website_url' => 'https://example.com/summithill',
                    'about' => "Fee-only fiduciary financial advisors helping small business owners, retirees, and young families optimize wealth management, estate planning, and tax strategy.",
                    'phone' => '(512) 555-4567',
                    'email' => 'info@summithill.local',
                    'address' => '701 Brazos St, Suite 1200',
                    'city' => 'Austin',
                    'state' => 'TX',
                    'country' => 'United States',
                    'status' => 'approved'
                ],
                [
                    'user_id' => 2,
                    'category_id' => 2, // Home & Trade Services
                    'business_name' => 'Lone Star Master Plumbers',
                    'slug' => 'lone-star-master-plumbers',
                    'website_url' => 'https://example.com/lonestarplumbing',
                    'about' => "Emergency plumbing repairs, water heater installation (tankless and traditional), drain clearing, and sewer line camera inspections. Transparent upfront pricing.",
                    'phone' => '(512) 555-7733',
                    'email' => 'dispatch@lonestarplumbing.local',
                    'address' => '3104 E 12th St',
                    'city' => 'Austin',
                    'state' => 'TX',
                    'country' => 'United States',
                    'status' => 'approved'
                ]
            ];

            $insertStmt = $db->prepare("
                INSERT INTO businesses (
                    user_id, category_id, business_name, slug, website_url, about,
                    phone, email, address, city, state, country, status, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, '', ?, ?, ?, CURRENT_TIMESTAMP)
            ");

            foreach ($sampleBiz as $sb) {
                $insertStmt->execute([
                    $sb['user_id'], $sb['category_id'], $sb['business_name'], $sb['slug'],
                    $sb['website_url'], $sb['about'], $sb['phone'], $sb['email'],
                    $sb['address'], $sb['state'], $sb['country'], $sb['status']
                ]);
            }

            // Add sample customer reviews
            $sampleReviews = [
                ['business_id' => 1, 'user_id' => 2, 'rating' => 5, 'review_text' => 'Highland HVAC fixed our AC compressor on the same day during a 100-degree heatwave. Very professional and tidy technician!'],
                ['business_id' => 2, 'user_id' => 1, 'rating' => 5, 'review_text' => 'The lamb flatbread and wood-fired seafood pasta were outstanding. Great ambiance and attentive staff.'],
                ['business_id' => 3, 'user_id' => 2, 'rating' => 5, 'review_text' => 'Barton Springs Dental made my routine cleaning completely stress-free. Very gentle hygienist.'],
                ['business_id' => 4, 'user_id' => 1, 'rating' => 4, 'review_text' => 'Diagnosed an intermittent check engine light on my BMW in under an hour. Solid communication throughout.'],
                ['business_id' => 6, 'user_id' => 1, 'rating' => 5, 'review_text' => 'Arrived within 45 minutes to unclog a main bathroom line. Cleaned up afterward and explained prevention tips.']
            ];

            $revStmt = $db->prepare("INSERT INTO reviews (business_id, user_id, rating, review_text, status, created_at) VALUES (?, ?, ?, ?, 'approved', CURRENT_TIMESTAMP)");
            foreach ($sampleReviews as $sr) {
                $revStmt->execute([$sr['business_id'], $sr['user_id'], $sr['rating'], $sr['review_text']]);
            }
        }

        $message = 'Database initialized successfully with sample directory listings, reviews, and test credentials!';
        $messageType = 'success';
    } catch (Exception $e) {
        $message = 'Initialization failed: ' . $e->getMessage();
        $messageType = 'danger';
    }
}

// Environmental checks
$checks = [
    'PHP Version >= 8.2' => [
        'pass' => version_compare(PHP_VERSION, '8.2.0', '>='),
        'detail' => 'Running PHP ' . PHP_VERSION
    ],
    'PDO Extension' => [
        'pass' => extension_loaded('pdo'),
        'detail' => extension_loaded('pdo') ? 'Loaded' : 'Missing pdo extension'
    ],
    'Database Driver (MySQL or SQLite)' => [
        'pass' => extension_loaded('pdo_mysql') || extension_loaded('pdo_sqlite'),
        'detail' => 'Active driver: ' . $db->getAttribute(PDO::ATTR_DRIVER_NAME)
    ],
    'GD Graphic Library (Image Resizing)' => [
        'pass' => extension_loaded('gd'),
        'detail' => extension_loaded('gd') ? 'Loaded' : 'Recommended for image resizing'
    ],
    'Uploads Directory Writable' => [
        'pass' => is_writable(UPLOAD_DIR),
        'detail' => UPLOAD_DIR . (is_writable(UPLOAD_DIR) ? ' is writable' : ' is not writable')
    ],
    'Apache URL Rewrite (.htaccess)' => [
        'pass' => file_exists(__DIR__ . '/../.htaccess'),
        'detail' => file_exists(__DIR__ . '/../.htaccess') ? 'Configured for clean URLs' : 'Missing .htaccess'
    ]
];

$pageTitle = 'Setup & Health Check';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="container my-5">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card shadow-sm border-1 p-4 p-md-5">
                <div class="d-flex align-items-center gap-3 mb-4 border-bottom pb-3">
                    <i class="bi bi-gear-wide-connected text-primary fs-1"></i>
                    <div>
                        <h1 class="h3 fw-bold mb-0">linkdir System &amp; Hosting Setup</h1>
                        <p class="text-muted small mb-0">Hosting environment verification and initial directory seeding</p>
                    </div>
                </div>

                <?php if ($message): ?>
                    <div class="alert alert-<?= $messageType ?> mb-4">
                        <?= e($message) ?>
                    </div>
                <?php endif; ?>

                <h5 class="fw-bold mb-3">1. Server Environment Compatibility</h5>
                <ul class="list-group mb-4">
                    <?php foreach ($checks as $title => $check): ?>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <div>
                                <strong><?= e($title) ?></strong>
                                <div class="small text-muted"><?= e($check['detail']) ?></div>
                            </div>
                            <?php if ($check['pass']): ?>
                                <span class="badge bg-success-subtle text-success border border-success-subtle px-3 py-2">
                                    <i class="bi bi-check-circle-fill me-1"></i> Pass
                                </span>
                            <?php else: ?>
                                <span class="badge bg-danger-subtle text-danger border border-danger-subtle px-3 py-2">
                                    <i class="bi bi-x-circle-fill me-1"></i> Fail
                                </span>
                            <?php endif; ?>
                        </li>
                    <?php endforeach; ?>
                </ul>

                <h5 class="fw-bold mb-3">2. Demo &amp; Administrator Credentials</h5>
                <div class="card bg-light border p-3 mb-4">
                    <div class="row g-3 small">
                        <div class="col-sm-6">
                            <strong class="text-danger d-block mb-1"><i class="bi bi-shield-lock me-1"></i>Administrator Account</strong>
                            <div>Email: <code>admin@linkdir.local</code></div>
                            <div>Password: <code>AdminPass123!</code></div>
                            <div class="text-muted mt-1" style="font-size:0.75rem;">Full access to admin panel, listing approvals, category CRUD, and review moderation.</div>
                        </div>
                        <div class="col-sm-6">
                            <strong class="text-primary d-block mb-1"><i class="bi bi-person me-1"></i>Sample Business Owner</strong>
                            <div>Email: <code>user@linkdir.local</code></div>
                            <div>Password: <code>UserPass123!</code></div>
                            <div class="text-muted mt-1" style="font-size:0.75rem;">Can create listings, edit owned businesses, and write customer reviews.</div>
                        </div>
                    </div>
                </div>

                <h5 class="fw-bold mb-3">3. Database Seeding &amp; Sample Data</h5>
                <p class="text-muted small">
                    Clicking the button below verifies the required database tables and populates sample categories, verified business listings, and customer reviews.
                </p>

                <form action="/install" method="POST" class="d-flex gap-2">
                    <input type="hidden" name="action_seed" value="1">
                    <button type="submit" class="btn btn-primary px-4 py-2 fw-semibold">
                        <i class="bi bi-database-fill-check me-1"></i> Initialize Database &amp; Seed Data
                    </button>
                    <a href="/" class="btn btn-outline-secondary px-3 py-2">
                        View Directory
                    </a>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
