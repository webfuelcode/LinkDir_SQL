<?php
/**
 * linkdir - Configuration Template
 * 
 * Copy this file to `config.php` and customize your database credentials
 * for shared hosting (cPanel) or local development.
 */

// Environment & Error Reporting (Set false in production)
define('APP_DEBUG', false);

// Database Driver ('mysql' for cPanel / MariaDB, 'sqlite' for portable file storage)
define('DB_DRIVER', 'mysql');

// MySQL / MariaDB Settings (Used when DB_DRIVER === 'mysql')
define('DB_HOST', 'localhost');
define('DB_PORT', '3306');
define('DB_NAME', 'cpaneluser_linkdir');
define('DB_USER', 'cpaneluser_linkdiruser');
define('DB_PASS', 'YourSecurePasswordHere123!');
define('DB_CHARSET', 'utf8mb4');

// SQLite Settings (Used if DB_DRIVER === 'sqlite')
define('DB_SQLITE_PATH', __DIR__ . '/../data/linkdir.sqlite');

// Application Info
define('SITE_NAME', 'linkdir');
define('SITE_TAGLINE', 'Find Trusted Local Businesses & Services');
define('SITE_EMAIL', 'noreply@example.com');

// Site URL (Leave empty for automatic base URL detection)
define('SITE_URL', '');

// Directory Settings
define('REQUIRE_BUSINESS_APPROVAL', true);   // Set to true to require admin approval for listings
define('REQUIRE_REVIEW_APPROVAL', false);    // Set to true to require review moderation before display
define('ITEMS_PER_PAGE', 12);

// Image Uploads
define('UPLOAD_DIR', __DIR__ . '/../uploads/businesses');
define('UPLOAD_URL', '/uploads/businesses');
define('MAX_UPLOAD_SIZE_BYTES', 2 * 1024 * 1024); // 2 MB
define('ALLOWED_EXTENSIONS', ['jpg', 'jpeg', 'png', 'webp']);
define('MAX_IMAGE_WIDTH', 800);
define('MAX_IMAGE_HEIGHT', 800);

// Security & Rate Limiting
define('RATE_LIMIT_LOGIN_ATTEMPTS', 5);
define('RATE_LIMIT_LOGIN_WINDOW', 900); // 15 minutes lockout
define('CAPTCHA_EXPIRY_SECONDS', 300);  // 5 minutes
