<?php
/**
 * linkdir - Application Configuration
 */

// Error reporting
define('APP_DEBUG', true);
if (APP_DEBUG) {
    ini_set('display_errors', '0'); // Do not expose PHP errors in response body
    ini_set('log_errors', '1');
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', '0');
    ini_set('log_errors', '1');
    error_reporting(0);
}

// Database Driver ('mysql' or 'sqlite')
// In this container preview environment, default to sqlite so it runs instantly.
// On cPanel, switch DB_DRIVER to 'mysql' and fill in MySQL credentials.
$envDriver = getenv('DB_DRIVER') ?: 'sqlite';
define('DB_DRIVER', $envDriver);

// MySQL / MariaDB Settings
define('DB_HOST', getenv('DB_HOST') ?: '127.0.0.1');
define('DB_PORT', getenv('DB_PORT') ?: '3306');
define('DB_NAME', getenv('DB_NAME') ?: 'linkdir');
define('DB_USER', getenv('DB_USER') ?: 'root');
define('DB_PASS', getenv('DB_PASS') ?: '');
define('DB_CHARSET', 'utf8mb4');

// SQLite Path
define('DB_SQLITE_PATH', __DIR__ . '/../data/linkdir.sqlite');

// Application Info
define('SITE_NAME', 'linkdir');
define('SITE_TAGLINE', 'Find Trusted Local Businesses & Services');
define('SITE_EMAIL', 'admin@linkdir.local');

// Base URL (auto-detected if empty)
define('SITE_URL', '');

// Directory Policies
define('REQUIRE_BUSINESS_APPROVAL', true);
define('REQUIRE_REVIEW_APPROVAL', false);
define('ITEMS_PER_PAGE', 12);

// Uploads
define('UPLOAD_DIR', __DIR__ . '/../uploads/businesses');
define('UPLOAD_URL', '/uploads/businesses');
define('MAX_UPLOAD_SIZE_BYTES', 2 * 1024 * 1024); // 2 MB
define('ALLOWED_EXTENSIONS', ['jpg', 'jpeg', 'png', 'webp']);
define('MAX_IMAGE_WIDTH', 800);
define('MAX_IMAGE_HEIGHT', 800);

// Security
define('RATE_LIMIT_LOGIN_ATTEMPTS', 5);
define('RATE_LIMIT_LOGIN_WINDOW', 900);
define('CAPTCHA_EXPIRY_SECONDS', 300);
