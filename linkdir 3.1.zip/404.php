<?php
/**
 * linkdir - 404 Not Found Page
 */

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

$pageTitle = 'Page Not Found (404)';
require_once __DIR__ . '/includes/header.php';
?>

<div class="container my-5 py-5 text-center">
    <div class="row justify-content-center">
        <div class="col-md-7 col-lg-6">
            <i class="bi bi-geo-alt-fill text-muted opacity-50" style="font-size: 5rem;"></i>
            <h1 class="display-5 fw-bold text-dark mt-3">404 - Page Not Found</h1>
            <p class="lead text-muted mb-4">
                The business listing, category, or page you were looking for doesn't exist or may have been removed.
            </p>

            <div class="card p-3 mb-4 shadow-sm">
                <form action="/businesses" method="GET" class="d-flex gap-2">
                    <input type="text" name="q" class="form-control" placeholder="Search businesses or services...">
                    <button type="submit" class="btn btn-primary px-3">Search</button>
                </form>
            </div>

            <div class="d-flex justify-content-center gap-3">
                <a href="/" class="btn btn-outline-secondary">Go to Homepage</a>
                <a href="/businesses" class="btn btn-primary">Browse All Listings</a>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
