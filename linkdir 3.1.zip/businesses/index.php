<?php
/**
 * linkdir - Business Directory Page (Search, Filter, Sort, Pagination)
 * Clean modern interface with instant filter updates, no state/region, and ad placements.
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';

$db = get_db();

// Filter parameters (No city, No state/region)
$search = trim($_GET['q'] ?? '');
$categorySlug = trim($_GET['category'] ?? '');
$sort = trim($_GET['sort'] ?? 'newest');
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = ITEMS_PER_PAGE;
$offset = ($page - 1) * $perPage;

// Fetch active categories for dropdown & sidebar
$categories = $db->query("
    SELECT c.id, c.name, c.slug, c.icon, COUNT(b.id) as b_count
    FROM categories c
    LEFT JOIN businesses b ON b.category_id = c.id AND b.status = 'approved'
    WHERE c.status = 'active'
    GROUP BY c.id, c.name, c.slug, c.icon
    ORDER BY c.name ASC
")->fetchAll();

// Build query
$where = ["b.status = 'approved'"];
$params = [];

if ($search !== '') {
    $where[] = "(b.business_name LIKE ? OR b.about LIKE ?)";
    $term = '%' . $search . '%';
    $params[] = $term;
    $params[] = $term;
}

if ($categorySlug !== '') {
    $where[] = "c.slug = ?";
    $params[] = $categorySlug;
}

$whereClause = implode(' AND ', $where);

// Count total matching items
$countSql = "
    SELECT COUNT(b.id)
    FROM businesses b
    JOIN categories c ON b.category_id = c.id
    WHERE {$whereClause}
";
$countStmt = $db->prepare($countSql);
$countStmt->execute($params);
$totalItems = (int)$countStmt->fetchColumn();
$totalPages = ceil($totalItems / $perPage);

// Sorting logic
$orderBy = "b.created_at DESC";
switch ($sort) {
    case 'rating':
        $orderBy = "avg_rating DESC, review_count DESC, b.business_name ASC";
        break;
    case 'updated':
        $orderBy = "b.updated_at DESC";
        break;
    case 'name':
        $orderBy = "b.business_name ASC";
        break;
    case 'newest':
    default:
        $orderBy = "b.created_at DESC";
        break;
}

// Fetch records
$dataSql = "
    SELECT b.id, b.business_name, b.slug, b.logo, b.about, b.country, b.created_at, b.updated_at,
           c.name as category_name, c.slug as category_slug,
           COALESCE(AVG(r.rating), 0) as avg_rating,
           COUNT(r.id) as review_count
    FROM businesses b
    JOIN categories c ON b.category_id = c.id
    LEFT JOIN reviews r ON r.business_id = b.id AND r.status = 'approved'
    WHERE {$whereClause}
    GROUP BY b.id, b.business_name, b.slug, b.logo, b.about, b.country, b.created_at, b.updated_at, c.name, c.slug
    ORDER BY {$orderBy}
    LIMIT {$perPage} OFFSET {$offset}
";
$dataStmt = $db->prepare($dataSql);
$dataStmt->execute($params);
$businesses = $dataStmt->fetchAll();

// Construct base query string for pagination links
$queryParams = $_GET;
unset($queryParams['page']);
$baseQuery = http_build_query($queryParams);

// -------------------------------------------------------------
// HTMX Partial Response (When called via HTMX AJAX)
// -------------------------------------------------------------
if (is_htmx()) {
    ?>
    <div id="businesses-results">
        <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
            <p class="text-muted small mb-0">
                Showing <strong class="text-dark"><?= count($businesses) ?></strong> of <strong class="text-dark"><?= $totalItems ?></strong> <?= ($totalItems === 1 ? 'business' : 'businesses') ?>
                <?php if ($search !== ''): ?> matching &ldquo;<strong><?= e($search) ?></strong>&rdquo;<?php endif; ?>
                <?php if ($categorySlug !== ''): ?>
                    <?php 
                        $activeCatName = '';
                        foreach ($categories as $c) {
                            if ($c['slug'] === $categorySlug) { $activeCatName = $c['name']; break; }
                        }
                    ?>
                    in <span class="badge bg-primary-subtle text-primary border border-primary-subtle"><?= e($activeCatName ?: $categorySlug) ?></span>
                <?php endif; ?>
            </p>
            <?php if ($totalPages > 1): ?>
                <span class="text-muted small">Page <?= $page ?> of <?= $totalPages ?></span>
            <?php endif; ?>
        </div>

        <?php if (!empty($businesses)): ?>
            <div class="row g-3 mb-4">
                <?php foreach ($businesses as $biz): ?>
                    <?php require __DIR__ . '/../includes/business-card.php'; ?>
                <?php endforeach; ?>
            </div>

            <!-- Pagination -->
            <?php if ($totalPages > 1): ?>
                <nav aria-label="Directory pagination" class="mt-4">
                    <ul class="pagination justify-content-center">
                        <li class="page-item <?= ($page <= 1 ? 'disabled' : '') ?>">
                            <a class="page-link" href="/businesses?<?= $baseQuery ?>&page=<?= ($page - 1) ?>"
                               hx-get="/businesses?<?= $baseQuery ?>&page=<?= ($page - 1) ?>"
                               hx-target="#businesses-results"
                               hx-swap="outerHTML"
                               hx-push-url="true"
                               hx-indicator="#search-indicator">
                                <i class="bi bi-chevron-left me-1"></i>Prev
                            </a>
                        </li>

                        <?php for ($i = max(1, $page - 2); $i <= min($totalPages, $page + 2); $i++): ?>
                            <li class="page-item <?= ($i === $page ? 'active' : '') ?>">
                                <a class="page-link" href="/businesses?<?= $baseQuery ?>&page=<?= $i ?>"
                                   hx-get="/businesses?<?= $baseQuery ?>&page=<?= $i ?>"
                                   hx-target="#businesses-results"
                                   hx-swap="outerHTML"
                                   hx-push-url="true"
                                   hx-indicator="#search-indicator">
                                    <?= $i ?>
                                </a>
                            </li>
                        <?php endfor; ?>

                        <li class="page-item <?= ($page >= $totalPages ? 'disabled' : '') ?>">
                            <a class="page-link" href="/businesses?<?= $baseQuery ?>&page=<?= ($page + 1) ?>"
                               hx-get="/businesses?<?= $baseQuery ?>&page=<?= ($page + 1) ?>"
                               hx-target="#businesses-results"
                               hx-swap="outerHTML"
                               hx-push-url="true"
                               hx-indicator="#search-indicator">
                                Next<i class="bi bi-chevron-right ms-1"></i>
                            </a>
                        </li>
                    </ul>
                </nav>
            <?php endif; ?>

        <?php else: ?>
            <div class="card p-5 text-center bg-white border-1 shadow-xs">
                <div class="category-icon mx-auto mb-3" style="width: 54px; height: 54px;">
                    <i class="bi bi-search fs-4"></i>
                </div>
                <h5 class="text-dark fw-bold mb-1">No businesses found</h5>
                <p class="text-muted small mb-3">Try refining your search keyword or clearing the active filters.</p>
                <div>
                    <a href="/businesses" class="btn btn-outline-primary btn-sm">
                        <i class="bi bi-arrow-counterclockwise me-1"></i>Reset All Filters
                    </a>
                </div>
            </div>
        <?php endif; ?>
    </div>
    <?php
    exit;
}

// -------------------------------------------------------------
// Full Page Rendering (Initial GET Request)
// -------------------------------------------------------------
$pageTitle = 'Explore Business Directory';
if ($categorySlug !== '') {
    foreach ($categories as $c) {
        if ($c['slug'] === $categorySlug) {
            $pageTitle = $c['name'] . ' - Business Directory';
            break;
        }
    }
}
$pageDescription = 'Search and filter verified companies, services, and client reviews on linkdir.';

require_once __DIR__ . '/../includes/header.php';
?>

<div class="container py-4 mb-5">
    <!-- Breadcrumb -->
    <nav aria-label="breadcrumb" class="mb-3">
        <ol class="breadcrumb small mb-0">
            <li class="breadcrumb-item"><a href="/"><i class="bi bi-house me-1"></i>Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">Explore Directory</li>
        </ol>
    </nav>

    <!-- Page Header Banner -->
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-3">
        <div>
            <h1 class="h3 fw-bold text-dark mb-1">Explore Directory</h1>
            <p class="text-muted small mb-0">Search and discover verified businesses, contractors, and specialized services.</p>
        </div>
        <div>
            <a href="<?= auth_check() ? '/dashboard/business/add' : '/login?redirect=/dashboard/business/add' ?>" class="btn btn-primary btn-sm">
                <i class="bi bi-plus-lg me-1"></i>
                <span>Add Your Listing</span>
            </a>
        </div>
    </div>

    <!-- Leaderboard Ad Slot (728x90) -->
    <?= render_ad('leaderboard_top', 'mb-4') ?>

    <div class="row g-4">
        <!-- Main Directory Area (Left Column) -->
        <div class="col-lg-8 col-xl-9">
            <!-- Filter Bar Card -->
            <div class="card p-3 mb-4 shadow-xs border-1 position-relative">
                <form id="filter-form" action="/businesses" method="GET"
                      hx-get="/businesses"
                      hx-trigger="submit, change from:select"
                      hx-target="#businesses-results"
                      hx-swap="outerHTML"
                      hx-push-url="true"
                      hx-indicator="#search-indicator">

                    <div class="row g-2 align-items-end">
                        <!-- Search Keyword (Auto-refreshes on typing or pressing enter) -->
                        <div class="col-md-5">
                            <label class="form-label small fw-semibold text-muted mb-1">Search Keywords</label>
                            <div class="input-group">
                                <span class="input-group-text bg-white border-end-0 text-muted"><i class="bi bi-search"></i></span>
                                <input type="text" name="q" id="search-input" class="form-control border-start-0" 
                                       placeholder="Business name, service..." 
                                       value="<?= e($search) ?>" 
                                       autocomplete="off"
                                       hx-get="/businesses"
                                       hx-trigger="input changed delay:350ms, search"
                                       hx-target="#businesses-results"
                                       hx-swap="outerHTML"
                                       hx-include="#filter-form"
                                       hx-push-url="true"
                                       hx-indicator="#search-indicator">
                            </div>
                        </div>

                        <!-- Category Selector -->
                        <div class="col-md-3">
                            <label class="form-label small fw-semibold text-muted mb-1">Category</label>
                            <select name="category" id="category-select" class="form-select">
                                <option value="">All Categories</option>
                                <?php foreach ($categories as $c): ?>
                                    <option value="<?= e($c['slug']) ?>" <?= ($categorySlug === $c['slug'] ? 'selected' : '') ?>>
                                        <?= e($c['name']) ?> (<?= $c['b_count'] ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <!-- Sort By Selector -->
                        <div class="col-md-2">
                            <label class="form-label small fw-semibold text-muted mb-1">Sort By</label>
                            <select name="sort" class="form-select">
                                <option value="newest" <?= ($sort === 'newest' ? 'selected' : '') ?>>Newest</option>
                                <option value="rating" <?= ($sort === 'rating' ? 'selected' : '') ?>>Highest Rated</option>
                                <option value="updated" <?= ($sort === 'updated' ? 'selected' : '') ?>>Updated</option>
                                <option value="name" <?= ($sort === 'name' ? 'selected' : '') ?>>Name (A-Z)</option>
                            </select>
                        </div>

                        <!-- Action Buttons (Search & Reset) -->
                        <div class="col-md-2 d-flex gap-1">
                            <button type="submit" class="btn btn-primary btn-sm w-100 d-flex align-items-center justify-content-center gap-1" style="height: 38px;">
                                <i class="bi bi-search"></i>
                                <span>Filter</span>
                            </button>
                            <a href="/businesses" class="btn btn-outline-secondary btn-sm d-flex align-items-center justify-content-center" style="height: 38px;" title="Reset Filters">
                                <i class="bi bi-x-lg"></i>
                            </a>
                        </div>
                    </div>
                </form>

                <!-- Search Activity Loading Indicator -->
                <div id="search-indicator" class="htmx-indicator position-absolute top-50 start-50 translate-middle p-2 bg-white rounded-pill shadow border">
                    <div class="d-flex align-items-center gap-2 px-2">
                        <div class="spinner-border spinner-border-sm text-primary" role="status"></div>
                        <span class="small fw-semibold text-secondary">Updating listings...</span>
                    </div>
                </div>
            </div>

            <!-- Results Block (Replaced via HTMX) -->
            <div id="businesses-results">
                <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
                    <p class="text-muted small mb-0">
                        Showing <strong class="text-dark"><?= count($businesses) ?></strong> of <strong class="text-dark"><?= $totalItems ?></strong> <?= ($totalItems === 1 ? 'business' : 'businesses') ?>
                        <?php if ($search !== ''): ?> matching &ldquo;<strong><?= e($search) ?></strong>&rdquo;<?php endif; ?>
                        <?php if ($categorySlug !== ''): ?>
                            <?php 
                                $activeCatName = '';
                                foreach ($categories as $c) {
                                    if ($c['slug'] === $categorySlug) { $activeCatName = $c['name']; break; }
                                }
                            ?>
                            in <span class="badge bg-primary-subtle text-primary border border-primary-subtle"><?= e($activeCatName ?: $categorySlug) ?></span>
                        <?php endif; ?>
                    </p>
                    <?php if ($totalPages > 1): ?>
                        <span class="text-muted small">Page <?= $page ?> of <?= $totalPages ?></span>
                    <?php endif; ?>
                </div>

                <?php if (!empty($businesses)): ?>
                    <div class="row g-3 mb-4">
                        <?php foreach ($businesses as $biz): ?>
                            <?php require __DIR__ . '/../includes/business-card.php'; ?>
                        <?php endforeach; ?>
                    </div>

                    <!-- Pagination -->
                    <?php if ($totalPages > 1): ?>
                        <nav aria-label="Directory pagination" class="mt-4">
                            <ul class="pagination justify-content-center">
                                <li class="page-item <?= ($page <= 1 ? 'disabled' : '') ?>">
                                    <a class="page-link" href="/businesses?<?= $baseQuery ?>&page=<?= ($page - 1) ?>"
                                       hx-get="/businesses?<?= $baseQuery ?>&page=<?= ($page - 1) ?>"
                                       hx-target="#businesses-results"
                                       hx-swap="outerHTML"
                                       hx-push-url="true"
                                       hx-indicator="#search-indicator">
                                        <i class="bi bi-chevron-left me-1"></i>Prev
                                    </a>
                                </li>

                                <?php for ($i = max(1, $page - 2); $i <= min($totalPages, $page + 2); $i++): ?>
                                    <li class="page-item <?= ($i === $page ? 'active' : '') ?>">
                                        <a class="page-link" href="/businesses?<?= $baseQuery ?>&page=<?= $i ?>"
                                           hx-get="/businesses?<?= $baseQuery ?>&page=<?= $i ?>"
                                           hx-target="#businesses-results"
                                           hx-swap="outerHTML"
                                           hx-push-url="true"
                                           hx-indicator="#search-indicator">
                                            <?= $i ?>
                                        </a>
                                    </li>
                                <?php endfor; ?>

                                <li class="page-item <?= ($page >= $totalPages ? 'disabled' : '') ?>">
                                    <a class="page-link" href="/businesses?<?= $baseQuery ?>&page=<?= ($page + 1) ?>"
                                       hx-get="/businesses?<?= $baseQuery ?>&page=<?= ($page + 1) ?>"
                                       hx-target="#businesses-results"
                                       hx-swap="outerHTML"
                                       hx-push-url="true"
                                       hx-indicator="#search-indicator">
                                        Next<i class="bi bi-chevron-right ms-1"></i>
                                    </a>
                                </li>
                            </ul>
                        </nav>
                    <?php endif; ?>

                <?php else: ?>
                    <div class="card p-5 text-center bg-white border-1 shadow-xs">
                        <div class="category-icon mx-auto mb-3" style="width: 54px; height: 54px;">
                            <i class="bi bi-search fs-4"></i>
                        </div>
                        <h5 class="text-dark fw-bold mb-1">No businesses found</h5>
                        <p class="text-muted small mb-3">Try refining your search keyword or clearing the active filters.</p>
                        <div>
                            <a href="/businesses" class="btn btn-outline-primary btn-sm">
                                <i class="bi bi-arrow-counterclockwise me-1"></i>Reset All Filters
                            </a>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Sidebar Area (Right Column) -->
        <div class="col-lg-4 col-xl-3">
            <!-- Sidebar Ad Slot (300x250) -->
            <?= render_ad('sidebar_directory', 'mb-4') ?>

            <!-- Categories Quick Navigation -->
            <div class="card shadow-xs border-1 p-3 mb-4">
                <h3 class="h6 fw-bold text-dark mb-3 pb-2 border-bottom d-flex align-items-center gap-2">
                    <i class="bi bi-grid text-primary"></i>
                    <span>Browse Categories</span>
                </h3>
                <div class="d-flex flex-column gap-1">
                    <a href="/businesses" class="d-flex justify-content-between align-items-center text-decoration-none py-1 px-2 rounded <?= $categorySlug === '' ? 'bg-primary text-white fw-bold' : 'text-secondary hover-bg-light' ?> small">
                        <span>All Categories</span>
                        <span class="badge <?= $categorySlug === '' ? 'bg-white text-primary' : 'bg-light text-muted' ?>"><?= $totalItems ?></span>
                    </a>
                    <?php foreach ($categories as $cat): ?>
                        <a href="/businesses?category=<?= e($cat['slug']) ?>" 
                           class="d-flex justify-content-between align-items-center text-decoration-none py-1 px-2 rounded <?= $categorySlug === $cat['slug'] ? 'bg-primary text-white fw-bold' : 'text-secondary hover-bg-light' ?> small">
                            <span class="text-truncate me-2"><i class="bi <?= e($cat['icon'] ?: 'bi-tag') ?> me-1"></i><?= e($cat['name']) ?></span>
                            <span class="badge <?= $categorySlug === $cat['slug'] ? 'bg-white text-primary' : 'bg-light text-muted' ?>"><?= $cat['b_count'] ?></span>
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Get Listed Callout Card -->
            <div class="card bg-primary-subtle border border-primary-subtle p-3 text-center">
                <div class="mb-2">
                    <i class="bi bi-shop fs-3 text-primary"></i>
                </div>
                <h4 class="h6 fw-bold text-dark mb-1">Own a local business?</h4>
                <p class="text-muted small mb-3">Add your free listing to connect with clients, collect customer reviews, and boost visibility.</p>
                <a href="<?= auth_check() ? '/dashboard/business/add' : '/login?redirect=/dashboard/business/add' ?>" class="btn btn-primary btn-sm w-100">
                    <i class="bi bi-plus-circle me-1"></i>List Your Business
                </a>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
