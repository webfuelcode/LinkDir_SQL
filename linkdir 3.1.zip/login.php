<?php
/**
 * linkdir - User Login
 */

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/includes/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/csrf.php';
require_once __DIR__ . '/includes/captcha.php';

// Redirect if already logged in
if (auth_check()) {
    header('Location: /dashboard');
    exit;
}

$errors = [];
$email = trim($_POST['email'] ?? '');
$redirect = $_GET['redirect'] ?? ($_POST['redirect'] ?? '/dashboard');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_require();

    // 1. Honeypot check
    if (!honeypot_verify()) {
        $errors[] = 'Spam submission detected.';
    }

    // 2. Math CAPTCHA verification
    $captchaAnswer = $_POST['captcha_challenge'] ?? '';
    if (!captcha_verify($captchaAnswer)) {
        $errors[] = 'Human verification answer was incorrect. Please solve the challenge below.';
    }

    // 3. Rate limiting check
    $ip = get_client_ip();
    $rateKey = 'login_' . md5($ip . '_' . strtolower($email));
    if (!rate_limit_check($rateKey, RATE_LIMIT_LOGIN_ATTEMPTS, RATE_LIMIT_LOGIN_WINDOW)) {
        $errors[] = 'Too many failed login attempts. Please wait 15 minutes before trying again.';
    }

    // 4. Authenticate credentials
    $password = $_POST['password'] ?? '';
    if (empty($email) || empty($password)) {
        $errors[] = 'Please provide both email and password.';
    }

    if (empty($errors)) {
        $db = get_db();
        try {
            $stmt = $db->prepare("SELECT id, name, email, password_hash, role, status, failed_logins, lock_until FROM users WHERE email = ? LIMIT 1");
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            $authSuccess = false;

            if ($user) {
                // Check account lock
                if (!empty($user['lock_until']) && strtotime($user['lock_until']) > time()) {
                    $errors[] = 'Account is temporarily locked due to multiple failed attempts. Please try again later.';
                } elseif ($user['status'] === 'suspended') {
                    $errors[] = 'This account has been suspended by an administrator.';
                } elseif (password_verify($password, $user['password_hash'])) {
                    $authSuccess = true;
                }
            }

            if ($authSuccess) {
                rate_limit_clear($rateKey);
                auth_login($user);

                // Safe redirect (validate internal path)
                $target = (str_starts_with($redirect, '/') && !str_starts_with($redirect, '//')) ? $redirect : '/dashboard';
                header('Location: ' . $target);
                exit;
            } else {
                // Record failure
                rate_limit_record($rateKey, RATE_LIMIT_LOGIN_WINDOW);

                if ($user) {
                    $stmtUpdate = $db->prepare("UPDATE users SET failed_logins = failed_logins + 1 WHERE id = ?");
                    $stmtUpdate->execute([$user['id']]);
                }

                // Generic message to avoid email enumeration
                $errors[] = 'Invalid email address or password.';
            }
        } catch (PDOException $e) {
            error_log('Login Error: ' . $e->getMessage());
            $errors[] = 'An authentication error occurred. Please try again.';
        }
    }
}

$pageTitle = 'Log In';
$pageDescription = 'Access your linkdir account to manage business listings and reviews.';
require_once __DIR__ . '/includes/header.php';
?>

<div class="container my-5">
    <div class="row justify-content-center">
        <div class="col-md-6 col-lg-5">
            <div class="card shadow-sm border-1 p-4 p-md-5">
                <div class="text-center mb-4">
                    <i class="bi bi-box-arrow-in-right text-primary fs-1"></i>
                    <h1 class="h3 fw-bold mt-2 mb-1">Welcome Back</h1>
                    <p class="text-muted small">Log in to manage your directory profile</p>
                </div>

                <?= flash_render() ?>

                <?php if (!empty($errors)): ?>
                    <div class="alert alert-danger mb-4">
                        <ul class="mb-0 ps-3 small">
                            <?php foreach ($errors as $err): ?>
                                <li><?= e($err) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form action="/login" method="POST">
                    <?= csrf_field() ?>
                    <?= honeypot_field() ?>
                    <input type="hidden" name="redirect" value="<?= e($redirect) ?>">

                    <div class="mb-3">
                        <label for="email" class="form-label small fw-semibold text-muted">Email Address</label>
                        <input type="email" class="form-control" id="email" name="email" value="<?= e($email) ?>" required autocomplete="email" placeholder="name@example.com">
                    </div>

                    <div class="mb-3">
                        <label for="password" class="form-label small fw-semibold text-muted">Password</label>
                        <input type="password" class="form-control" id="password" name="password" required autocomplete="current-password" placeholder="••••••••">
                    </div>

                    <?= captcha_field() ?>

                    <button type="submit" class="btn btn-primary w-100 py-2 fw-semibold">
                        Log In
                    </button>
                </form>

                <div class="mt-3 p-3 bg-light rounded border text-center">
                    <div class="text-muted small fw-semibold mb-2">Demo Quick Login:</div>
                    <div class="d-flex gap-2">
                        <button type="button" class="btn btn-outline-primary btn-sm flex-fill" onclick="document.getElementById('email').value='admin@linkdir.local';document.getElementById('password').value='AdminPass123!';">
                            <i class="bi bi-shield-lock me-1"></i>Admin Account
                        </button>
                        <button type="button" class="btn btn-outline-secondary btn-sm flex-fill" onclick="document.getElementById('email').value='user@linkdir.local';document.getElementById('password').value='UserPass123!';">
                            <i class="bi bi-person me-1"></i>User Account
                        </button>
                    </div>
                </div>

                <div class="text-center mt-4 pt-3 border-top small text-muted">
                    Don't have an account yet? <a href="/register" class="text-primary text-decoration-none fw-semibold">Register here</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
