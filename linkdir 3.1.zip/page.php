<?php
/**
 * linkdir - Dynamic Public Custom Page Viewer
 */

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/includes/database.php';
require_once __DIR__ . '/includes/functions.php';
require_once __DIR__ . '/includes/auth.php';

$db = get_db();
$slug = trim($_GET['slug'] ?? '');

if ($slug === '') {
    header('Location: /');
    exit;
}

$stmt = $db->prepare("SELECT * FROM pages WHERE slug = ? LIMIT 1");
$stmt->execute([$slug]);
$pageData = $stmt->fetch();

$isAdmin = auth_is_admin();

// If page does not exist, or is draft when visitor is not an admin -> 404
if (!$pageData || ($pageData['status'] !== 'published' && !$isAdmin)) {
    http_response_code(404);
    $pageTitle = 'Page Not Found';
    require_once __DIR__ . '/404.php';
    exit;
}

$pageTitle = $pageData['title'] . ' - ' . SITE_NAME;
$pageDescription = !empty($pageData['meta_description']) 
    ? $pageData['meta_description'] 
    : strip_tags(substr($pageData['content'], 0, 150)) . '...';

// Fetch other published pages for navigation
$otherPagesStmt = $db->prepare("SELECT id, title, slug FROM pages WHERE status = 'published' AND id != ? ORDER BY sort_order ASC, title ASC LIMIT 8");
$otherPagesStmt->execute([$pageData['id']]);
$otherPages = $otherPagesStmt->fetchAll();

// Fetch top categories for sidebar
$topCategories = get_footer_categories();

require_once __DIR__ . '/includes/header.php';
?>

<div class="container py-4">
    <!-- Breadcrumb Navigation -->
    <nav aria-label="breadcrumb" class="mb-4">
        <ol class="breadcrumb mb-0 py-2 px-3 bg-light rounded border">
            <li class="breadcrumb-item"><a href="/" class="text-decoration-none"><i class="bi bi-house me-1"></i>Home</a></li>
            <li class="breadcrumb-item active text-truncate" aria-current="page"><?= e($pageData['title']) ?></li>
        </ol>
    </nav>

    <?php if ($pageData['status'] === 'draft'): ?>
        <div class="alert alert-warning d-flex align-items-center gap-2 mb-4" role="alert">
            <i class="bi bi-exclamation-triangle-fill fs-5"></i>
            <div>
                <strong>Draft Preview:</strong> This page is currently unpublished. It is only visible to logged-in administrators.
                <a href="/admin/pages?edit=<?= (int)$pageData['id'] ?>" class="alert-link ms-2">Edit in Admin &rarr;</a>
            </div>
        </div>
    <?php endif; ?>

    <div class="row g-4">
        <!-- Main Content Area -->
        <div class="col-lg-8">
            <article class="card border shadow-sm p-4 p-md-5 bg-white">
                <header class="mb-4 pb-3 border-bottom">
                    <h1 class="h2 fw-bold text-dark mb-2"><?= e($pageData['title']) ?></h1>
                    <?php if (!empty($pageData['meta_description'])): ?>
                        <p class="text-muted lead fs-6 mb-2"><?= e($pageData['meta_description']) ?></p>
                    <?php endif; ?>
                    <div class="d-flex align-items-center gap-3 text-secondary small">
                        <span><i class="bi bi-clock-history me-1"></i>Updated <?= date('F j, Y', strtotime($pageData['updated_at'])) ?></span>
                        <?php if ($isAdmin): ?>
                            <span>&bull;</span>
                            <a href="/admin/pages?edit=<?= (int)$pageData['id'] ?>" class="text-primary text-decoration-none">
                                <i class="bi bi-pencil-square me-1"></i>Edit Page
                            </a>
                        <?php endif; ?>
                    </div>
                </header>

                <div class="page-body lh-lg text-dark fs-6" style="word-break: break-word;">
                    <?php 
                    // Render page content. If contains HTML tags, render directly; otherwise use nl2br + safe escaping
                    $rawContent = $pageData['content'];
                    if (strip_tags($rawContent) !== $rawContent) {
                        // Contains intentional HTML formatting
                        echo $rawContent;
                    } else {
                        echo nl2br(e($rawContent));
                    }
                    ?>
                </div>

                <footer class="mt-5 pt-4 border-top d-flex flex-wrap justify-content-between align-items-center gap-3">
                    <a href="/businesses" class="btn btn-outline-secondary btn-sm">
                        <i class="bi bi-arrow-left me-1"></i>Explore Business Directory
                    </a>
                    <div class="d-flex align-items-center gap-2 text-secondary small">
                        <?php $shareUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http') . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost') . '/page/' . $pageData['slug']; ?>
                        <span>Share:</span>
                        <a href="https://twitter.com/intent/tweet?text=<?= urlencode($pageData['title']) ?>&url=<?= urlencode($shareUrl) ?>" target="_blank" rel="noopener" class="btn btn-light btn-sm border" title="Share on X / Twitter">
                            <i class="bi bi-twitter-x"></i>
                        </a>
                        <a href="https://www.facebook.com/sharer/sharer.php?u=<?= urlencode($shareUrl) ?>" target="_blank" rel="noopener" class="btn btn-light btn-sm border" title="Share on Facebook">
                            <i class="bi bi-facebook"></i>
                        </a>
                        <a href="https://www.linkedin.com/sharing/share-offsite/?url=<?= urlencode($shareUrl) ?>" target="_blank" rel="noopener" class="btn btn-light btn-sm border" title="Share on LinkedIn">
                            <i class="bi bi-linkedin"></i>
                        </a>
                    </div>
                </footer>
            </article>
        </div>

        <!-- Sidebar Area -->
        <div class="col-lg-4">
            <div class="d-flex flex-column gap-4">
                <?php if (!empty($otherPages)): ?>
                    <div class="card border shadow-sm">
                        <div class="card-header bg-white py-3 border-bottom">
                            <h6 class="card-title fw-bold mb-0 text-dark">
                                <i class="bi bi-file-text me-2 text-primary"></i>More Information
                            </h6>
                        </div>
                        <div class="list-group list-group-flush">
                            <?php foreach ($otherPages as $op): ?>
                                <a href="/page/<?= e($op['slug']) ?>" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center py-2 px-3 small">
                                    <span class="text-dark"><?= e($op['title']) ?></span>
                                    <i class="bi bi-chevron-right text-muted" style="font-size:0.75rem;"></i>
                                </a>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if (!empty($topCategories)): ?>
                    <div class="card border shadow-sm">
                        <div class="card-header bg-white py-3 border-bottom">
                            <h6 class="card-title fw-bold mb-0 text-dark">
                                <i class="bi bi-tags me-2 text-primary"></i>Top Categories
                            </h6>
                        </div>
                        <div class="list-group list-group-flush">
                            <?php foreach ($topCategories as $tc): ?>
                                <a href="/category/<?= e($tc['slug']) ?>" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center py-2 px-3 small">
                                    <div class="d-flex align-items-center gap-2">
                                        <i class="bi <?= e($tc['icon'] ?? 'bi-tag') ?> text-primary"></i>
                                        <span class="text-dark"><?= e($tc['name']) ?></span>
                                    </div>
                                    <i class="bi bi-arrow-right text-muted" style="font-size:0.75rem;"></i>
                                </a>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- Business Owner CTA -->
                <div class="card border-primary border-2 shadow-sm bg-primary-subtle p-4">
                    <h6 class="fw-bold text-primary mb-2">Own a Local Business?</h6>
                    <p class="small text-secondary mb-3">
                        Get your business listed on <?= e(SITE_NAME) ?> in under 2 minutes. Gain visibility and verified community reviews.
                    </p>
                    <a href="<?= auth_check() ? '/dashboard/business/add' : '/register' ?>" class="btn btn-primary btn-sm fw-semibold">
                        <i class="bi bi-plus-circle me-1"></i>List Your Business
                    </a>
                </div>

                <!-- Ad Placement if any -->
                <?= render_ad('sidebar_directory') ?>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
