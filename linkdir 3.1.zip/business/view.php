<?php
/**
 * linkdir - Business Detail Page
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';

$db = get_db();
$slug = trim($_GET['slug'] ?? '');

if ($slug === '') {
    header('Location: /businesses');
    exit;
}

// Fetch business details
$bizStmt = $db->prepare("
    SELECT b.*, c.name as category_name, c.slug as category_slug, u.name as owner_name
    FROM businesses b
    JOIN categories c ON b.category_id = c.id
    LEFT JOIN users u ON b.user_id = u.id
    WHERE b.slug = ?
    LIMIT 1
");
$bizStmt->execute([$slug]);
$biz = $bizStmt->fetch();

if (!$biz) {
    http_response_code(404);
    $pageTitle = 'Business Not Found';
    require_once __DIR__ . '/../404.php';
    exit;
}

// If business is not approved, only the owner or an admin can preview it
$currentUser = auth_user();
$isOwner = ($currentUser && $currentUser['id'] == $biz['user_id']);
$isAdmin = auth_is_admin();

if ($biz['status'] !== 'approved' && !$isOwner && !$isAdmin) {
    http_response_code(404);
    $pageTitle = 'Listing Unavailable';
    require_once __DIR__ . '/../404.php';
    exit;
}

// Fetch approved reviews
$revStmt = $db->prepare("
    SELECT r.id, r.user_id, r.rating, r.review_text, r.created_at, r.updated_at, u.name as reviewer_name
    FROM reviews r
    JOIN users u ON r.user_id = u.id
    WHERE r.business_id = ? AND r.status = 'approved'
    ORDER BY r.created_at DESC
");
$revStmt->execute([$biz['id']]);
$reviews = $revStmt->fetchAll();

// Calculate review statistics
$totalReviews = count($reviews);
$avgRating = 0.0;
if ($totalReviews > 0) {
    $sum = array_sum(array_column($reviews, 'rating'));
    $avgRating = round($sum / $totalReviews, 1);
}

// Check if current logged in user already left a review
$userReview = null;
if ($currentUser) {
    $userRevStmt = $db->prepare("SELECT * FROM reviews WHERE business_id = ? AND user_id = ? LIMIT 1");
    $userRevStmt->execute([$biz['id'], $currentUser['id']]);
    $userReview = $userRevStmt->fetch();
}

// Structured data (Schema.org LocalBusiness)
$jsonLd = [
    '@context' => 'https://schema.org',
    '@type' => 'LocalBusiness',
    'name' => $biz['business_name'],
    'description' => strip_tags($biz['about']),
    'url' => (!empty($biz['website_url']) ? $biz['website_url'] : 'https://' . ($_SERVER['HTTP_HOST'] ?? 'example.com') . '/business/' . $biz['slug']),
    'telephone' => $biz['phone'] ?? '',
    'email' => $biz['email'] ?? '',
    'address' => [
        '@type' => 'PostalAddress',
        'streetAddress' => $biz['address'] ?? '',
        'addressCountry' => $biz['country']
    ]
];

if (!empty($biz['logo'])) {
    $jsonLd['image'] = 'https://' . ($_SERVER['HTTP_HOST'] ?? 'example.com') . '/uploads/businesses/' . $biz['logo'];
}

if ($totalReviews > 0) {
    $jsonLd['aggregateRating'] = [
        '@type' => 'AggregateRating',
        'ratingValue' => $avgRating,
        'reviewCount' => $totalReviews,
        'bestRating' => 5,
        'worstRating' => 1
    ];
}

$pageTitle = $biz['business_name'] . ' - ' . $biz['category_name'];
$pageDescription = mb_strimwidth(strip_tags($biz['about']), 0, 160, '...');
$ogType = 'business.business';
$ogImage = !empty($biz['logo']) ? '/uploads/businesses/' . $biz['logo'] : '';

require_once __DIR__ . '/../includes/header.php';
?>

<!-- Business Header Banner -->
<div class="bg-light border-bottom py-4 mb-4">
    <div class="container">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb small mb-2">
                <li class="breadcrumb-item"><a href="/" class="text-decoration-none">Home</a></li>
                <li class="breadcrumb-item"><a href="/businesses" class="text-decoration-none">Directory</a></li>
                <li class="breadcrumb-item"><a href="/category/<?= e($biz['category_slug']) ?>" class="text-decoration-none"><?= e($biz['category_name']) ?></a></li>
                <li class="breadcrumb-item active" aria-current="page"><?= e($biz['business_name']) ?></li>
            </ol>
        </nav>

        <?php if ($biz['status'] !== 'approved'): ?>
            <div class="alert alert-warning d-flex align-items-center mb-3">
                <i class="bi bi-exclamation-triangle-fill fs-4 me-2"></i>
                <div>
                    <strong>Listing Status: <?= ucfirst(e($biz['status'])) ?>.</strong> 
                    This listing is not currently visible to the public. 
                    <?= ($biz['status'] === 'pending' ? 'It is awaiting administrator approval.' : '') ?>
                </div>
            </div>
        <?php endif; ?>

        <div class="d-flex flex-column flex-md-row align-items-md-center justify-content-between gap-3">
            <div class="d-flex align-items-center gap-3">
                <?php if (!empty($biz['logo'])): ?>
                    <img src="/uploads/businesses/<?= e($biz['logo']) ?>" alt="<?= e($biz['business_name']) ?>" class="business-logo-thumb-large shadow-sm">
                <?php else: ?>
                    <div class="business-logo-placeholder-lg shadow-sm">
                        <?= strtoupper(substr($biz['business_name'], 0, 2)) ?>
                    </div>
                <?php endif; ?>

                <div>
                    <div class="d-flex align-items-center gap-2 flex-wrap mb-1">
                        <h1 class="h3 fw-bold mb-0 text-dark"><?= e($biz['business_name']) ?></h1>
                        <a href="/category/<?= e($biz['category_slug']) ?>" class="badge bg-primary-subtle text-primary border border-primary-subtle text-decoration-none">
                            <?= e($biz['category_name']) ?>
                        </a>
                    </div>

                    <div class="d-flex align-items-center gap-2 flex-wrap text-muted small">
                        <div>
                            <?= render_stars($avgRating, true) ?>
                            <span class="text-muted">(<?= $totalReviews ?> <?= ($totalReviews === 1 ? 'review' : 'reviews') ?>)</span>
                        </div>
                        <?php if (!empty($biz['country'])): ?>
                            <span>&bull;</span>
                            <div>
                                <i class="bi bi-geo-alt text-primary me-1"></i><?= e($biz['country']) ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <?php if ($isOwner || $isAdmin): ?>
                <div class="d-flex gap-2">
                    <a href="/dashboard/business/edit/<?= (int)$biz['id'] ?>" class="btn btn-outline-secondary btn-sm">
                        <i class="bi bi-pencil me-1"></i>Edit Listing
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="container mb-5">
    <?= flash_render() ?>

    <div class="row g-4">
        <!-- Main Left Column: About & Reviews -->
        <div class="col-lg-8">
            <!-- About Business -->
            <div class="card shadow-sm border-1 p-4 mb-4">
                <h2 class="h5 fw-bold mb-3 border-bottom pb-2">About <?= e($biz['business_name']) ?></h2>
                <div class="text-secondary lh-lg" style="white-space: pre-line;">
                    <?= e($biz['about']) ?>
                </div>
            </div>

            <!-- Customer Reviews Section -->
            <div class="card shadow-sm border-1 p-4" id="reviews-section">
                <div class="d-flex justify-content-between align-items-center mb-3 border-bottom pb-2">
                    <div>
                        <h2 class="h5 fw-bold mb-0">Customer Reviews</h2>
                        <span class="text-muted small"><?= $totalReviews ?> <?= ($totalReviews === 1 ? 'verified review' : 'verified reviews') ?></span>
                    </div>

                    <div class="text-end">
                        <div class="fs-4 fw-bold text-dark"><?= ($avgRating > 0 ? number_format($avgRating, 1) : '—') ?><span class="fs-6 text-muted">/5</span></div>
                        <div class="small"><?= render_stars($avgRating, false) ?></div>
                    </div>
                </div>

                <!-- Review Submission or Status -->
                <div id="review-form-container" class="mb-4">
                    <?php if (!$currentUser): ?>
                        <div class="alert alert-light border text-center p-3">
                            <p class="mb-2 small text-muted">Have you used this service or visited this business?</p>
                            <a href="/login?redirect=/business/<?= e($biz['slug']) ?>#reviews-section" class="btn btn-primary btn-sm">
                                Log in to Write a Review
                            </a>
                        </div>
                    <?php elseif ($isOwner): ?>
                        <div class="alert alert-secondary small p-2 text-center text-muted">
                            <i class="bi bi-info-circle me-1"></i>You are the owner of this business listing.
                        </div>
                    <?php elseif ($userReview): ?>
                        <!-- User's Existing Review -->
                        <div class="card bg-light border p-3 mb-3" id="user-review-card">
                            <div class="d-flex justify-content-between align-items-start mb-2">
                                <div>
                                    <span class="badge bg-success mb-1">Your Review</span>
                                    <div class="small"><?= render_stars((float)$userReview['rating']) ?></div>
                                </div>
                                <div class="btn-group btn-group-sm">
                                    <button class="btn btn-outline-danger btn-sm"
                                            hx-post="/actions/review.php?action=delete&id=<?= (int)$userReview['id'] ?>"
                                            hx-confirm="Are you sure you want to delete your review?"
                                            hx-target="#review-form-container"
                                            hx-swap="outerHTML">
                                        <i class="bi bi-trash"></i> Delete
                                    </button>
                                </div>
                            </div>
                            <p class="small mb-1 text-dark"><?= e($userReview['review_text']) ?></p>
                            <small class="text-muted"><?= format_date($userReview['created_at']) ?></small>
                        </div>
                    <?php else: ?>
                        <!-- Write Review Form -->
                        <form action="/actions/review.php" method="POST"
                              class="card bg-light border p-3"
                              hx-post="/actions/review.php"
                              hx-target="#reviews-section"
                              hx-swap="outerHTML">
                            <?= csrf_field() ?>
                            <input type="hidden" name="business_id" value="<?= (int)$biz['id'] ?>">
                            <input type="hidden" name="business_slug" value="<?= e($biz['slug']) ?>">

                            <h6 class="fw-bold mb-2">Leave a Review</h6>
                            <div class="row g-2 mb-3">
                                <div class="col-sm-4">
                                    <label class="form-label small fw-semibold text-muted">Rating</label>
                                    <select name="rating" class="form-select form-select-sm" required>
                                        <option value="5">★★★★★ (5 - Excellent)</option>
                                        <option value="4">★★★★☆ (4 - Very Good)</option>
                                        <option value="3">★★★☆☆ (3 - Average)</option>
                                        <option value="2">★★☆☆☆ (2 - Poor)</option>
                                        <option value="1">★☆☆☆☆ (1 - Terrible)</option>
                                    </select>
                                </div>
                            </div>

                            <div class="mb-3">
                                <label class="form-label small fw-semibold text-muted">Your Experience</label>
                                <textarea name="review_text" class="form-control form-control-sm" rows="3" placeholder="Share specific details about the service, quality, punctuality, or pricing..." required maxlength="2000"></textarea>
                            </div>

                            <button type="submit" class="btn btn-primary btn-sm align-self-start">
                                <i class="bi bi-send me-1"></i>Submit Review
                            </button>
                        </form>
                    <?php endif; ?>
                </div>

                <!-- Reviews List -->
                <?php if (!empty($reviews)): ?>
                    <div class="d-flex flex-column gap-3">
                        <?php foreach ($reviews as $rev): ?>
                            <div class="border-bottom pb-3">
                                <div class="d-flex justify-content-between align-items-center mb-1">
                                    <strong class="text-dark"><?= e($rev['reviewer_name']) ?></strong>
                                    <span class="text-muted small"><?= time_ago($rev['created_at']) ?></span>
                                </div>
                                <div class="mb-2">
                                    <?= render_stars((float)$rev['rating'], false) ?>
                                </div>
                                <p class="text-secondary small mb-0 lh-base">
                                    <?= e($rev['review_text']) ?>
                                </p>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="text-center py-4 text-muted">
                        <i class="bi bi-chat-heart fs-3 text-secondary opacity-50 mb-2 d-block"></i>
                        <p class="small mb-0">No reviews yet for this listing. Be the first to share your feedback!</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Sidebar Right Column: Quick Contact & Details -->
        <div class="col-lg-4">
            <!-- Contact Card -->
            <div class="card shadow-sm border-1 p-4 mb-4">
                <h3 class="h6 fw-bold text-uppercase text-muted tracking-wide mb-3">Direct Contact</h3>

                <div class="d-grid gap-2 mb-4">
                    <?php if (!empty($biz['phone'])): ?>
                        <a href="tel:<?= preg_replace('/[^0-9+]/', '', $biz['phone']) ?>" class="btn btn-primary btn-contact-action">
                            <i class="bi bi-telephone-fill me-2"></i>Call <?= e($biz['phone']) ?>
                        </a>
                    <?php endif; ?>

                    <?php if (!empty($biz['email'])): ?>
                        <a href="mailto:<?= e($biz['email']) ?>" class="btn btn-outline-secondary btn-contact-action">
                            <i class="bi bi-envelope-fill me-2"></i>Send Email
                        </a>
                    <?php endif; ?>

                    <?php if (!empty($biz['website_url'])): ?>
                        <a href="<?= e($biz['website_url']) ?>" target="_blank" rel="noopener noreferrer nofollow" class="btn btn-outline-dark btn-contact-action">
                            <i class="bi bi-box-arrow-up-right me-2"></i>Visit Website
                        </a>
                    <?php endif; ?>
                </div>

                <h4 class="h6 fw-bold text-uppercase text-muted tracking-wide mb-2">Location</h4>
                <div class="text-secondary small mb-3">
                    <?php if (!empty($biz['address'])): ?>
                        <div class="mb-1"><i class="bi bi-geo-alt me-1 text-primary"></i><?= e($biz['address']) ?></div>
                    <?php endif; ?>
                    <?php if (!empty($biz['country'])): ?>
                        <div class="fw-semibold text-dark"><i class="bi bi-globe me-1 text-muted"></i><?= e($biz['country']) ?></div>
                    <?php endif; ?>
                </div>

                <div class="border-top pt-3 text-muted small">
                    <div class="d-flex justify-content-between mb-1">
                        <span>Listed:</span>
                        <span><?= format_date($biz['created_at']) ?></span>
                    </div>
                    <?php if (!empty($biz['updated_at']) && $biz['updated_at'] !== $biz['created_at']): ?>
                        <div class="d-flex justify-content-between">
                            <span>Last Updated:</span>
                            <span><?= format_date($biz['updated_at']) ?></span>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Share Box -->
            <div class="card shadow-sm border-1 p-3 text-center bg-light mb-4">
                <small class="text-muted fw-semibold mb-2 d-block">Share this listing</small>
                <div class="d-flex justify-content-center gap-2">
                    <button class="btn btn-outline-secondary btn-sm" onclick="navigator.clipboard.writeText(window.location.href); this.innerText = 'Copied!'; setTimeout(() => this.innerText = 'Copy Link', 2000);">
                        <i class="bi bi-link-45deg me-1"></i>Copy Link
                    </button>
                </div>
            </div>

            <!-- Sidebar Ad Placement (300x250) -->
            <?= render_ad('sidebar_business', 'mb-4') ?>
        </div>
    </div>

    <!-- Leaderboard Ad Placement (728x90) -->
    <?= render_ad('leaderboard_business', 'mt-4') ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
