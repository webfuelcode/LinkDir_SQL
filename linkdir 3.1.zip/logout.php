<?php
/**
 * linkdir - User Logout
 */

require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/functions.php';

auth_logout();
flash_set('info', 'You have been safely logged out.');
header('Location: /login');
exit;
