# linkdir - Business & Service Directory

A lightweight, high-performance, production-ready business and service directory web application built with:

* **PHP 8.2+**
* **MySQL / MariaDB** (with zero-config SQLite support for instant local testing)
* **HTMX** (for fast, dynamic UI updates without page reloads)
* **Bootstrap 5 & Bootstrap Icons**
* **PDO with prepared statements**
* **PHP sessions for secure authentication**

Designed specifically for **normal shared hosting / cPanel environments** (no Node.js, React, Next.js, or complex runtime requirements needed in production).

---

## 🚀 Shared Hosting / cPanel Deployment Guide

### 1. Upload Files
1. Download or export the project ZIP.
2. Log in to your cPanel control panel and open **File Manager**.
3. Upload all files into your `public_html` directory (or your chosen addon domain / subdomain folder).
4. Ensure the `.htaccess` file is uploaded (in cPanel File Manager, enable **"Show Hidden Files (dotfiles)"** in Settings to view `.htaccess`).

### 2. Set Up the MySQL Database
1. In cPanel, navigate to **MySQL® Databases**.
2. Create a new database (e.g., `cpaneluser_linkdir`).
3. Create a new database user with a strong password.
4. Add the user to the database with **ALL PRIVILEGES**.
5. Open **phpMyAdmin**, select your new database, click **Import**, and upload `database.sql`.

### 3. Configure Database Credentials
Open `config/config.php` in the cPanel File Editor:
```php
define('DB_DRIVER', 'mysql'); // Change to 'mysql'
define('DB_HOST', 'localhost');
define('DB_PORT', '3306');
define('DB_NAME', 'cpaneluser_linkdir');
define('DB_USER', 'cpaneluser_dbuser');
define('DB_PASS', 'YourStrongPasswordHere');
```

### 4. Verify Folder Permissions
Ensure the upload directory has write permissions for image uploads:
* `uploads/businesses/` -> `chmod 755` (or `775` depending on server configuration)

### 5. Access and Test
Navigate to your domain in any web browser. Visit `/install` to run the environment health check.

---

## 🔑 Default Demo Accounts

* **Administrator:**
  * **Email:** `admin@linkdir.local`
  * **Password:** `AdminPass123!`
  * **Capabilities:** Approve/reject listings, moderate reviews, manage categories, promote/demote users.

* **Business Owner / User:**
  * **Email:** `user@linkdir.local`
  * **Password:** `UserPass123!`
  * **Capabilities:** Add and edit own listings, write reviews, manage profile.

---

## 🛡️ Security Features
* **CSRF Protection:** Cryptographically secure CSRF token verified on all POST/PUT/DELETE actions and HTMX requests.
* **Rate Limiting:** Database-backed rate limiter on login and registration endpoints to prevent brute-force attempts.
* **Anti-Bot Defenses:** Dual-layer protection using CSS-hidden honeypots and server-side dynamic arithmetic math challenges.
* **Prepared Statements:** 100% of database queries use PDO prepared statements to eliminate SQL injection risks.
* **Image Sanitization:** Uploaded images are validated via MIME type and `getimagesize()`, stripped of harmful metadata, and resized using GD.
* **XSS Sanitization:** All output is escaped using `htmlspecialchars(..., ENT_QUOTES, 'UTF-8')`.

---

## 🔍 SEO & Structured Data
* Clean, human-readable URLs (e.g., `/business/saffron-table-bistro`, `/category/restaurants-dining`).
* Schema.org `LocalBusiness` JSON-LD structured data embedded on every business detail page.
* Dynamic XML Sitemap generated at `/sitemap.xml`.
* Open Graph social preview meta tags.
