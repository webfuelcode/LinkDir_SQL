<?php
/**
 * linkdir - Dynamic XML Sitemap
 */

require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/includes/database.php';

header('Content-Type: application/xml; charset=utf-8');

$db = get_db();
$scheme = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') ? 'https' : 'http';
$host = $_SERVER['HTTP_HOST'] ?? 'example.com';
$baseUrl = $scheme . '://' . $host;

// Fetch categories
$categories = $db->query("SELECT slug, created_at FROM categories WHERE status = 'active'")->fetchAll();

// Fetch approved businesses
$businesses = $db->query("SELECT slug, updated_at, created_at FROM businesses WHERE status = 'approved'")->fetchAll();

echo '<?xml version="1.0" encoding="UTF-8"?>' . PHP_EOL;
?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
    <!-- Static Pages -->
    <url>
        <loc><?= $baseUrl ?>/</loc>
        <changefreq>daily</changefreq>
        <priority>1.0</priority>
    </url>
    <url>
        <loc><?= $baseUrl ?>/businesses</loc>
        <changefreq>daily</changefreq>
        <priority>0.9</priority>
    </url>

    <!-- Categories -->
    <?php foreach ($categories as $cat): ?>
    <url>
        <loc><?= $baseUrl ?>/category/<?= htmlspecialchars($cat['slug']) ?></loc>
        <changefreq>weekly</changefreq>
        <priority>0.8</priority>
    </url>
    <?php endforeach; ?>

    <!-- Approved Businesses -->
    <?php foreach ($businesses as $b): ?>
    <url>
        <loc><?= $baseUrl ?>/business/<?= htmlspecialchars($b['slug']) ?></loc>
        <lastmod><?= date('Y-m-d', strtotime($b['updated_at'] ?: $b['created_at'])) ?></lastmod>
        <changefreq>weekly</changefreq>
        <priority>0.7</priority>
    </url>
    <?php endforeach; ?>
</urlset>
