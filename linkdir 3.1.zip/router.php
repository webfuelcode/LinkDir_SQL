<?php
/**
 * linkdir - Router for PHP Built-in Server (Local Development / Preview)
 * 
 * NOTE FOR CPANEL / APACHE HOSTING:
 * On standard cPanel / Apache shared hosting, this file is not needed.
 * Apache will automatically use the included /.htaccess file for URL rewriting.
 */

$uri = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
$file = __DIR__ . $uri;

// 1. Serve static files directly if they exist
if ($uri !== '/' && file_exists($file) && !is_dir($file)) {
    // Determine mime type
    $ext = pathinfo($file, PATHINFO_EXTENSION);
    $mimes = [
        'css'  => 'text/css',
        'js'   => 'application/javascript',
        'png'  => 'image/png',
        'jpg'  => 'image/jpeg',
        'jpeg' => 'image/jpeg',
        'webp' => 'image/webp',
        'gif'  => 'image/gif',
        'svg'  => 'image/svg+xml',
        'ico'  => 'image/x-icon',
        'xml'  => 'application/xml',
        'json' => 'application/json',
        'txt'  => 'text/plain',
    ];

    if (isset($mimes[$ext])) {
        header('Content-Type: ' . $mimes[$ext]);
    }

    // Execute PHP files directly
    if ($ext === 'php') {
        require $file;
        exit;
    }

    return false; // Let PHP built-in server serve static assets
}

// 2. URL Routing emulation matching .htaccess
if ($uri === '/' || $uri === '/index.php') {
    require __DIR__ . '/index.php';
    exit;
}

if ($uri === '/businesses' || $uri === '/businesses/') {
    require __DIR__ . '/businesses/index.php';
    exit;
}

if (preg_match('#^/category/([a-zA-Z0-9_-]+)/?$#', $uri, $matches)) {
    $_GET['slug'] = $matches[1];
    require __DIR__ . '/category/index.php';
    exit;
}

if (preg_match('#^/(?:page|p)/([a-zA-Z0-9_-]+)/?$#', $uri, $matches)) {
    $_GET['slug'] = $matches[1];
    require __DIR__ . '/page.php';
    exit;
}

if (preg_match('#^/business/([a-zA-Z0-9_-]+)/?$#', $uri, $matches)) {
    $_GET['slug'] = $matches[1];
    require __DIR__ . '/business/view.php';
    exit;
}

if ($uri === '/dashboard' || $uri === '/dashboard/') {
    require __DIR__ . '/dashboard/index.php';
    exit;
}

if ($uri === '/dashboard/business/add') {
    require __DIR__ . '/dashboard/business-add.php';
    exit;
}

if (preg_match('#^/dashboard/business/edit/([0-9]+)/?$#', $uri, $matches)) {
    $_GET['id'] = $matches[1];
    require __DIR__ . '/dashboard/business-edit.php';
    exit;
}

if ($uri === '/dashboard/reviews' || $uri === '/dashboard/reviews/') {
    require __DIR__ . '/dashboard/reviews.php';
    exit;
}

if ($uri === '/dashboard/profile' || $uri === '/dashboard/profile/') {
    require __DIR__ . '/dashboard/profile.php';
    exit;
}

// Admin Routes
if ($uri === '/admin' || $uri === '/admin/') {
    require __DIR__ . '/admin/index.php';
    exit;
}

if ($uri === '/admin/businesses' || $uri === '/admin/businesses/') {
    require __DIR__ . '/admin/businesses.php';
    exit;
}

if ($uri === '/admin/reviews' || $uri === '/admin/reviews/') {
    require __DIR__ . '/admin/reviews.php';
    exit;
}

if ($uri === '/admin/categories' || $uri === '/admin/categories/') {
    require __DIR__ . '/admin/categories.php';
    exit;
}

if (in_array($uri, ['/admin/ads', '/admin/ads/', '/admin/ads.php', '/admin/banner', '/admin/banners', '/admin/ad-placements', '/admin/advertisements'])) {
    require __DIR__ . '/admin/ads.php';
    exit;
}

if (in_array($uri, ['/admin/pages', '/admin/pages/', '/admin/pages.php'])) {
    require __DIR__ . '/admin/pages.php';
    exit;
}

if (in_array($uri, ['/admin/footer', '/admin/footer/', '/admin/footer.php', '/admin/footer-settings'])) {
    require __DIR__ . '/admin/footer.php';
    exit;
}

if (in_array($uri, ['/admin/settings', '/admin/settings/', '/admin/settings.php', '/admin/config'])) {
    require __DIR__ . '/admin/settings.php';
    exit;
}

if ($uri === '/admin/users' || $uri === '/admin/users/') {
    require __DIR__ . '/admin/users.php';
    exit;
}

if ($uri === '/admin/actions.php') {
    require __DIR__ . '/admin/actions.php';
    exit;
}

// Actions
if ($uri === '/actions/review.php') {
    require __DIR__ . '/actions/review.php';
    exit;
}

if ($uri === '/actions/business.php') {
    require __DIR__ . '/actions/business.php';
    exit;
}

// Auth
if ($uri === '/login') {
    require __DIR__ . '/login.php';
    exit;
}

if ($uri === '/register') {
    require __DIR__ . '/register.php';
    exit;
}

if ($uri === '/logout') {
    require __DIR__ . '/logout.php';
    exit;
}

// Utilities
if ($uri === '/install' || $uri === '/install/') {
    require __DIR__ . '/install/index.php';
    exit;
}

if ($uri === '/sitemap.xml') {
    require __DIR__ . '/sitemap.php';
    exit;
}

// Fallback 404
http_response_code(404);
require __DIR__ . '/404.php';
