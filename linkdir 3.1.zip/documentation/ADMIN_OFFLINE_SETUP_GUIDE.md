# Admin Offline Setup & Installation Guide

This document is a private reference guide for administrators to install, configure, and manage **linkdir** in offline environments, local development servers, or private cPanel hosting.

---

## 1. Web Setup Wizard (`/install`)

The interactive setup wizard is located in `/install` (e.g. `https://your-domain.com/install`). It has been removed from the public website footer so general visitors cannot discover it.

### Using the Web Installer:
1. Upload the project files to your web server (`public_html` or document root).
2. Ensure PHP 8.1+ is installed with `pdo_sqlite` or `pdo_mysql`, `mbstring`, and `gd`.
3. Set write permissions (`chmod 775` or `chmod 777`) on:
   - `/data`
   - `/config`
   - `/uploads`
4. In your browser, navigate directly to:
   ```
   https://your-domain.com/install
   ```
5. Follow the 3-step wizard:
   - **Step 1 - System Checks**: Verifies PHP version and writable directories.
   - **Step 2 - Database Setup**: Choose SQLite (zero configuration, recommended for instant deployment) or MySQL (enter Host, Database Name, User, and Password).
   - **Step 3 - Admin Account**: Create your initial administrator username, email, and password.
6. Once complete, the wizard creates `data/installed.lock` to prevent unauthorized re-installation.

### Post-Installation Security Recommendation:
For maximum security in production, either:
- Delete the `/install` folder entirely from your server:
  ```bash
  rm -rf /path/to/public_html/install
  ```
- Or restrict access to `/install` via `.htaccess` to your specific IP address.

---

## 2. Manual (Offline) Database Setup

If you cannot or do not want to use the web wizard:

### Option A: SQLite (Default & Instant)
- No database server needed.
- Ensure the `/data` directory is writable by the web server user (`www-data` or `apache`).
- The application will automatically create `/data/linkdir.sqlite` and bootstrap tables upon first access.

### Option B: MySQL / MariaDB (cPanel)
1. In cPanel, go to **MySQL Databases** and create a new database (e.g. `myuser_linkdir`).
2. Create a user and grant **All Privileges** to that database.
3. In **phpMyAdmin**, select the new database and import `config/database.sql`.
4. Copy `config/config.example.php` (or edit `config/config.php`):
   ```php
   define('DB_DRIVER', 'mysql');
   define('DB_HOST', 'localhost');
   define('DB_PORT', '3306');
   define('DB_NAME', 'myuser_linkdir');
   define('DB_USER', 'myuser_dbuser');
   define('DB_PASS', 'your_secure_password');
   ```
5. Create the initial admin user using the SQL script or password hash utility in `includes/auth.php`.

---

## 3. Admin Panel & Ads / Banners Management

### Accessing the Admin Area:
- Direct URL: `https://your-domain.com/admin`
- Default Demo Admin Credentials (if seeded):
  - **Email**: `admin@linkdir.local`
  - **Password**: `AdminPass123!`

### Managing Advertisements & Banners:
- Direct URL: `https://your-domain.com/admin/ads` (or `/admin/ads.php`)
- Configurable Placements:
  1. **Directory Top Leaderboard (728x90)**: Appears at the top of the main Explore Directory and search results.
  2. **Directory Sidebar Ad (300x250)**: Medium rectangle banner in the directory filter sidebar.
  3. **Business Detail Sidebar Ad (300x250)**: Highlighted sponsor ad on every business profile page.
  4. **Business Detail Bottom Leaderboard (728x90)**: Bottom banner slot on business profile pages.
- Supported Ad Types:
  - **Image Banner**: Provide an image URL and click destination URL.
  - **Custom Script / Embed**: Google AdSense, affiliate tracking scripts, or custom HTML.
- Status Toggle:
  - **Active**: Publicly visible in the layout slot.
  - **Disabled**: Hidden without deleting your configurations.

---

## 4. Server Configuration & URL Rewriting

### Apache / cPanel:
Ensure `mod_rewrite` is enabled. The included `/.htaccess` handles clean URLs automatically:
- `/businesses` -> `businesses/index.php`
- `/admin` -> `admin/index.php`
- `/admin/ads` -> `admin/ads.php`
- `/category/{slug}` -> `category/index.php?slug={slug}`
- `/business/{slug}` -> `business/view.php?slug={slug}`

If `mod_rewrite` is not supported on your host, you can also access files directly:
- `admin/ads/index.php`
- `admin/ads.php`
- `businesses/index.php`
