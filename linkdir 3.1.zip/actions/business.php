<?php
/**
 * linkdir - Business Listing Actions (Delete / Status update)
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';

auth_require_login();
$user = auth_user();
$db = get_db();

$action = $_GET['action'] ?? '';
$businessId = (int)($_GET['id'] ?? 0);

if ($businessId <= 0) {
    http_response_code(400);
    die('Invalid business ID');
}

// Fetch business
$stmt = $db->prepare("SELECT * FROM businesses WHERE id = ? LIMIT 1");
$stmt->execute([$businessId]);
$biz = $stmt->fetch();

if (!$biz) {
    http_response_code(404);
    die('Business not found');
}

// Verify ownership or admin
if ($biz['user_id'] != $user['id'] && !auth_is_admin()) {
    http_response_code(403);
    die('Forbidden: You do not have permission to modify this business.');
}

if ($action === 'delete') {
    csrf_require();

    // 1. Delete logo file if exists
    if (!empty($biz['logo'])) {
        $logoPath = UPLOAD_DIR . '/businesses/' . $biz['logo'];
        if (file_exists($logoPath)) {
            @unlink($logoPath);
        }
    }

    // 2. Delete business record (foreign keys cascade will remove reviews if set, or manually delete)
    $delReviews = $db->prepare("DELETE FROM reviews WHERE business_id = ?");
    $delReviews->execute([$businessId]);

    $delBiz = $db->prepare("DELETE FROM businesses WHERE id = ?");
    $delBiz->execute([$businessId]);

    if (is_htmx()) {
        // Return empty string to remove the row from DOM
        exit('');
    }

    flash_set('success', 'Business listing "' . $biz['business_name'] . '" was deleted successfully.');
    header('Location: /dashboard');
    exit;
}

http_response_code(400);
echo 'Invalid action';
