<?php
/**
 * linkdir - Review Action Handler (Create / Delete)
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';

if (!auth_check()) {
    if (is_htmx()) {
        http_response_code(401);
        echo '<div class="alert alert-danger py-2 small">Please log in to submit a review.</div>';
        exit;
    }
    flash_set('danger', 'Please log in to submit a review.');
    header('Location: /login');
    exit;
}

$user = auth_user();
$db = get_db();
$action = $_GET['action'] ?? 'create';

// Delete review action
if ($action === 'delete') {
    csrf_require();
    $reviewId = (int)($_GET['id'] ?? 0);

    $revStmt = $db->prepare("SELECT * FROM reviews WHERE id = ? LIMIT 1");
    $revStmt->execute([$reviewId]);
    $review = $revStmt->fetch();

    if ($review && ($review['user_id'] == $user['id'] || auth_is_admin())) {
        $delStmt = $db->prepare("DELETE FROM reviews WHERE id = ?");
        $delStmt->execute([$reviewId]);

        if (is_htmx()) {
            // Return replacement review form
            ?>
            <form action="/actions/review.php" method="POST"
                  class="card bg-light border p-3"
                  hx-post="/actions/review.php"
                  hx-target="#reviews-section"
                  hx-swap="outerHTML">
                <?= csrf_field() ?>
                <input type="hidden" name="business_id" value="<?= (int)$review['business_id'] ?>">
                <h6 class="fw-bold mb-2">Leave a Review</h6>
                <div class="row g-2 mb-3">
                    <div class="col-sm-4">
                        <label class="form-label small fw-semibold text-muted">Rating</label>
                        <select name="rating" class="form-select form-select-sm" required>
                            <option value="5">★★★★★ (5 - Excellent)</option>
                            <option value="4">★★★★☆ (4 - Very Good)</option>
                            <option value="3">★★★☆☆ (3 - Average)</option>
                            <option value="2">★★☆☆☆ (2 - Poor)</option>
                            <option value="1">★☆☆☆☆ (1 - Terrible)</option>
                        </select>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label small fw-semibold text-muted">Your Experience</label>
                    <textarea name="review_text" class="form-control form-control-sm" rows="3" placeholder="Share specific details about the service, quality, punctuality, or pricing..." required maxlength="2000"></textarea>
                </div>
                <button type="submit" class="btn btn-primary btn-sm align-self-start">
                    <i class="bi bi-send me-1"></i>Submit Review
                </button>
            </form>
            <?php
            exit;
        }

        flash_set('success', 'Your review has been removed.');
        header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? '/dashboard/reviews'));
        exit;
    }

    http_response_code(403);
    die('Forbidden');
}

// Create Review Action
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_require();

    $businessId = (int)($_POST['business_id'] ?? 0);
    $rating = (int)($_POST['rating'] ?? 5);
    $reviewText = trim($_POST['review_text'] ?? '');
    $businessSlug = trim($_POST['business_slug'] ?? '');

    // Validation
    if ($rating < 1 || $rating > 5) {
        $rating = 5;
    }

    if (empty($reviewText)) {
        if (is_htmx()) {
            echo '<div class="alert alert-danger py-2 small">Review text cannot be empty.</div>';
            exit;
        }
        flash_set('danger', 'Review text is required.');
        header('Location: /business/' . urlencode($businessSlug));
        exit;
    }

    // Verify business exists
    $bStmt = $db->prepare("SELECT id, slug, user_id FROM businesses WHERE id = ? AND status = 'approved' LIMIT 1");
    $bStmt->execute([$businessId]);
    $biz = $bStmt->fetch();

    if (!$biz) {
        http_response_code(404);
        die('Business not found');
    }

    // Prevent owner from reviewing own business
    if ($biz['user_id'] == $user['id']) {
        if (is_htmx()) {
            echo '<div class="alert alert-warning py-2 small">You cannot review your own business listing.</div>';
            exit;
        }
        flash_set('warning', 'You cannot review your own business listing.');
        header('Location: /business/' . urlencode($biz['slug']));
        exit;
    }

    // Check duplicate review
    $dupStmt = $db->prepare("SELECT id FROM reviews WHERE business_id = ? AND user_id = ? LIMIT 1");
    $dupStmt->execute([$businessId, $user['id']]);
    if ($dupStmt->fetch()) {
        if (is_htmx()) {
            echo '<div class="alert alert-warning py-2 small">You have already reviewed this business.</div>';
            exit;
        }
        flash_set('warning', 'You have already reviewed this business.');
        header('Location: /business/' . urlencode($biz['slug']));
        exit;
    }

    // Determine review status (auto approve or pending based on config)
    $reviewStatus = REQUIRE_REVIEW_APPROVAL ? 'pending' : 'approved';

    // Insert review
    $insStmt = $db->prepare("
        INSERT INTO reviews (business_id, user_id, rating, review_text, status, created_at)
        VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
    ");
    $insStmt->execute([$businessId, $user['id'], $rating, $reviewText, $reviewStatus]);

    if (is_htmx()) {
        // Render updated full reviews section
        $revStmt = $db->prepare("
            SELECT r.id, r.user_id, r.rating, r.review_text, r.created_at, u.name as reviewer_name
            FROM reviews r
            JOIN users u ON r.user_id = u.id
            WHERE r.business_id = ? AND r.status = 'approved'
            ORDER BY r.created_at DESC
        ");
        $revStmt->execute([$businessId]);
        $reviews = $revStmt->fetchAll();

        $totalReviews = count($reviews);
        $avgRating = $totalReviews > 0 ? round(array_sum(array_column($reviews, 'rating')) / $totalReviews, 1) : 0.0;
        ?>
        <div class="card shadow-sm border-1 p-4" id="reviews-section">
            <?php if ($reviewStatus === 'pending'): ?>
                <div class="alert alert-info py-2 small mb-3">
                    <i class="bi bi-info-circle me-1"></i>Thank you! Your review has been submitted and is awaiting administrator moderation.
                </div>
            <?php else: ?>
                <div class="alert alert-success py-2 small mb-3">
                    <i class="bi bi-check-circle me-1"></i>Thank you! Your review has been published.
                </div>
            <?php endif; ?>

            <div class="d-flex justify-content-between align-items-center mb-3 border-bottom pb-2">
                <div>
                    <h2 class="h5 fw-bold mb-0">Customer Reviews</h2>
                    <span class="text-muted small"><?= $totalReviews ?> verified reviews</span>
                </div>
                <div class="text-end">
                    <div class="fs-4 fw-bold text-dark"><?= ($avgRating > 0 ? number_format($avgRating, 1) : '—') ?><span class="fs-6 text-muted">/5</span></div>
                    <div class="small"><?= render_stars($avgRating, false) ?></div>
                </div>
            </div>

            <div class="card bg-light border p-3 mb-3">
                <div class="d-flex justify-content-between align-items-start mb-2">
                    <div>
                        <span class="badge bg-success mb-1">Your Review</span>
                        <div class="small"><?= render_stars((float)$rating) ?></div>
                    </div>
                </div>
                <p class="small mb-1 text-dark"><?= e($reviewText) ?></p>
                <small class="text-muted">Just now</small>
            </div>

            <div class="d-flex flex-column gap-3">
                <?php foreach ($reviews as $rev): ?>
                    <div class="border-bottom pb-3">
                        <div class="d-flex justify-content-between align-items-center mb-1">
                            <strong class="text-dark"><?= e($rev['reviewer_name']) ?></strong>
                            <span class="text-muted small"><?= time_ago($rev['created_at']) ?></span>
                        </div>
                        <div class="mb-2">
                            <?= render_stars((float)$rev['rating'], false) ?>
                        </div>
                        <p class="text-secondary small mb-0 lh-base">
                            <?= e($rev['review_text']) ?>
                        </p>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php
        exit;
    }

    flash_set('success', 'Your review has been submitted.');
    header('Location: /business/' . urlencode($biz['slug']) . '#reviews-section');
    exit;
}
