-- ==========================================================
-- linkdir - Business & Service Directory
-- Database Schema for MySQL / MariaDB 10.4+ / PHP 8.2+
-- ==========================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------------------------------------
-- Table structure for `users`
-- ----------------------------------------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(191) NOT NULL,
  `password_hash` VARCHAR(255) NOT NULL,
  `role` ENUM('user', 'admin') NOT NULL DEFAULT 'user',
  `status` ENUM('active', 'suspended') NOT NULL DEFAULT 'active',
  `failed_logins` INT UNSIGNED NOT NULL DEFAULT 0,
  `lock_until` DATETIME NULL DEFAULT NULL,
  `last_login` DATETIME NULL DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_users_email` (`email`),
  KEY `idx_users_role` (`role`),
  KEY `idx_users_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------
-- Table structure for `categories`
-- ----------------------------------------------------------
DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(100) NOT NULL,
  `slug` VARCHAR(120) NOT NULL,
  `description` TEXT NULL DEFAULT NULL,
  `icon` VARCHAR(60) NOT NULL DEFAULT 'bi-briefcase',
  `status` ENUM('active', 'inactive') NOT NULL DEFAULT 'active',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_categories_slug` (`slug`),
  KEY `idx_categories_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------
-- Table structure for `businesses`
-- ----------------------------------------------------------
DROP TABLE IF EXISTS `businesses`;
CREATE TABLE `businesses` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` INT UNSIGNED NOT NULL,
  `category_id` INT UNSIGNED NOT NULL,
  `business_name` VARCHAR(150) NOT NULL,
  `slug` VARCHAR(180) NOT NULL,
  `website_url` VARCHAR(255) NULL DEFAULT NULL,
  `logo` VARCHAR(255) NULL DEFAULT NULL,
  `about` TEXT NOT NULL,
  `phone` VARCHAR(50) NULL DEFAULT NULL,
  `email` VARCHAR(191) NULL DEFAULT NULL,
  `address` VARCHAR(255) NULL DEFAULT NULL,
  `city` VARCHAR(100) NOT NULL DEFAULT '',
  `state` VARCHAR(100) NOT NULL DEFAULT '',
  `country` VARCHAR(100) NOT NULL DEFAULT 'United States',
  `status` ENUM('pending', 'approved', 'rejected', 'suspended') NOT NULL DEFAULT 'pending',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_businesses_slug` (`slug`),
  KEY `idx_businesses_user_id` (`user_id`),
  KEY `idx_businesses_category_id` (`category_id`),
  KEY `idx_businesses_status` (`status`),
  KEY `idx_businesses_city` (`city`),
  KEY `idx_businesses_state` (`state`),
  KEY `idx_businesses_country` (`country`),
  CONSTRAINT `fk_businesses_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_businesses_category` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------
-- Table structure for `reviews`
-- ----------------------------------------------------------
DROP TABLE IF EXISTS `reviews`;
CREATE TABLE `reviews` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `business_id` INT UNSIGNED NOT NULL,
  `user_id` INT UNSIGNED NOT NULL,
  `rating` TINYINT UNSIGNED NOT NULL,
  `review_text` TEXT NOT NULL,
  `status` ENUM('pending', 'approved', 'rejected') NOT NULL DEFAULT 'approved',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_reviews_unique_user_business` (`business_id`, `user_id`),
  KEY `idx_reviews_business_id` (`business_id`),
  KEY `idx_reviews_user_id` (`user_id`),
  KEY `idx_reviews_status` (`status`),
  CONSTRAINT `fk_reviews_business` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_reviews_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------
-- Table structure for `rate_limits`
-- ----------------------------------------------------------
DROP TABLE IF EXISTS `rate_limits`;
CREATE TABLE `rate_limits` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `action_key` VARCHAR(191) NOT NULL,
  `hits` INT UNSIGNED NOT NULL DEFAULT 1,
  `first_hit` INT UNSIGNED NOT NULL,
  `expire_time` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_rate_limits_action_key` (`action_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------
-- Table structure for `ads` (Ad Placement Management)
-- ----------------------------------------------------------
DROP TABLE IF EXISTS `ads`;
CREATE TABLE `ads` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `slot_key` VARCHAR(50) NOT NULL,
  `title` VARCHAR(100) NOT NULL,
  `type` ENUM('image', 'script') NOT NULL DEFAULT 'image',
  `image_url` TEXT NULL DEFAULT NULL,
  `link_url` TEXT NULL DEFAULT NULL,
  `script_code` MEDIUMTEXT NULL DEFAULT NULL,
  `status` ENUM('active', 'disabled') NOT NULL DEFAULT 'active',
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ads_slot_key` (`slot_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------
-- Table structure for `settings` (Site & Footer Configurations)
-- ----------------------------------------------------------
DROP TABLE IF EXISTS `settings`;
CREATE TABLE `settings` (
  `key_name` VARCHAR(100) NOT NULL,
  `value_content` LONGTEXT NULL,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`key_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------
-- Table structure for `pages` (Custom Dynamic Pages)
-- ----------------------------------------------------------
DROP TABLE IF EXISTS `pages`;
CREATE TABLE `pages` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` VARCHAR(255) NOT NULL,
  `slug` VARCHAR(191) NOT NULL UNIQUE,
  `content` MEDIUMTEXT NOT NULL,
  `meta_description` TEXT NULL,
  `status` ENUM('published', 'draft') NOT NULL DEFAULT 'published',
  `show_in_footer` TINYINT(1) NOT NULL DEFAULT 1,
  `sort_order` INT NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_pages_footer` (`show_in_footer`),
  KEY `idx_pages_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;

-- ----------------------------------------------------------
-- Default Seed Categories
-- ----------------------------------------------------------
INSERT INTO `categories` (`id`, `name`, `slug`, `description`, `icon`, `status`) VALUES
(1, 'Restaurants & Dining', 'restaurants-dining', 'Cafes, bistros, bakeries, food trucks, and fine dining.', 'bi-cup-hot', 'active'),
(2, 'Home & Trade Services', 'home-trade-services', 'Plumbing, electrical, roofing, HVAC, cleaning, and landscaping.', 'bi-tools', 'active'),
(3, 'Health & Medical', 'health-medical', 'Doctors, dentists, physical therapists, clinics, and wellness centers.', 'bi-heart-pulse', 'active'),
(4, 'Automotive Services', 'automotive-services', 'Auto repair, detailing, tire shops, towing, and dealerships.', 'bi-car-front', 'active'),
(5, 'Professional & Legal', 'professional-legal', 'Lawyers, certified accountants, consultants, and financial advisors.', 'bi-briefcase', 'active'),
(6, 'Beauty & Personal Care', 'beauty-personal-care', 'Hair salons, barbershops, spas, nail studios, and skincare.', 'bi-scissors', 'active'),
(7, 'Technology & Web Services', 'technology-web-services', 'IT support, software agencies, computer repair, and web design.', 'bi-laptop', 'active'),
(8, 'Real Estate & Property', 'real-estate-property', 'Realtors, property management, appraisals, and inspection.', 'bi-house-check', 'active'),
(9, 'Education & Tutoring', 'education-tutoring', 'Music lessons, language schools, driving schools, and academic tutors.', 'bi-book', 'active'),
(10, 'Fitness & Recreation', 'fitness-recreation', 'Gyms, martial arts, personal trainers, yoga, and dance studios.', 'bi-activity', 'active');

-- ----------------------------------------------------------
-- Default Ad Placements (Leaderboard & Sidebar)
-- ----------------------------------------------------------
INSERT INTO `ads` (`id`, `slot_key`, `title`, `type`, `image_url`, `link_url`, `script_code`, `status`) VALUES
(1, 'leaderboard_top', 'Directory Top Leaderboard (728x90)', 'image', 'https://placehold.co/728x90/e2e8f0/334155?text=Advertise+Here+-+Premium+Leaderboard+Banner+(728x90)', '#', '', 'active'),
(2, 'sidebar_directory', 'Directory Sidebar Ad (300x250)', 'image', 'https://placehold.co/300x250/e2e8f0/334155?text=Feature+Your+Business+Here+(300x250)', '#', '', 'active'),
(3, 'sidebar_business', 'Business Detail Sidebar Ad (300x250)', 'image', 'https://placehold.co/300x250/e2e8f0/334155?text=Partner+Promotion+Banner+(300x250)', '#', '', 'active'),
(4, 'leaderboard_business', 'Business Detail Bottom Leaderboard (728x90)', 'image', 'https://placehold.co/728x90/e2e8f0/334155?text=Sponsor+Placement+Area+(728x90)', '#', '', 'active');

-- ----------------------------------------------------------
-- Default Seed Users
-- Admin Login: admin@linkdir.local / AdminPass123!
-- User Login:  user@linkdir.local  / UserPass123!
-- ----------------------------------------------------------
INSERT INTO `users` (`id`, `name`, `email`, `password_hash`, `role`, `status`, `created_at`) VALUES
(1, 'Site Administrator', 'admin@linkdir.local', '$2y$10$OGF9Fk3OKyLfiwYoE.o.K.zpnUfzt/PpP06fq6kOjobIhr8Eu1dNi', 'admin', 'active', CURRENT_TIMESTAMP),
(2, 'Sarah Jenkins', 'user@linkdir.local', '$2y$10$PLIag4.PG28eqEs6xdMTj.dj715b9mPYGiyzgIfIY8tkHwq8j7osi', 'user', 'active', CURRENT_TIMESTAMP);

-- ----------------------------------------------------------
-- Sample Seed Businesses
-- ----------------------------------------------------------
INSERT INTO `businesses` (`id`, `user_id`, `category_id`, `business_name`, `slug`, `website_url`, `logo`, `about`, `phone`, `email`, `address`, `city`, `state`, `country`, `status`, `created_at`) VALUES
(1, 1, 2, 'Highland Heating & Air Conditioning', 'highland-heating-air-conditioning', 'https://example.com/highland-hvac', NULL, 'Highland Heating & Air Conditioning provides 24/7 residential and light commercial HVAC maintenance, heat pump installations, and duct cleaning. Family-owned and operated with over 18 years of licensed experience.', '(512) 555-0192', 'service@highlandhvac.local', '4402 Industrial Blvd, Suite B', '', 'Texas', 'United States', 'approved', CURRENT_TIMESTAMP),
(2, 2, 1, 'Saffron Table Bistro', 'saffron-table-bistro', 'https://example.com/saffron-table', NULL, 'Artisanal Mediterranean dining featuring organic wood-fired flatbreads, house-made pastas, and local wine pairings. Perfect for casual lunches or celebratory family dinners.', '(512) 555-8821', 'reservations@saffrontable.local', '118 E 6th Street', '', 'Texas', 'United States', 'approved', CURRENT_TIMESTAMP),
(3, 1, 3, 'Barton Springs Family Dental Care', 'barton-springs-family-dental-care', 'https://example.com/bartondental', NULL, 'Comprehensive dental care for adults and children. Services include teeth cleanings, painless cavity fillings, invisalign orthodontics, and cosmetic teeth whitening.', '(512) 555-3419', 'hello@bartondental.local', '2201 S Lamar Blvd', '', 'Texas', 'United States', 'approved', CURRENT_TIMESTAMP),
(4, 2, 4, 'Precision European Auto Repair', 'precision-european-auto-repair', 'https://example.com/precisionauto', NULL, 'ASE-certified technicians specializing in BMW, Audi, Mercedes-Benz, and Volkswagen service. Brake diagnostics, transmission fluid flushes, oil changes, and electrical troubleshooting.', '(512) 555-9014', 'techs@precisioneuro.local', '8204 Research Blvd', '', 'Texas', 'United States', 'approved', CURRENT_TIMESTAMP),
(5, 1, 5, 'Summit Hill Financial Planning', 'summit-hill-financial-planning', 'https://example.com/summithill', NULL, 'Fee-only fiduciary financial advisors helping small business owners, retirees, and young families optimize wealth management, estate planning, and tax strategy.', '(512) 555-4567', 'info@summithill.local', '701 Brazos St, Suite 1200', '', 'Texas', 'United States', 'approved', CURRENT_TIMESTAMP),
(6, 2, 2, 'Lone Star Master Plumbers', 'lone-star-master-plumbers', 'https://example.com/lonestarplumbing', NULL, 'Emergency plumbing repairs, water heater installation (tankless and traditional), drain clearing, and sewer line camera inspections. Transparent upfront pricing.', '(512) 555-7733', 'dispatch@lonestarplumbing.local', '3104 E 12th St', '', 'Texas', 'United States', 'approved', CURRENT_TIMESTAMP);

-- ----------------------------------------------------------
-- Sample Seed Reviews
-- ----------------------------------------------------------
INSERT INTO `reviews` (`business_id`, `user_id`, `rating`, `review_text`, `status`, `created_at`) VALUES
(1, 2, 5, 'Highland HVAC fixed our AC compressor on the same day during a 100-degree heatwave. Very professional and tidy technician!', 'approved', CURRENT_TIMESTAMP),
(2, 1, 5, 'The lamb flatbread and wood-fired seafood pasta were outstanding. Great ambiance and attentive staff.', 'approved', CURRENT_TIMESTAMP),
(3, 2, 5, 'Barton Springs Dental made my routine cleaning completely stress-free. Very gentle hygienist.', 'approved', CURRENT_TIMESTAMP),
(4, 1, 4, 'Diagnosed an intermittent check engine light on my BMW in under an hour. Solid communication throughout.', 'approved', CURRENT_TIMESTAMP),
(6, 1, 5, 'Arrived within 45 minutes to unclog a main bathroom line. Cleaned up afterward and explained prevention tips.', 'approved', CURRENT_TIMESTAMP);

-- ----------------------------------------------------------
-- Default Site & Footer Settings
-- ----------------------------------------------------------
INSERT INTO `settings` (`key_name`, `value_content`) VALUES
('footer_description', 'A lightweight, fast, and modern business & service directory. Helping clients find trusted service providers, professionals, and verified ratings with ease.'),
('footer_categories', '2,1,3,4,7'),
('footer_copyright', '&copy; 2026 <strong class=\"text-light\">linkdir</strong>. All rights reserved.'),
('footer_pages_title', 'Pages & Legal'),
('footer_categories_title', 'Popular Categories'),
('footer_biz_heading', 'For Business Owners'),
('footer_biz_text', 'Submit your business or service in under two minutes. Get discovered by clients searching for verified providers.'),
('footer_biz_button', 'List Your Business'),
('user_listing_limit', '5');

-- ----------------------------------------------------------
-- Default Seed Pages
-- ----------------------------------------------------------
INSERT INTO `pages` (`id`, `title`, `slug`, `content`, `meta_description`, `status`, `show_in_footer`, `sort_order`) VALUES
(1, 'About Us', 'about-us', '<h3>Welcome to linkdir</h3>\n<p>linkdir is a high-performance business and service directory crafted for modern communities. We connect local consumers with reputable, accredited service professionals, restaurants, healthcare providers, and local trades.</p>\n<p>Our mission is simple: provide verified reviews, transparent contact details, and a seamless discovery experience without clutter, invasive tracking, or slow load times.</p>\n<h4>Why Choose linkdir?</h4>\n<ul>\n<li><strong>Verified Local Listings:</strong> Every business is reviewed to ensure accurate contact information and credentials.</li>\n<li><strong>Authentic Community Feedback:</strong> Real reviews from verified patrons to help you make informed decisions.</li>\n<li><strong>Fast & Mobile Optimized:</strong> Accessible from any device with zero lag.</li>\n</ul>', 'Learn about linkdir, our mission to connect local consumers with trusted businesses, and our commitment to verified reviews.', 'published', 1, 1),
(2, 'Privacy Policy', 'privacy-policy', '<h3>Privacy Policy</h3>\n<p>Your privacy is important to us. This Privacy Policy outlines how linkdir collects, uses, and safeguards information when you visit our directory or submit listings.</p>\n<h4>Information We Collect</h4>\n<p>We only collect personal information that you voluntarily provide when creating an account, leaving a review, or listing a business. This may include your name, email address, and business contact details.</p>\n<h4>How We Use Information</h4>\n<p>We use this data solely to provide directory search features, authenticate listing owners, verify submitted reviews, and maintain platform security. We never sell your personal information to third-party data brokers.</p>\n<h4>Cookies & Security</h4>\n<p>We use essential session cookies to keep you signed in securely and defend against automated attacks with rate limiting and CSRF protection.</p>', 'Read the linkdir Privacy Policy to understand how we protect your personal data and respect your digital rights.', 'published', 1, 2),
(3, 'Terms of Service', 'terms-of-service', '<h3>Terms of Service</h3>\n<p>By accessing or using the linkdir directory, you agree to comply with and be bound by these Terms of Service.</p>\n<h4>Listing Standards</h4>\n<p>Business owners are responsible for ensuring that all information, business names, addresses, and licenses provided in listings are truthful, current, and not misleading. linkdir reserves the right to remove listings that violate community standards.</p>\n<h4>Review Guidelines</h4>\n<p>Reviews must reflect genuine first-hand experiences. Defamatory, abusive, fraudulent, or paid reviews are strictly prohibited and will be removed upon moderation.</p>\n<h4>Limitation of Liability</h4>\n<p>linkdir acts as an informational directory platform. We do not endorse or guarantee the specific quality of services provided by independent listed vendors.</p>', 'Terms and conditions governing the use of linkdir directory, listing guidelines, and user reviews.', 'published', 1, 3),
(4, 'Contact & Support', 'contact-us', '<h3>Contact & Help Desk</h3>\n<p>We are here to assist business owners, community members, and partners with any questions about listings, directory moderation, or advertising placements.</p>\n<div class=\"row g-3 my-3\">\n<div class=\"col-md-6\"><div class=\"p-3 bg-light rounded border\"><strong>General Inquiries</strong><p class=\"small text-muted mb-0\">Email: hello@linkdir.local<br>Response time: within 24 business hours</p></div></div>\n<div class=\"col-md-6\"><div class=\"p-3 bg-light rounded border\"><strong>Business Support</strong><p class=\"small text-muted mb-0\">Email: listings@linkdir.local<br>Phone: (512) 555-0199</p></div></div>\n</div>\n<p>To report an incorrect listing or request an ownership claim, please email our support desk with your business registration documents.</p>', 'Contact the linkdir support team for help with business listings, claims, or advertising opportunities.', 'published', 1, 4);


