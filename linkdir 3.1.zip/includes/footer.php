<?php
/**
 * linkdir - Modern Dynamic Reusable Footer Component
 */

$footerDesc = get_setting('footer_description', 'A lightweight, fast, and modern business & service directory. Helping clients find trusted service providers, professionals, and verified ratings with ease.');
$footerCatTitle = get_setting('footer_categories_title', 'Popular Categories');
$footerPagesTitle = get_setting('footer_pages_title', 'Pages & Legal');
$footerBizHeading = get_setting('footer_biz_heading', 'For Business Owners');
$footerBizText = get_setting('footer_biz_text', 'Submit your business or service in under two minutes. Get discovered by clients searching for verified providers.');
$footerBizButton = get_setting('footer_biz_button', 'List Your Business');
$footerCopyright = get_setting('footer_copyright', '&copy; ' . date('Y') . ' <strong class="text-light">linkdir</strong>. All rights reserved.');

$dynamicFooterCategories = get_footer_categories();
$dynamicFooterPages = get_footer_pages();
?>
</main>

<footer class="bg-dark text-light py-5 mt-auto border-top border-secondary">
    <div class="container">
        <div class="row g-4 mb-4">
            <!-- Column 1: Brand & Logo Description -->
            <div class="col-lg-4 col-md-6">
                <div class="d-flex align-items-center gap-2 mb-3">
                    <div class="brand-icon-box">
                        <i class="bi bi-compass-fill"></i>
                    </div>
                    <span class="fs-4 fw-bold text-white tracking-tight">linkdir</span>
                    <span class="brand-badge ms-1 text-light bg-dark border-secondary">Directory</span>
                </div>
                <p class="text-secondary small mb-3 lh-base">
                    <?= nl2br(e($footerDesc)) ?>
                </p>
                <div class="d-flex gap-3 text-secondary">
                    <a href="/businesses" class="text-secondary text-decoration-none small hover-white"><i class="bi bi-search me-1"></i>Search</a>
                    <a href="/sitemap.xml" class="text-secondary text-decoration-none small hover-white"><i class="bi bi-diagram-3 me-1"></i>Sitemap</a>
                    <?php if (auth_is_admin()): ?>
                        <a href="/admin/footer" class="text-primary text-decoration-none small hover-white"><i class="bi bi-gear-fill me-1"></i>Footer Settings</a>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Column 2: Selected Categories -->
            <div class="col-lg-3 col-md-6">
                <h6 class="text-white text-uppercase fw-bold mb-3 small" style="letter-spacing: 0.05em;"><?= e($footerCatTitle) ?></h6>
                <ul class="list-unstyled text-secondary small mb-0 d-flex flex-column gap-2">
                    <?php if (empty($dynamicFooterCategories)): ?>
                        <li class="text-muted small">No categories selected</li>
                    <?php else: ?>
                        <?php foreach ($dynamicFooterCategories as $fCat): ?>
                            <li>
                                <a href="/category/<?= e($fCat['slug']) ?>" class="text-secondary text-decoration-none hover-white d-inline-flex align-items-center">
                                    <i class="bi <?= e($fCat['icon'] ?: 'bi-chevron-right') ?> me-2 text-primary"></i><?= e($fCat['name']) ?>
                                </a>
                            </li>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </ul>
            </div>

            <!-- Column 3: Custom Pages Links -->
            <div class="col-lg-2 col-md-6">
                <h6 class="text-white text-uppercase fw-bold mb-3 small" style="letter-spacing: 0.05em;"><?= e($footerPagesTitle) ?></h6>
                <ul class="list-unstyled text-secondary small mb-0 d-flex flex-column gap-2">
                    <?php if (empty($dynamicFooterPages)): ?>
                        <li class="text-muted small">No pages published</li>
                    <?php else: ?>
                        <?php foreach ($dynamicFooterPages as $fPage): ?>
                            <li>
                                <a href="/page/<?= e($fPage['slug']) ?>" class="text-secondary text-decoration-none hover-white d-inline-flex align-items-center">
                                    <i class="bi bi-chevron-right me-1 text-primary"></i><?= e($fPage['title']) ?>
                                </a>
                            </li>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </ul>
            </div>

            <!-- Column 4: Business Owners CTA -->
            <div class="col-lg-3 col-md-6">
                <h6 class="text-white text-uppercase fw-bold mb-3 small" style="letter-spacing: 0.05em;"><?= e($footerBizHeading) ?></h6>
                <p class="text-secondary small mb-3 lh-base">
                    <?= e($footerBizText) ?>
                </p>
                <a href="<?= auth_check() ? '/dashboard/business/add' : '/register' ?>" class="btn btn-primary btn-sm">
                    <i class="bi bi-plus-lg me-1"></i><?= e($footerBizButton) ?>
                </a>
            </div>
        </div>

        <div class="pt-4 mt-4 border-top border-secondary text-secondary small d-flex flex-column flex-md-row justify-content-between align-items-center gap-2">
            <div>
                <?= $footerCopyright ?>
            </div>
            <div class="d-flex gap-3 align-items-center flex-wrap">
                <?php foreach (array_slice($dynamicFooterPages, 0, 3) as $subPage): ?>
                    <a href="/page/<?= e($subPage['slug']) ?>" class="text-secondary text-decoration-none hover-white"><?= e($subPage['title']) ?></a>
                    <span class="text-muted">&bull;</span>
                <?php endforeach; ?>
                <span class="text-secondary">PHP 8.2 + HTMX</span>
            </div>
        </div>
    </div>
</footer>

<!-- Bootstrap 5 Bundle with Popper JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>
