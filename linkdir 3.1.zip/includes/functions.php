<?php
/**
 * linkdir - Helper Functions & Utilities
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/database.php';

// Polyfills for mbstring if extension is missing
if (!function_exists('mb_strlen')) {
    function mb_strlen(string $string, ?string $encoding = null): int {
        return strlen($string);
    }
}
if (!function_exists('mb_substr')) {
    function mb_substr(string $string, int $start, ?int $length = null, ?string $encoding = null): string {
        return $length !== null ? substr($string, $start, $length) : substr($string, $start);
    }
}
if (!function_exists('mb_strimwidth')) {
    function mb_strimwidth(string $str, int $start, int $width, string $trimmarker = '', ?string $encoding = null): string {
        if (strlen($str) <= $width) {
            return $str;
        }
        $markerLen = strlen($trimmarker);
        return substr($str, $start, max(0, $width - $markerLen)) . $trimmarker;
    }
}

/**
 * Escape HTML output for XSS prevention.
 */
function e(?string $string): string {
    return htmlspecialchars($string ?? '', ENT_QUOTES, 'UTF-8');
}

/**
 * Generate a URL-friendly slug from a string.
 */
function slugify(string $text): string {
    $text = preg_replace('~[^\pL\d]+~u', '-', $text);
    $text = iconv('utf-8', 'us-ascii//TRANSLIT', $text);
    $text = preg_replace('~[^-\w]+~', '', $text);
    $text = trim($text, '-');
    $text = preg_replace('~-+~', '-', $text);
    $text = strtolower($text);

    if (empty($text)) {
        return 'n-a-' . substr(bin2hex(random_bytes(4)), 0, 6);
    }

    return $text;
}

/**
 * Render accessible star rating HTML.
 */
function render_stars(float $rating, bool $showNumber = true): string {
    $full = (int)floor($rating);
    $half = ($rating - $full >= 0.5) ? 1 : 0;
    $empty = 5 - $full - $half;

    $html = '<span class="star-rating text-warning" aria-label="' . number_format($rating, 1) . ' out of 5 stars">';
    for ($i = 0; $i < $full; $i++) {
        $html .= '<i class="bi bi-star-fill me-1" aria-hidden="true"></i>';
    }
    if ($half) {
        $html .= '<i class="bi bi-star-half me-1" aria-hidden="true"></i>';
    }
    for ($i = 0; $i < $empty; $i++) {
        $html .= '<i class="bi bi-star me-1 text-muted opacity-50" aria-hidden="true"></i>';
    }
    if ($showNumber) {
        $html .= '<span class="text-dark fw-bold ms-1">' . number_format($rating, 1) . '</span>';
    }
    $html .= '</span>';

    return $html;
}

/**
 * Format date for friendly display.
 */
function format_date(string $datetime): string {
    $ts = strtotime($datetime);
    return date('M j, Y', $ts);
}

/**
 * Human-readable relative time.
 */
function time_ago(string $datetime): string {
    $time = strtotime($datetime);
    $diff = time() - $time;

    if ($diff < 60) {
        return 'Just now';
    } elseif ($diff < 3600) {
        $min = round($diff / 60);
        return $min . ' min' . ($min > 1 ? 's' : '') . ' ago';
    } elseif ($diff < 86400) {
        $hrs = round($diff / 3600);
        return $hrs . ' hour' . ($hrs > 1 ? 's' : '') . ' ago';
    } elseif ($diff < 604800) {
        $days = round($diff / 86400);
        return $days . ' day' . ($days > 1 ? 's' : '') . ' ago';
    } else {
        return date('M j, Y', $time);
    }
}

/**
 * Check if the current request is an HTMX request.
 */
function is_htmx(): bool {
    return !empty($_SERVER['HTTP_HX_REQUEST']);
}

/**
 * Set a session flash message.
 */
function flash_set(string $type, string $message): void {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    $_SESSION['flash_messages'][] = [
        'type'    => $type, // 'success', 'danger', 'warning', 'info'
        'message' => $message
    ];
}

/**
 * Get and clear all flash messages.
 */
function flash_get(): array {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    $messages = $_SESSION['flash_messages'] ?? [];
    unset($_SESSION['flash_messages']);
    return $messages;
}

/**
 * Render flash messages as Bootstrap alerts.
 */
function flash_render(): string {
    $messages = flash_get();
    if (empty($messages)) {
        return '';
    }

    $html = '';
    foreach ($messages as $msg) {
        $type = htmlspecialchars($msg['type'], ENT_QUOTES, 'UTF-8');
        $text = htmlspecialchars($msg['message'], ENT_QUOTES, 'UTF-8');
        $html .= '<div class="alert alert-' . $type . ' alert-dismissible fade show my-3" role="alert">';
        $html .= $text;
        $html .= '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>';
        $html .= '</div>';
    }
    return $html;
}

/**
 * Get client IP address safely.
 */
function get_client_ip(): string {
    if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
        return $_SERVER['HTTP_CF_CONNECTING_IP'];
    }
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ips = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        return trim($ips[0]);
    }
    return $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
}

/**
 * Check if an action is rate limited.
 * 
 * @param string $actionKey Unique action identifier (e.g. "login_" . ip)
 * @param int $maxAttempts Maximum allowed attempts
 * @param int $window Window duration in seconds
 * @return bool True if allowed, false if rate limited
 */
function rate_limit_check(string $actionKey, int $maxAttempts, int $window): bool {
    try {
        $db = get_db();
        $now = time();

        // Delete expired rate limits
        $stmt = $db->prepare("DELETE FROM rate_limits WHERE expire_time < ?");
        $stmt->execute([$now]);

        // Check current hits
        $stmt = $db->prepare("SELECT hits FROM rate_limits WHERE action_key = ? AND expire_time >= ?");
        $stmt->execute([$actionKey, $now]);
        $row = $stmt->fetch();

        if ($row && $row['hits'] >= $maxAttempts) {
            return false; // Exceeded
        }

        return true;
    } catch (PDOException $e) {
        error_log("Rate limit error: " . $e->getMessage());
        return true; // Fail open if error
    }
}

/**
 * Record an attempt for rate limiting.
 */
function rate_limit_record(string $actionKey, int $window): void {
    try {
        $db = get_db();
        $now = time();
        $expire = $now + $window;

        $stmt = $db->prepare("SELECT id, hits FROM rate_limits WHERE action_key = ? AND expire_time >= ?");
        $stmt->execute([$actionKey, $now]);
        $row = $stmt->fetch();

        if ($row) {
            $stmt = $db->prepare("UPDATE rate_limits SET hits = hits + 1 WHERE id = ?");
            $stmt->execute([$row['id']]);
        } else {
            $stmt = $db->prepare("INSERT INTO rate_limits (action_key, hits, first_hit, expire_time) VALUES (?, 1, ?, ?)");
            $stmt->execute([$actionKey, $now, $expire]);
        }
    } catch (PDOException $e) {
        error_log("Rate limit record error: " . $e->getMessage());
    }
}

/**
 * Clear rate limit for an action.
 */
function rate_limit_clear(string $actionKey): void {
    try {
        $db = get_db();
        $stmt = $db->prepare("DELETE FROM rate_limits WHERE action_key = ?");
        $stmt->execute([$actionKey]);
    } catch (PDOException $e) {
        error_log("Rate limit clear error: " . $e->getMessage());
    }
}

/**
 * Validate and process an uploaded business logo image.
 * 
 * - Allowed types: JPG, JPEG, PNG, WebP (No SVG)
 * - Validates file size (max 2MB)
 * - Verifies real image content with getimagesize
 * - Checks MIME type
 * - Resizes large images using GD to max 800x800
 * - Generates random cryptographically safe filename
 * 
 * @param array $file $_FILES['logo'] array
 * @return string Uploaded filename
 * @throws Exception On validation or processing failure
 */
function handle_image_upload(array $file): string {
    if (!isset($file['error']) || is_array($file['error'])) {
        throw new Exception('Invalid upload parameter.');
    }

    if ($file['error'] === UPLOAD_ERR_NO_FILE) {
        throw new Exception('No image file selected.');
    }

    if ($file['error'] !== UPLOAD_ERR_OK) {
        throw new Exception('File upload error code: ' . $file['error']);
    }

    if ($file['size'] > MAX_UPLOAD_SIZE_BYTES) {
        throw new Exception('File size exceeds the 2 MB limit.');
    }

    // Verify actual image via getimagesize
    $imageInfo = @getimagesize($file['tmp_name']);
    if ($imageInfo === false) {
        throw new Exception('The uploaded file is not a valid image.');
    }

    $mime = $imageInfo['mime'];
    $allowedMimes = [
        'image/jpeg' => 'jpg',
        'image/pjpeg' => 'jpg',
        'image/png'  => 'png',
        'image/webp' => 'webp'
    ];

    if (!isset($allowedMimes[$mime])) {
        throw new Exception('Unsupported image format. Only JPG, PNG, and WebP are allowed.');
    }

    $ext = $allowedMimes[$mime];
    $targetDir = UPLOAD_DIR;
    if (!is_dir($targetDir)) {
        mkdir($targetDir, 0755, true);
    }

    // Generate random filename
    $newFilename = bin2hex(random_bytes(16)) . '.' . $ext;
    $targetPath = $targetDir . '/' . $newFilename;

    $width = $imageInfo[0];
    $height = $imageInfo[1];
    $maxWidth = MAX_IMAGE_WIDTH;
    $maxHeight = MAX_IMAGE_HEIGHT;

    // If image needs resizing and GD is available
    if (($width > $maxWidth || $height > $maxHeight) && extension_loaded('gd')) {
        $ratio = min($maxWidth / $width, $maxHeight / $height);
        $newWidth = (int)round($width * $ratio);
        $newHeight = (int)round($height * $ratio);

        $srcImage = null;
        switch ($mime) {
            case 'image/jpeg':
            case 'image/pjpeg':
                $srcImage = @imagecreatefromjpeg($file['tmp_name']);
                break;
            case 'image/png':
                $srcImage = @imagecreatefrompng($file['tmp_name']);
                break;
            case 'image/webp':
                if (function_exists('imagecreatefromwebp')) {
                    $srcImage = @imagecreatefromwebp($file['tmp_name']);
                }
                break;
        }

        if ($srcImage) {
            $destImage = imagecreatetruecolor($newWidth, $newHeight);

            // Handle transparency for PNG/WebP
            if ($ext === 'png' || $ext === 'webp') {
                imagealphablending($destImage, false);
                imagesavealpha($destImage, true);
                $transparent = imagecolorallocatealpha($destImage, 255, 255, 255, 127);
                imagefilledrectangle($destImage, 0, 0, $newWidth, $newHeight, $transparent);
            }

            imagecopyresampled($destImage, $srcImage, 0, 0, 0, 0, $newWidth, $newHeight, $width, $height);

            $saved = false;
            switch ($ext) {
                case 'jpg':
                    $saved = imagejpeg($destImage, $targetPath, 85);
                    break;
                case 'png':
                    $saved = imagepng($destImage, $targetPath, 8);
                    break;
                case 'webp':
                    if (function_exists('imagewebp')) {
                        $saved = imagewebp($destImage, $targetPath, 85);
                    }
                    break;
            }

            imagedestroy($srcImage);
            imagedestroy($destImage);

            if ($saved) {
                return $newFilename;
            }
        }
    }

    // Direct move if no resize needed or resize fallback
    if (!move_uploaded_file($file['tmp_name'], $targetPath)) {
        throw new Exception('Failed to save uploaded image to destination.');
    }

    return $newFilename;
}

/**
 * Retrieve an ad slot configuration.
 */
function get_ad(string $slotKey): ?array {
    static $adCache = [];
    if (array_key_exists($slotKey, $adCache)) {
        return $adCache[$slotKey];
    }

    try {
        $db = get_db();
        $stmt = $db->prepare("SELECT * FROM ads WHERE slot_key = ? LIMIT 1");
        $stmt->execute([$slotKey]);
        $ad = $stmt->fetch();
        $adCache[$slotKey] = $ad ?: null;
        return $adCache[$slotKey];
    } catch (Exception $e) {
        return null;
    }
}

/**
 * Render HTML for an ad slot.
 */
function render_ad(string $slotKey, string $wrapperClass = ''): string {
    $ad = get_ad($slotKey);
    if (!$ad || ($ad['status'] ?? '') !== 'active') {
        return '';
    }

    $html = '<div class="ad-placement-container my-3 ' . htmlspecialchars($wrapperClass, ENT_QUOTES, 'UTF-8') . '">';
    $html .= '<div class="ad-placement-box text-center p-2 rounded border bg-light shadow-xs">';
    $html .= '<div class="ad-label text-muted text-uppercase mb-1" style="font-size:0.65rem; letter-spacing:1px; font-weight:600;">SPONSORED</div>';

    if (($ad['type'] ?? 'image') === 'script') {
        $html .= '<div class="ad-script-wrap d-flex justify-content-center overflow-hidden">' . ($ad['script_code'] ?? '') . '</div>';
    } else {
        $imgUrl = !empty($ad['image_url']) ? htmlspecialchars($ad['image_url'], ENT_QUOTES, 'UTF-8') : '';
        $linkUrl = !empty($ad['link_url']) ? htmlspecialchars($ad['link_url'], ENT_QUOTES, 'UTF-8') : '#';
        $altText = !empty($ad['title']) ? htmlspecialchars($ad['title'], ENT_QUOTES, 'UTF-8') : 'Advertisement';

        if ($imgUrl !== '') {
            $html .= '<a href="' . $linkUrl . '" target="_blank" rel="noopener noreferrer nofollow" class="d-inline-block text-decoration-none">';
            $html .= '<img src="' . $imgUrl . '" alt="' . $altText . '" class="img-fluid rounded" style="max-width:100%; height:auto;" loading="lazy">';
            $html .= '</a>';
        }
    }

    $html .= '</div>';
    $html .= '</div>';

    return $html;
}

/**
 * Retrieve a setting value from the settings table.
 */
function get_setting(string $key, string $default = ''): string {
    static $settingsCache = null;
    if ($settingsCache === null) {
        $settingsCache = [];
        try {
            $db = get_db();
            $stmt = $db->query("SELECT key_name, value_content FROM settings");
            while ($row = $stmt->fetch()) {
                $settingsCache[$row['key_name']] = $row['value_content'];
            }
        } catch (Exception $e) {
            // Table might not be ready yet
        }
    }

    return array_key_exists($key, $settingsCache) ? (string)$settingsCache[$key] : $default;
}

/**
 * Update or insert a setting value into the settings table.
 */
function set_setting(string $key, string $value): bool {
    try {
        $db = get_db();
        $stmt = $db->prepare("SELECT COUNT(*) FROM settings WHERE key_name = ?");
        $stmt->execute([$key]);
        if ((int)$stmt->fetchColumn() > 0) {
            $upd = $db->prepare("UPDATE settings SET value_content = ?, updated_at = CURRENT_TIMESTAMP WHERE key_name = ?");
            $upd->execute([$value, $key]);
        } else {
            $ins = $db->prepare("INSERT INTO settings (key_name, value_content, updated_at) VALUES (?, ?, CURRENT_TIMESTAMP)");
            $ins->execute([$key, $value]);
        }
        return true;
    } catch (Exception $e) {
        error_log("set_setting error: " . $e->getMessage());
        return false;
    }
}

/**
 * Get categories selected for footer display.
 * 
 * @return array List of category rows
 */
function get_footer_categories(): array {
    $db = get_db();
    $savedIds = get_setting('footer_categories', '');

    if (!empty($savedIds)) {
        $idArray = array_filter(array_map('intval', explode(',', $savedIds)));
        if (!empty($idArray)) {
            $placeholders = implode(',', array_fill(0, count($idArray), '?'));
            $stmt = $db->prepare("SELECT * FROM categories WHERE id IN ($placeholders) AND status = 'active'");
            $stmt->execute($idArray);
            $cats = $stmt->fetchAll();

            if (!empty($cats)) {
                // Preserve order specified in settings
                $idOrder = array_flip(array_values($idArray));
                usort($cats, function($a, $b) use ($idOrder) {
                    return ($idOrder[(int)$a['id']] ?? 999) <=> ($idOrder[(int)$b['id']] ?? 999);
                });
                return $cats;
            }
        }
    }

    // Default fallback: Top 5 active categories
    $stmt = $db->query("SELECT * FROM categories WHERE status = 'active' ORDER BY id ASC LIMIT 5");
    return $stmt->fetchAll() ?: [];
}

/**
 * Get custom pages configured to display in footer.
 * 
 * @return array List of page rows
 */
function get_footer_pages(): array {
    try {
        $db = get_db();
        $stmt = $db->query("SELECT id, title, slug, sort_order FROM pages WHERE status = 'published' AND show_in_footer = 1 ORDER BY sort_order ASC, title ASC");
        return $stmt->fetchAll() ?: [];
    } catch (Exception $e) {
        return [];
    }
}

/**
 * Get the maximum business listings allowed for a user.
 * 0 or negative means Unlimited.
 *
 * @param int|null $userId Optional specific user ID to check for individual override
 * @return int Allowed limit (0 = Unlimited)
 */
function get_user_listing_limit(?int $userId = null): int {
    $db = get_db();

    // Check if user has an individual custom limit override
    if ($userId !== null && $userId > 0) {
        try {
            $uStmt = $db->prepare("SELECT custom_listing_limit FROM users WHERE id = ? LIMIT 1");
            $uStmt->execute([$userId]);
            $custom = $uStmt->fetchColumn();
            if ($custom !== false && $custom !== null && $custom !== '') {
                return max(0, (int)$custom);
            }
        } catch (Exception $e) {
            // Column may not exist or error
        }
    }

    // Default to global setting (defaults to 5)
    $val = get_setting('user_listing_limit', '5');
    if ($val === '' || $val === null) {
        return 5;
    }

    return max(0, (int)$val);
}

/**
 * Set the global maximum business listings allowed per standard user.
 * 
 * @param int $limit Max number of listings (0 = unlimited)
 * @return bool
 */
function set_user_listing_limit(int $limit): bool {
    return set_setting('user_listing_limit', (string)max(0, $limit));
}

/**
 * Count how many business listings a user has created (all statuses).
 * 
 * @param int $userId
 * @return int Total listings count
 */
function get_user_listing_count(int $userId): int {
    $db = get_db();
    $stmt = $db->prepare("SELECT COUNT(*) FROM businesses WHERE user_id = ?");
    $stmt->execute([$userId]);
    return (int)$stmt->fetchColumn();
}

/**
 * Get comprehensive listing limit allowance info for a user.
 *
 * @param array|int $user User array or user ID
 * @return array Allowance metadata
 */
function get_user_listing_limit_info($user): array {
    $db = get_db();

    if (is_numeric($user)) {
        $uStmt = $db->prepare("SELECT id, role, custom_listing_limit FROM users WHERE id = ? LIMIT 1");
        $uStmt->execute([(int)$user]);
        $user = $uStmt->fetch() ?: ['id' => (int)$user, 'role' => 'user'];
    }

    $userId = (int)($user['id'] ?? 0);
    $isAdmin = (($user['role'] ?? '') === 'admin');
    $count = get_user_listing_count($userId);
    $limit = get_user_listing_limit($userId);

    $isUnlimited = $isAdmin || ($limit === 0);
    $isReached = !$isUnlimited && ($count >= $limit);
    $remaining = $isUnlimited ? 999999 : max(0, $limit - $count);
    $percentage = ($limit > 0) ? min(100, (int)round(($count / $limit) * 100)) : 0;

    return [
        'user_id'      => $userId,
        'is_admin'     => $isAdmin,
        'count'        => $count,
        'limit'        => $limit,
        'is_unlimited' => $isUnlimited,
        'is_reached'   => $isReached,
        'remaining'    => $remaining,
        'percentage'   => $percentage,
        'label'        => $isUnlimited ? 'Unlimited' : ($count . ' of ' . $limit . ' listings used'),
    ];
}

/**
 * Determine if a user is permitted to create a new business listing.
 *
 * @param array|int $user
 * @return bool True if permitted
 */
function can_user_add_listing($user): bool {
    $info = get_user_listing_limit_info($user);
    return !$info['is_reached'];
}


