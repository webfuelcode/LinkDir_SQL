<?php
/**
 * linkdir - Database Connection via PDO
 * 
 * Supports both MySQL/MariaDB (default on cPanel) and SQLite
 * using strictly prepared statements and secure connection options.
 */

require_once __DIR__ . '/../config/config.php';

function get_db(): PDO {
    static $pdo = null;

    if ($pdo !== null) {
        return $pdo;
    }

    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];

    try {
        if (DB_DRIVER === 'mysql') {
            $dsn = sprintf(
                'mysql:host=%s;port=%s;dbname=%s;charset=%s',
                DB_HOST,
                DB_PORT,
                DB_NAME,
                DB_CHARSET
            );
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
            $pdo->exec("SET NAMES " . DB_CHARSET);
        } else {
            // SQLite driver (for instant portable zero-config run)
            $dbPath = DB_SQLITE_PATH;
            $dir = dirname($dbPath);
            if (!is_dir($dir)) {
                mkdir($dir, 0755, true);
            }
            $isNew = !file_exists($dbPath);
            $pdo = new PDO('sqlite:' . $dbPath, null, null, $options);
            $pdo->exec('PRAGMA foreign_keys = ON;');
            $pdo->exec('PRAGMA journal_mode = WAL;');

            if ($isNew) {
                bootstrap_sqlite_schema($pdo);
            }
        }
    } catch (PDOException $e) {
        error_log('Database Connection Error: ' . $e->getMessage());
        if (defined('APP_DEBUG') && APP_DEBUG) {
            die('Database Connection Error: Please check database configuration in config/config.php or run the installer at <a href="/install">/install</a>.');
        } else {
            die('Database error. Please try again later.');
        }
    }

    ensure_extended_schema($pdo);
    return $pdo;
}

/**
 * Bootstrap SQLite schema if sqlite driver is used and database file is new.
 */
function bootstrap_sqlite_schema(PDO $pdo): void {
    $schema = "
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'user',
        status TEXT NOT NULL DEFAULT 'active',
        failed_logins INTEGER NOT NULL DEFAULT 0,
        lock_until DATETIME NULL,
        last_login DATETIME NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS categories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        slug TEXT NOT NULL UNIQUE,
        description TEXT NULL,
        icon TEXT NOT NULL DEFAULT 'bi-briefcase',
        status TEXT NOT NULL DEFAULT 'active',
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS businesses (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        category_id INTEGER NOT NULL,
        business_name TEXT NOT NULL,
        slug TEXT NOT NULL UNIQUE,
        website_url TEXT NULL,
        logo TEXT NULL,
        about TEXT NOT NULL,
        phone TEXT NULL,
        email TEXT NULL,
        address TEXT NULL,
        city TEXT NOT NULL DEFAULT '',
        state TEXT NOT NULL DEFAULT '',
        country TEXT NOT NULL DEFAULT 'United States',
        status TEXT NOT NULL DEFAULT 'pending',
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE RESTRICT
    );

    CREATE TABLE IF NOT EXISTS reviews (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        business_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        rating INTEGER NOT NULL,
        review_text TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'approved',
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(business_id, user_id),
        FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS rate_limits (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        action_key TEXT NOT NULL,
        hits INTEGER NOT NULL DEFAULT 1,
        first_hit INTEGER NOT NULL,
        expire_time INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS ads (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        slot_key TEXT NOT NULL UNIQUE,
        title TEXT NOT NULL,
        type TEXT NOT NULL DEFAULT 'image',
        image_url TEXT NULL,
        link_url TEXT NULL,
        script_code TEXT NULL,
        status TEXT NOT NULL DEFAULT 'active',
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
    );

    CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
    CREATE INDEX IF NOT EXISTS idx_businesses_slug ON businesses(slug);
    CREATE INDEX IF NOT EXISTS idx_businesses_status ON businesses(status);
    CREATE INDEX IF NOT EXISTS idx_businesses_cat ON businesses(category_id);
    CREATE INDEX IF NOT EXISTS idx_businesses_city ON businesses(city);
    CREATE INDEX IF NOT EXISTS idx_reviews_biz ON reviews(business_id);
    ";

    $pdo->exec($schema);

    // Populate initial categories
    $stmt = $pdo->prepare("INSERT OR IGNORE INTO categories (id, name, slug, description, icon, status) VALUES (?, ?, ?, ?, ?, ?)");
    $cats = [
        [1, 'Restaurants & Dining', 'restaurants-dining', 'Cafes, bistros, bakeries, food trucks, and fine dining.', 'bi-cup-hot', 'active'],
        [2, 'Home & Trade Services', 'home-trade-services', 'Plumbing, electrical, roofing, HVAC, cleaning, and landscaping.', 'bi-tools', 'active'],
        [3, 'Health & Medical', 'health-medical', 'Doctors, dentists, physical therapists, clinics, and wellness centers.', 'bi-heart-pulse', 'active'],
        [4, 'Automotive Services', 'automotive-services', 'Auto repair, detailing, tire shops, towing, and dealerships.', 'bi-car-front', 'active'],
        [5, 'Professional & Legal', 'professional-legal', 'Lawyers, certified accountants, consultants, and financial advisors.', 'bi-briefcase', 'active'],
        [6, 'Beauty & Personal Care', 'beauty-personal-care', 'Hair salons, barbershops, spas, nail studios, and skincare.', 'bi-scissors', 'active'],
        [7, 'Technology & Web Services', 'technology-web-services', 'IT support, software agencies, computer repair, and web design.', 'bi-laptop', 'active'],
        [8, 'Real Estate & Property', 'real-estate-property', 'Realtors, property management, appraisals, and inspection.', 'bi-house-check', 'active'],
        [9, 'Education & Tutoring', 'education-tutoring', 'Music lessons, language schools, driving schools, and academic tutors.', 'bi-book', 'active'],
        [10, 'Fitness & Recreation', 'fitness-recreation', 'Gyms, martial arts, personal trainers, yoga, and dance studios.', 'bi-activity', 'active']
    ];
    foreach ($cats as $cat) {
        $stmt->execute($cat);
    }

    // Populate default ad slots
    $adStmt = $pdo->prepare("INSERT OR IGNORE INTO ads (slot_key, title, type, image_url, link_url, script_code, status) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $seedAds = [
        ['leaderboard_top', 'Directory Top Leaderboard (728x90)', 'image', 'https://placehold.co/728x90/e2e8f0/334155?text=Advertise+Here+-+Premium+Leaderboard+Banner+(728x90)', '#', '', 'active'],
        ['sidebar_directory', 'Directory Sidebar Ad (300x250)', 'image', 'https://placehold.co/300x250/e2e8f0/334155?text=Feature+Your+Business+Here+(300x250)', '#', '', 'active'],
        ['sidebar_business', 'Business Detail Sidebar Ad (300x250)', 'image', 'https://placehold.co/300x250/e2e8f0/334155?text=Partner+Promotion+Banner+(300x250)', '#', '', 'active'],
        ['leaderboard_business', 'Business Detail Bottom Leaderboard (728x90)', 'image', 'https://placehold.co/728x90/e2e8f0/334155?text=Sponsor+Placement+Area+(728x90)', '#', '', 'active']
    ];
    foreach ($seedAds as $sa) {
        $adStmt->execute($sa);
    }
}

/**
 * Ensure extended schema (pages, settings) exist and have default seeds.
 */
function ensure_extended_schema(PDO $pdo): void {
    static $checked = false;
    if ($checked) {
        return;
    }
    $checked = true;

    try {
        $driver = $pdo->getAttribute(PDO::ATTR_DRIVER_NAME);
        
        if ($driver === 'sqlite') {
            $pdo->exec("
                CREATE TABLE IF NOT EXISTS settings (
                    key_name TEXT PRIMARY KEY,
                    value_content TEXT NULL,
                    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
                );

                CREATE TABLE IF NOT EXISTS pages (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    title TEXT NOT NULL,
                    slug TEXT NOT NULL UNIQUE,
                    content TEXT NOT NULL,
                    meta_description TEXT NULL,
                    status TEXT NOT NULL DEFAULT 'published',
                    show_in_footer INTEGER NOT NULL DEFAULT 1,
                    sort_order INTEGER NOT NULL DEFAULT 0,
                    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
                );

                CREATE INDEX IF NOT EXISTS idx_pages_slug ON pages(slug);
                CREATE INDEX IF NOT EXISTS idx_pages_footer ON pages(show_in_footer);
            ");
        } else {
            // MySQL / MariaDB
            $pdo->exec("
                CREATE TABLE IF NOT EXISTS `settings` (
                    `key_name` VARCHAR(100) NOT NULL,
                    `value_content` LONGTEXT NULL,
                    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    PRIMARY KEY (`key_name`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

                CREATE TABLE IF NOT EXISTS `pages` (
                    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                    `title` VARCHAR(255) NOT NULL,
                    `slug` VARCHAR(191) NOT NULL UNIQUE,
                    `content` MEDIUMTEXT NOT NULL,
                    `meta_description` TEXT NULL,
                    `status` ENUM('published', 'draft') NOT NULL DEFAULT 'published',
                    `show_in_footer` TINYINT(1) NOT NULL DEFAULT 1,
                    `sort_order` INT NOT NULL DEFAULT 0,
                    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    PRIMARY KEY (`id`),
                    KEY `idx_pages_footer` (`show_in_footer`),
                    KEY `idx_pages_status` (`status`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
            ");
        }

        // Seed default settings if empty
        $stmtCount = $pdo->query("SELECT COUNT(*) FROM settings");
        if ((int)$stmtCount->fetchColumn() === 0) {
            $stmtSet = $pdo->prepare("INSERT INTO settings (key_name, value_content) VALUES (?, ?)");
            $defaultSettings = [
                ['footer_description', 'A lightweight, fast, and modern business & service directory. Helping clients find trusted service providers, professionals, and verified ratings with ease.'],
                ['footer_categories', '2,1,3,4,7'],
                ['footer_copyright', '&copy; ' . date('Y') . ' <strong class="text-light">linkdir</strong>. All rights reserved.'],
                ['footer_pages_title', 'Pages & Legal'],
                ['footer_categories_title', 'Popular Categories'],
                ['footer_biz_heading', 'For Business Owners'],
                ['footer_biz_text', 'Submit your business or service in under two minutes. Get discovered by clients searching for verified providers.'],
                ['footer_biz_button', 'List Your Business'],
                ['user_listing_limit', '5'],
            ];
            foreach ($defaultSettings as $ds) {
                $stmtSet->execute($ds);
            }
        } else {
            // Ensure user_listing_limit exists if settings table already existed
            $chkLimit = $pdo->prepare("SELECT COUNT(*) FROM settings WHERE key_name = 'user_listing_limit'");
            $chkLimit->execute();
            if ((int)$chkLimit->fetchColumn() === 0) {
                $insLimit = $pdo->prepare("INSERT INTO settings (key_name, value_content) VALUES ('user_listing_limit', '5')");
                $insLimit->execute();
            }
        }

        // Try adding custom_listing_limit column to users table if not exists
        try {
            if ($driver === 'sqlite') {
                $cols = $pdo->query("PRAGMA table_info(users)")->fetchAll();
                $hasCol = false;
                foreach ($cols as $col) {
                    if ($col['name'] === 'custom_listing_limit') {
                        $hasCol = true;
                        break;
                    }
                }
                if (!$hasCol) {
                    $pdo->exec("ALTER TABLE users ADD COLUMN custom_listing_limit INTEGER NULL DEFAULT NULL");
                }
            } else {
                $chkCol = $pdo->query("SHOW COLUMNS FROM `users` LIKE 'custom_listing_limit'")->fetch();
                if (!$chkCol) {
                    $pdo->exec("ALTER TABLE `users` ADD COLUMN `custom_listing_limit` INT NULL DEFAULT NULL AFTER `status`");
                }
            }
        } catch (Exception $colEx) {
            // Non-blocking if already exists or permission denied
        }

        // Seed default pages if empty
        $pageCount = $pdo->query("SELECT COUNT(*) FROM pages");
        if ((int)$pageCount->fetchColumn() === 0) {
            $stmtPage = $pdo->prepare("INSERT INTO pages (title, slug, content, meta_description, status, show_in_footer, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $defaultPages = [
                [
                    'About Us',
                    'about-us',
                    "<h3>Welcome to linkdir</h3>\n<p>linkdir is a high-performance business and service directory crafted for modern communities. We connect local consumers with reputable, accredited service professionals, restaurants, healthcare providers, and local trades.</p>\n<p>Our mission is simple: provide verified reviews, transparent contact details, and a seamless discovery experience without clutter, invasive tracking, or slow load times.</p>\n<h4>Why Choose linkdir?</h4>\n<ul>\n<li><strong>Verified Local Listings:</strong> Every business is reviewed to ensure accurate contact information and credentials.</li>\n<li><strong>Authentic Community Feedback:</strong> Real reviews from verified patrons to help you make informed decisions.</li>\n<li><strong>Fast & Mobile Optimized:</strong> Accessible from any device with zero lag.</li>\n</ul>",
                    'Learn about linkdir, our mission to connect local consumers with trusted businesses, and our commitment to verified reviews.',
                    'published',
                    1,
                    1
                ],
                [
                    'Privacy Policy',
                    'privacy-policy',
                    "<h3>Privacy Policy</h3>\n<p>Your privacy is important to us. This Privacy Policy outlines how linkdir collects, uses, and safeguards information when you visit our directory or submit listings.</p>\n<h4>Information We Collect</h4>\n<p>We only collect personal information that you voluntarily provide when creating an account, leaving a review, or listing a business. This may include your name, email address, and business contact details.</p>\n<h4>How We Use Information</h4>\n<p>We use this data solely to provide directory search features, authenticate listing owners, verify submitted reviews, and maintain platform security. We never sell your personal information to third-party data brokers.</p>\n<h4>Cookies & Security</h4>\n<p>We use essential session cookies to keep you signed in securely and defend against automated attacks with rate limiting and CSRF protection.</p>",
                    'Read the linkdir Privacy Policy to understand how we protect your personal data and respect your digital rights.',
                    'published',
                    1,
                    2
                ],
                [
                    'Terms of Service',
                    'terms-of-service',
                    "<h3>Terms of Service</h3>\n<p>By accessing or using the linkdir directory, you agree to comply with and be bound by these Terms of Service.</p>\n<h4>Listing Standards</h4>\n<p>Business owners are responsible for ensuring that all information, business names, addresses, and licenses provided in listings are truthful, current, and not misleading. linkdir reserves the right to remove listings that violate community standards.</p>\n<h4>Review Guidelines</h4>\n<p>Reviews must reflect genuine first-hand experiences. Defamatory, abusive, fraudulent, or paid reviews are strictly prohibited and will be removed upon moderation.</p>\n<h4>Limitation of Liability</h4>\n<p>linkdir acts as an informational directory platform. We do not endorse or guarantee the specific quality of services provided by independent listed vendors.</p>",
                    'Terms and conditions governing the use of linkdir directory, listing guidelines, and user reviews.',
                    'published',
                    1,
                    3
                ],
                [
                    'Contact & Support',
                    'contact-us',
                    "<h3>Contact & Help Desk</h3>\n<p>We are here to assist business owners, community members, and partners with any questions about listings, directory moderation, or advertising placements.</p>\n<div class=\"row g-3 my-3\">\n<div class=\"col-md-6\"><div class=\"p-3 bg-light rounded border\"><strong>General Inquiries</strong><p class=\"small text-muted mb-0\">Email: hello@linkdir.local<br>Response time: within 24 business hours</p></div></div>\n<div class=\"col-md-6\"><div class=\"p-3 bg-light rounded border\"><strong>Business Support</strong><p class=\"small text-muted mb-0\">Email: listings@linkdir.local<br>Phone: (512) 555-0199</p></div></div>\n</div>\n<p>To report an incorrect listing or request an ownership claim, please email our support desk with your business registration documents.</p>",
                    'Contact the linkdir support team for help with business listings, claims, or advertising opportunities.',
                    'published',
                    1,
                    4
                ]
            ];
            foreach ($defaultPages as $dp) {
                $stmtPage->execute($dp);
            }
        }
    } catch (Exception $e) {
        error_log("ensure_extended_schema error: " . $e->getMessage());
    }
}

