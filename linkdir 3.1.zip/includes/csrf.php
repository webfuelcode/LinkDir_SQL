<?php
/**
 * linkdir - CSRF Protection Module
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Get or generate the CSRF token for the current session.
 */
function csrf_token(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Render a hidden HTML input containing the CSRF token.
 */
function csrf_field(): string {
    $token = htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8');
    return '<input type="hidden" name="csrf_token" value="' . $token . '">';
}

/**
 * Render a meta tag containing the CSRF token for HTMX / JS.
 */
function csrf_meta(): string {
    $token = htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8');
    return '<meta name="csrf-token" content="' . $token . '">';
}

/**
 * Verify CSRF token from POST body or X-CSRF-Token header.
 * 
 * @param string|null $token Optional explicit token to verify
 * @return bool True if valid, false otherwise
 */
function csrf_verify(?string $token = null): bool {
    $expected = csrf_token();

    if ($token === null) {
        if (!empty($_POST['csrf_token'])) {
            $token = $_POST['csrf_token'];
        } elseif (!empty($_SERVER['HTTP_X_CSRF_TOKEN'])) {
            $token = $_SERVER['HTTP_X_CSRF_TOKEN'];
        }
    }

    if (empty($token) || !is_string($token)) {
        return false;
    }

    return hash_equals($expected, $token);
}

/**
 * Enforce CSRF validation. Terminates execution with 403 if invalid.
 */
function csrf_require(): void {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (!csrf_verify()) {
            http_response_code(403);
            if (!empty($_SERVER['HTTP_HX_REQUEST'])) {
                echo '<div class="alert alert-danger mb-0">Security token expired or invalid. Please refresh the page.</div>';
                exit;
            }
            die('Invalid or expired security token (CSRF). Please go back, refresh the page, and try again.');
        }
    }
}
