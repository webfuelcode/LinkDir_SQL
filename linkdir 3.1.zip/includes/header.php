<?php
/**
 * linkdir - Reusable Header Component
 * 
 * Supports dynamic SEO tags, OpenGraph, Canonical URLs, and JSON-LD schema.
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/csrf.php';

$siteName = SITE_NAME;
$siteTagline = SITE_TAGLINE;

$title = !empty($pageTitle) ? e($pageTitle) . ' | ' . e($siteName) : e($siteName) . ' - ' . e($siteTagline);
$description = !empty($pageDescription) ? e($pageDescription) : 'Discover trusted local businesses, professionals, and service providers with verified reviews on ' . e($siteName) . '.';
$canonical = !empty($canonicalUrl) ? $canonicalUrl : (isset($_SERVER['REQUEST_URI']) ? htmlspecialchars($_SERVER['REQUEST_URI'], ENT_QUOTES, 'UTF-8') : '/');
$ogType = !empty($ogType) ? $ogType : 'website';
$ogImage = !empty($ogImage) ? $ogImage : '/assets/img/og-default.png';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title ?></title>
    <meta name="description" content="<?= $description ?>">
    <link rel="canonical" href="<?= $canonical ?>">
    
    <!-- Open Graph Metadata -->
    <meta property="og:title" content="<?= $title ?>">
    <meta property="og:description" content="<?= $description ?>">
    <meta property="og:type" content="<?= $ogType ?>">
    <meta property="og:url" content="<?= $canonical ?>">
    <?php if (!empty($ogImage)): ?>
    <meta property="og:image" content="<?= e($ogImage) ?>">
    <?php endif; ?>
    
    <!-- CSRF Token Meta for HTMX & JS -->
    <?= csrf_meta() ?>

    <!-- Google Font (Plus Jakarta Sans) -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <!-- Bootstrap 5.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <!-- Custom Directory Stylesheet -->
    <link rel="stylesheet" href="/assets/css/style.css">

    <!-- HTMX Library -->
    <script src="/assets/js/htmx.min.js"></script>

    <?php if (!empty($jsonLd)): ?>
    <!-- Schema.org Structured Data -->
    <script type="application/ld+json">
    <?= json_encode($jsonLd, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT) ?>
    </script>
    <?php endif; ?>
</head>
<body>
<?php require_once __DIR__ . '/navbar.php'; ?>
<main>
