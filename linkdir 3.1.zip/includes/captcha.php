<?php
/**
 * linkdir - Bot Protection & Human Verification Challenge (Math CAPTCHA + Honeypot)
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Generate a new arithmetic challenge.
 */
function captcha_generate(): string {
    $ops = ['+', '-', '*'];
    $op = $ops[array_rand($ops)];

    if ($op === '+') {
        $a = random_int(2, 19);
        $b = random_int(1, 15);
        $ans = $a + $b;
        $q = "What is {$a} + {$b}?";
    } elseif ($op === '-') {
        $a = random_int(10, 25);
        $b = random_int(1, $a - 1);
        $ans = $a - $b;
        $q = "What is {$a} - {$b}?";
    } else {
        $a = random_int(2, 9);
        $b = random_int(2, 8);
        $ans = $a * $b;
        $q = "What is {$a} × {$b}?";
    }

    $_SESSION['captcha_question'] = $q;
    $_SESSION['captcha_answer'] = (string)$ans;
    $_SESSION['captcha_expires'] = time() + (defined('CAPTCHA_EXPIRY_SECONDS') ? CAPTCHA_EXPIRY_SECONDS : 300);

    return $q;
}

/**
 * Get current challenge question or generate one.
 */
function captcha_question(): string {
    if (empty($_SESSION['captcha_question']) || empty($_SESSION['captcha_expires']) || time() > $_SESSION['captcha_expires']) {
        return captcha_generate();
    }
    return $_SESSION['captcha_question'];
}

/**
 * Verify user's CAPTCHA answer.
 * 
 * @param string|null $answer User submitted answer
 * @return bool True if valid, false otherwise
 */
function captcha_verify(?string $answer): bool {
    if (empty($_SESSION['captcha_answer']) || empty($_SESSION['captcha_expires'])) {
        return false;
    }

    if (time() > $_SESSION['captcha_expires']) {
        unset($_SESSION['captcha_answer'], $_SESSION['captcha_question'], $_SESSION['captcha_expires']);
        return false;
    }

    $expected = trim($_SESSION['captcha_answer']);
    $provided = trim((string)$answer);

    $valid = ($provided !== '' && $provided === $expected);

    // Regenerate for next attempt so answer can't be replayed
    captcha_generate();

    return $valid;
}

/**
 * Render CAPTCHA form group HTML.
 */
function captcha_field(): string {
    $question = htmlspecialchars(captcha_question(), ENT_QUOTES, 'UTF-8');
    return '
    <div class="mb-3">
        <label for="captcha_input" class="form-label d-flex justify-content-between align-items-center">
            <span><strong>Human Verification:</strong> ' . $question . '</span>
            <small class="text-muted"><i class="bi bi-shield-check me-1"></i>Bot protection</small>
        </label>
        <input type="text" class="form-control" id="captcha_input" name="captcha_challenge" placeholder="Enter the number" required autocomplete="off">
    </div>';
}

/**
 * Render invisible honeypot field.
 */
function honeypot_field(): string {
    return '<div class="visually-hidden" style="display:none !important; position:absolute; left:-9999px;" aria-hidden="true">
        <label for="user_system_website_hp">Leave this field blank</label>
        <input type="text" id="user_system_website_hp" name="user_system_website_hp" tabindex="-1" autocomplete="off" value="">
    </div>';
}

/**
 * Verify honeypot has remained empty.
 */
function honeypot_verify(): bool {
    if (!empty($_POST['user_system_website_hp'])) {
        return false; // Bot filled out the honeypot field!
    }
    return true;
}
