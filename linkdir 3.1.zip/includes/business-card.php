<?php
/**
 * linkdir - Reusable Business Card Component
 * 
 * Expected $biz array keys:
 * - id, business_name, slug, category_name, category_slug, logo, about,
 * - state, country, avg_rating, review_count
 */

$bizLogo = !empty($biz['logo']) ? '/uploads/businesses/' . e($biz['logo']) : null;
$bizInitials = strtoupper(substr($biz['business_name'] ?? 'B', 0, 2));
$rating = isset($biz['avg_rating']) ? (float)$biz['avg_rating'] : 0.0;
$reviewsCount = isset($biz['review_count']) ? (int)$biz['review_count'] : 0;
$shortAbout = !empty($biz['about']) ? mb_strimwidth(strip_tags($biz['about']), 0, 115, '...') : '';
$locationLabel = !empty($biz['country']) ? e($biz['country']) : '';
?>
<div class="col-md-6 col-lg-6 col-xl-4 mb-4">
    <div class="card h-100 business-card p-3 d-flex flex-column justify-content-between">
        <div>
            <div class="d-flex align-items-start gap-3 mb-3">
                <?php if ($bizLogo): ?>
                    <img src="<?= $bizLogo ?>" alt="<?= e($biz['business_name']) ?>" class="business-logo-thumb flex-shrink-0" loading="lazy">
                <?php else: ?>
                    <div class="business-logo-placeholder flex-shrink-0">
                        <?= e($bizInitials) ?>
                    </div>
                <?php endif; ?>

                <div class="overflow-hidden">
                    <h5 class="card-title mb-1 text-truncate fs-6">
                        <a href="/business/<?= e($biz['slug']) ?>" class="text-decoration-none text-dark fw-bold hover-primary">
                            <?= e($biz['business_name']) ?>
                        </a>
                    </h5>
                    <?php if (!empty($biz['category_name'])): ?>
                        <a href="/category/<?= e($biz['category_slug'] ?? slugify($biz['category_name'])) ?>" class="badge bg-primary-subtle text-primary border border-primary-subtle text-decoration-none fw-semibold small">
                            <?= e($biz['category_name']) ?>
                        </a>
                    <?php endif; ?>
                </div>
            </div>

            <p class="card-text text-muted small mb-3 lh-base" style="min-height: 2.7rem;">
                <?= e($shortAbout) ?>
            </p>
        </div>

        <div class="pt-2 border-top">
            <div class="d-flex align-items-center justify-content-between mb-3">
                <div class="d-flex align-items-center small">
                    <?= render_stars($rating, false) ?>
                    <span class="ms-1 fw-bold small text-dark"><?= ($rating > 0 ? number_format($rating, 1) : 'New') ?></span>
                    <span class="text-muted ms-1 small">(<?= $reviewsCount ?>)</span>
                </div>
                <?php if ($locationLabel !== ''): ?>
                    <div class="text-muted small text-truncate" style="max-width: 140px;" title="<?= $locationLabel ?>">
                        <i class="bi bi-geo-alt me-1 text-primary"></i><?= $locationLabel ?>
                    </div>
                <?php endif; ?>
            </div>

            <a href="/business/<?= e($biz['slug']) ?>" class="btn btn-outline-primary btn-sm w-100">
                <span>View Details</span>
                <i class="bi bi-arrow-right"></i>
            </a>
        </div>
    </div>
</div>
