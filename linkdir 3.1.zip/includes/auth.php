<?php
/**
 * linkdir - Authentication & Session Management
 */

require_once __DIR__ . '/database.php';

// Secure Session Initialization
if (session_status() === PHP_SESSION_NONE) {
    $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || 
               (!empty($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == 443) ||
               (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https');

    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'domain'   => '',
        'secure'   => $isHttps,
        'httponly' => true,
        'samesite' => 'Lax'
    ]);

    session_start();
}

/**
 * Check if the current visitor is logged in.
 */
function auth_check(): bool {
    return !empty($_SESSION['user_id']);
}

/**
 * Get current logged in user array or null.
 */
function auth_user(): ?array {
    if (!auth_check()) {
        return null;
    }

    static $currentUser = null;
    if ($currentUser !== null && $currentUser['id'] == $_SESSION['user_id']) {
        return $currentUser;
    }

    try {
        $db = get_db();
        $stmt = $db->prepare("SELECT id, name, email, role, status, created_at, last_login FROM users WHERE id = ? LIMIT 1");
        $stmt->execute([$_SESSION['user_id']]);
        $user = $stmt->fetch();

        if ($user && $user['status'] === 'active') {
            $currentUser = $user;
            return $currentUser;
        } else {
            // User deleted or suspended
            auth_logout();
            return null;
        }
    } catch (PDOException $e) {
        error_log("auth_user error: " . $e->getMessage());
        return null;
    }
}

/**
 * Get current user ID or null.
 */
function auth_id(): ?int {
    return auth_check() ? (int)$_SESSION['user_id'] : null;
}

/**
 * Check if logged in user is an administrator.
 */
function auth_is_admin(): bool {
    if (!auth_check()) {
        return false;
    }
    return !empty($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
}

/**
 * Require user to be logged in, otherwise redirect to /login.
 */
function auth_require_login(): void {
    if (!auth_check()) {
        $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'] ?? '/dashboard';
        header('Location: /login');
        exit;
    }
}

/**
 * Require user to be an administrator, otherwise 403.
 */
function auth_require_admin(): void {
    auth_require_login();
    if (!auth_is_admin()) {
        http_response_code(403);
        require __DIR__ . '/../403.php';
        exit;
    }
}

/**
 * Log in a user securely and regenerate session ID.
 */
function auth_login(array $user): void {
    session_regenerate_id(true);

    $_SESSION['user_id'] = (int)$user['id'];
    $_SESSION['user_name'] = $user['name'];
    $_SESSION['user_email'] = $user['email'];
    $_SESSION['user_role'] = $user['role'];
    $_SESSION['logged_in_at'] = time();

    // Update last_login in database
    try {
        $db = get_db();
        $stmt = $db->prepare("UPDATE users SET last_login = CURRENT_TIMESTAMP, failed_logins = 0, lock_until = NULL WHERE id = ?");
        $stmt->execute([$user['id']]);
    } catch (PDOException $e) {
        error_log("Failed updating last_login: " . $e->getMessage());
    }
}

/**
 * Log out user and destroy session.
 */
function auth_logout(): void {
    $_SESSION = [];

    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(
            session_name(),
            '',
            time() - 42000,
            $params["path"],
            $params["domain"],
            $params["secure"],
            $params["httponly"]
        );
    }

    session_destroy();
}
