<?php
/**
 * linkdir - Admin Footer Management Settings
 * 
 * Allows administrators to customize the website footer:
 * - Brand short description below the logo column
 * - Selected categories to show in the footer
 * - Column titles and Business Owner CTA
 * - Copyright text
 * - Preview of the configured footer
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';

auth_require_admin();
$db = get_db();

// Handle Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_require();

    $footerDesc = trim($_POST['footer_description'] ?? '');
    $footerCategoriesTitle = trim($_POST['footer_categories_title'] ?? 'Popular Categories');
    $footerPagesTitle = trim($_POST['footer_pages_title'] ?? 'Pages & Legal');
    $footerBizHeading = trim($_POST['footer_biz_heading'] ?? 'For Business Owners');
    $footerBizText = trim($_POST['footer_biz_text'] ?? '');
    $footerBizButton = trim($_POST['footer_biz_button'] ?? 'List Your Business');
    $footerCopyright = trim($_POST['footer_copyright'] ?? '');

    // Selected categories
    $selectedCategoryIds = $_POST['footer_categories'] ?? [];
    if (is_array($selectedCategoryIds)) {
        $validIds = array_filter(array_map('intval', $selectedCategoryIds));
        $categoryIdsString = implode(',', $validIds);
    } else {
        $categoryIdsString = '';
    }

    // Save to settings table
    set_setting('footer_description', $footerDesc);
    set_setting('footer_categories', $categoryIdsString);
    set_setting('footer_categories_title', $footerCategoriesTitle);
    set_setting('footer_pages_title', $footerPagesTitle);
    set_setting('footer_biz_heading', $footerBizHeading);
    set_setting('footer_biz_text', $footerBizText);
    set_setting('footer_biz_button', $footerBizButton);
    set_setting('footer_copyright', $footerCopyright);

    flash_set('success', 'Footer settings and category display preferences have been updated successfully.');
    header('Location: /admin/footer');
    exit;
}

// Fetch current values
$currentDesc = get_setting('footer_description', 'A lightweight, fast, and modern business & service directory. Helping clients find trusted service providers, professionals, and verified ratings with ease.');
$currentCategoriesTitle = get_setting('footer_categories_title', 'Popular Categories');
$currentPagesTitle = get_setting('footer_pages_title', 'Pages & Legal');
$currentBizHeading = get_setting('footer_biz_heading', 'For Business Owners');
$currentBizText = get_setting('footer_biz_text', 'Submit your business or service in under two minutes. Get discovered by clients searching for verified providers.');
$currentBizButton = get_setting('footer_biz_button', 'List Your Business');
$currentCopyright = get_setting('footer_copyright', '&copy; ' . date('Y') . ' <strong class="text-light">linkdir</strong>. All rights reserved.');

$rawSavedCategories = get_setting('footer_categories', '2,1,3,4,7');
$savedCategoryIds = array_filter(array_map('intval', explode(',', $rawSavedCategories)));

// Fetch all categories for admin selector with listing counts
$allCategoriesStmt = $db->query("
    SELECT c.*, COUNT(b.id) as business_count 
    FROM categories c 
    LEFT JOIN businesses b ON b.category_id = c.id AND b.status = 'approved'
    GROUP BY c.id 
    ORDER BY c.name ASC
");
$allCategories = $allCategoriesStmt->fetchAll();

// Fetch published pages that will appear in the footer
$footerPagesStmt = $db->query("
    SELECT id, title, slug, sort_order, show_in_footer 
    FROM pages 
    WHERE status = 'published' AND show_in_footer = 1 
    ORDER BY sort_order ASC, title ASC
");
$footerPages = $footerPagesStmt->fetchAll();

$pageTitle = 'Footer Settings - Admin';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/includes/admin-nav.php';
?>

<div class="container mb-5">
    <?= flash_render() ?>

    <!-- Page Title & Navigation Header -->
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
        <div>
            <h2 class="h4 fw-bold text-dark mb-1">
                <i class="bi bi-layout-text-window-reverse text-primary me-2"></i>Footer Management &amp; Settings
            </h2>
            <p class="text-secondary small mb-0">
                Configure the branding description, choose which category links appear, customize section titles, and preview the site footer.
            </p>
        </div>
        <div class="d-flex gap-2">
            <a href="/admin/pages" class="btn btn-outline-primary btn-sm d-inline-flex align-items-center gap-1">
                <i class="bi bi-file-earmark-text"></i>
                <span>Manage Pages (<?= count($footerPages) ?> in footer)</span>
            </a>
            <a href="/" target="_blank" class="btn btn-outline-secondary btn-sm d-inline-flex align-items-center gap-1">
                <i class="bi bi-box-arrow-up-right"></i>
                <span>View Public Footer</span>
            </a>
        </div>
    </div>

    <!-- Live Preview Card Banner -->
    <div class="card border shadow-xs mb-4">
        <div class="card-header bg-dark text-white py-3 d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center gap-2">
                <i class="bi bi-eye-fill text-primary"></i>
                <strong class="small text-uppercase" style="letter-spacing:0.5px;">Live Footer Preview</strong>
            </div>
            <span class="badge bg-secondary-subtle text-light" style="font-size:0.7rem;">Renders in real-time</span>
        </div>
        <div class="card-body bg-dark text-light p-4" id="footerLivePreview">
            <div class="row g-4 mb-4">
                <!-- Col 1: Logo & Short Description -->
                <div class="col-lg-4 col-md-6">
                    <div class="d-flex align-items-center gap-2 mb-3">
                        <div class="brand-icon-box">
                            <i class="bi bi-compass-fill"></i>
                        </div>
                        <span class="fs-4 fw-bold text-white tracking-tight">linkdir</span>
                        <span class="brand-badge ms-1 text-light bg-dark border-secondary">Directory</span>
                    </div>
                    <p class="text-secondary small mb-3 lh-base" id="previewDescText">
                        <?= e($currentDesc) ?>
                    </p>
                    <div class="d-flex gap-3 text-secondary small">
                        <span><i class="bi bi-search me-1"></i>Search</span>
                        <span><i class="bi bi-diagram-3 me-1"></i>Sitemap</span>
                    </div>
                </div>

                <!-- Col 2: Categories -->
                <div class="col-lg-3 col-md-6">
                    <h6 class="text-white text-uppercase fw-bold mb-3 small" id="previewCategoriesHeading" style="letter-spacing: 0.05em;">
                        <?= e($currentCategoriesTitle) ?>
                    </h6>
                    <ul class="list-unstyled text-secondary small mb-0 d-flex flex-column gap-2" id="previewCategoriesList">
                        <!-- Populated by JS based on selected checkboxes -->
                    </ul>
                </div>

                <!-- Col 3: Pages Links -->
                <div class="col-lg-2 col-md-6">
                    <h6 class="text-white text-uppercase fw-bold mb-3 small" id="previewPagesHeading" style="letter-spacing: 0.05em;">
                        <?= e($currentPagesTitle) ?>
                    </h6>
                    <ul class="list-unstyled text-secondary small mb-0 d-flex flex-column gap-2">
                        <?php if (empty($footerPages)): ?>
                            <li class="text-muted fst-italic">No pages marked for footer</li>
                        <?php else: ?>
                            <?php foreach ($footerPages as $fp): ?>
                                <li>
                                    <span class="text-secondary">
                                        <i class="bi bi-chevron-right me-1 text-primary"></i><?= e($fp['title']) ?>
                                    </span>
                                </li>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </ul>
                </div>

                <!-- Col 4: Business Owners CTA -->
                <div class="col-lg-3 col-md-6">
                    <h6 class="text-white text-uppercase fw-bold mb-3 small" id="previewBizHeading" style="letter-spacing: 0.05em;">
                        <?= e($currentBizHeading) ?>
                    </h6>
                    <p class="text-secondary small mb-3 lh-base" id="previewBizText">
                        <?= e($currentBizText) ?>
                    </p>
                    <span class="btn btn-primary btn-sm disabled" id="previewBizButton">
                        <i class="bi bi-plus-lg me-1"></i><?= e($currentBizButton) ?>
                    </span>
                </div>
            </div>

            <!-- Bottom Row -->
            <div class="pt-3 mt-3 border-top border-secondary text-secondary small d-flex flex-column flex-md-row justify-content-between align-items-center gap-2">
                <div id="previewCopyrightText">
                    <?= $currentCopyright ?>
                </div>
                <div class="d-flex gap-2 align-items-center">
                    <span class="text-secondary">PHP 8.2 + HTMX</span>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Settings Form -->
    <form action="/admin/footer" method="POST" id="footerSettingsForm">
        <?= csrf_field() ?>

        <div class="row g-4">
            <!-- Left Column: Description & Categories Selector -->
            <div class="col-lg-7">
                <!-- Section 1: Logo Column Short Description -->
                <div class="card border shadow-xs mb-4">
                    <div class="card-header bg-white py-3 border-bottom">
                        <h5 class="card-title fw-bold mb-0 text-dark">
                            <i class="bi bi-chat-left-quote text-primary me-2"></i>Logo Column &amp; Short Description
                        </h5>
                    </div>
                    <div class="card-body p-4">
                        <div class="mb-3">
                            <div class="d-flex justify-content-between align-items-center mb-1">
                                <label for="footerDescInput" class="form-label small fw-bold text-dark mb-0">
                                    Footer Short Description <span class="text-danger">*</span>
                                </label>
                                <button type="button" class="btn btn-link btn-sm p-0 text-decoration-none text-muted" id="btnResetDesc" style="font-size:0.75rem;">
                                    Reset to Default
                                </button>
                            </div>
                            <textarea name="footer_description" id="footerDescInput" class="form-control" rows="3" required><?= e($currentDesc) ?></textarea>
                            <div class="d-flex justify-content-between text-muted mt-1" style="font-size:0.75rem;">
                                <span>This text appears directly beneath the linkdir brand icon &amp; title in the footer.</span>
                                <span id="footerDescCharCount">0 chars</span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Section 2: Categories to Display in Footer -->
                <div class="card border shadow-xs mb-4">
                    <div class="card-header bg-white py-3 border-bottom d-flex flex-column flex-sm-row justify-content-between align-items-sm-center gap-2">
                        <div>
                            <h5 class="card-title fw-bold mb-0 text-dark">
                                <i class="bi bi-tags text-primary me-2"></i>Choose Categories in Footer
                            </h5>
                            <small class="text-muted">Select which categories site visitors will see in the footer column.</small>
                        </div>
                        <span class="badge bg-primary rounded-pill px-3 py-2" id="selectedCatCountBadge">
                            <?= count($savedCategoryIds) ?> selected
                        </span>
                    </div>

                    <div class="p-3 bg-light border-bottom d-flex flex-wrap justify-content-between align-items-center gap-2">
                        <div class="d-flex gap-2">
                            <button type="button" class="btn btn-white btn-sm border bg-white" id="btnSelectAllCats">Select All</button>
                            <button type="button" class="btn btn-white btn-sm border bg-white" id="btnSelectTop5Cats">Select Top 5</button>
                            <button type="button" class="btn btn-white btn-sm border bg-white" id="btnClearCats">Clear All</button>
                        </div>
                        <small class="text-muted">Tip: 4-6 categories provide ideal visual balance.</small>
                    </div>

                    <div class="card-body p-3">
                        <div class="row g-2" id="categoriesGrid">
                            <?php foreach ($allCategories as $cat): ?>
                                <?php $isSelected = in_array((int)$cat['id'], $savedCategoryIds); ?>
                                <div class="col-sm-6">
                                    <label class="category-select-card d-flex align-items-center justify-content-between p-2 rounded border <?= $isSelected ? 'border-primary bg-primary-subtle' : 'bg-white' ?>" style="cursor: pointer; transition: all 0.15s ease-in-out;">
                                        <div class="d-flex align-items-center gap-2">
                                            <input type="checkbox" name="footer_categories[]" value="<?= (int)$cat['id'] ?>" class="form-check-input cat-checkbox me-1" <?= $isSelected ? 'checked' : '' ?> data-name="<?= e($cat['name']) ?>" data-slug="<?= e($cat['slug']) ?>" data-icon="<?= e($cat['icon']) ?>">
                                            <i class="bi <?= e($cat['icon'] ?: 'bi-tag') ?> text-primary"></i>
                                            <span class="small fw-semibold text-dark text-truncate" style="max-width: 170px;"><?= e($cat['name']) ?></span>
                                        </div>
                                        <span class="badge bg-secondary-subtle text-secondary small" style="font-size:0.68rem;">
                                            <?= (int)$cat['business_count'] ?> listings
                                        </span>
                                    </label>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Right Column: Titles, Pages, Business CTA & Copyright -->
            <div class="col-lg-5">
                <!-- Section 3: Column Titles -->
                <div class="card border shadow-xs mb-4">
                    <div class="card-header bg-white py-3 border-bottom">
                        <h5 class="card-title fw-bold mb-0 text-dark">
                            <i class="bi bi-type-h1 text-primary me-2"></i>Column Titles
                        </h5>
                    </div>
                    <div class="card-body p-4">
                        <div class="mb-3">
                            <label for="footerCategoriesTitleInput" class="form-label small fw-bold text-dark">Categories Column Heading</label>
                            <input type="text" name="footer_categories_title" id="footerCategoriesTitleInput" class="form-control form-control-sm" value="<?= e($currentCategoriesTitle) ?>" required>
                        </div>
                        <div class="mb-0">
                            <label for="footerPagesTitleInput" class="form-label small fw-bold text-dark">Pages Column Heading</label>
                            <input type="text" name="footer_pages_title" id="footerPagesTitleInput" class="form-control form-control-sm" value="<?= e($currentPagesTitle) ?>" required>
                        </div>
                    </div>
                </div>

                <!-- Section 4: Pages in Footer Overview -->
                <div class="card border shadow-xs mb-4">
                    <div class="card-header bg-white py-3 border-bottom d-flex justify-content-between align-items-center">
                        <h5 class="card-title fw-bold mb-0 text-dark">
                            <i class="bi bi-file-earmark-text text-primary me-2"></i>Pages in Footer
                        </h5>
                        <a href="/admin/pages" class="btn btn-outline-primary btn-sm py-0 px-2" style="font-size:0.75rem;">Manage Pages</a>
                    </div>
                    <div class="card-body p-3">
                        <p class="small text-muted mb-2">
                            The following published pages are enabled to display in the footer. To add, remove, or re-order pages, use the 
                            <a href="/admin/pages" class="fw-semibold text-decoration-none">Pages Manager</a>.
                        </p>
                        <div class="list-group list-group-flush rounded border">
                            <?php if (empty($footerPages)): ?>
                                <div class="p-3 text-center text-muted small">
                                    No pages currently have "Display in Footer" checked.
                                </div>
                            <?php else: ?>
                                <?php foreach ($footerPages as $fp): ?>
                                    <div class="list-group-item d-flex justify-content-between align-items-center py-2 px-3 small">
                                        <div class="d-flex align-items-center gap-2">
                                            <span class="badge bg-light text-muted border">#<?= (int)$fp['sort_order'] ?></span>
                                            <span class="fw-semibold text-dark"><?= e($fp['title']) ?></span>
                                        </div>
                                        <div class="d-flex align-items-center gap-2">
                                            <a href="/page/<?= e($fp['slug']) ?>" target="_blank" class="text-muted" title="View page">
                                                <i class="bi bi-box-arrow-up-right"></i>
                                            </a>
                                            <a href="/admin/pages?edit=<?= (int)$fp['id'] ?>" class="text-primary" title="Edit page">
                                                <i class="bi bi-pencil"></i>
                                            </a>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Section 5: Business CTA & Copyright -->
                <div class="card border shadow-xs mb-4">
                    <div class="card-header bg-white py-3 border-bottom">
                        <h5 class="card-title fw-bold mb-0 text-dark">
                            <i class="bi bi-briefcase text-primary me-2"></i>Business CTA &amp; Copyright
                        </h5>
                    </div>
                    <div class="card-body p-4">
                        <div class="mb-3">
                            <label for="footerBizHeadingInput" class="form-label small fw-bold text-dark">Business Column Heading</label>
                            <input type="text" name="footer_biz_heading" id="footerBizHeadingInput" class="form-control form-control-sm" value="<?= e($currentBizHeading) ?>">
                        </div>

                        <div class="mb-3">
                            <label for="footerBizTextInput" class="form-label small fw-bold text-dark">Business Column Blurb</label>
                            <textarea name="footer_biz_text" id="footerBizTextInput" class="form-control form-control-sm" rows="2"><?= e($currentBizText) ?></textarea>
                        </div>

                        <div class="mb-3">
                            <label for="footerBizButtonInput" class="form-label small fw-bold text-dark">CTA Button Text</label>
                            <input type="text" name="footer_biz_button" id="footerBizButtonInput" class="form-control form-control-sm" value="<?= e($currentBizButton) ?>">
                        </div>

                        <div class="mb-0">
                            <label for="footerCopyrightInput" class="form-label small fw-bold text-dark">Bottom Copyright Text</label>
                            <input type="text" name="footer_copyright" id="footerCopyrightInput" class="form-control form-control-sm font-monospace" value="<?= e($currentCopyright) ?>" style="font-size:0.8rem;">
                            <small class="text-muted" style="font-size:0.72rem;">HTML supported (e.g. &amp;copy;, &lt;strong&gt;).</small>
                        </div>
                    </div>
                </div>

                <!-- Save Button Card -->
                <div class="card border shadow-xs p-3 bg-light">
                    <button type="submit" class="btn btn-primary btn-lg w-100 fw-bold shadow-xs">
                        <i class="bi bi-check2-circle me-1"></i>Save Footer Changes
                    </button>
                    <small class="text-center text-muted d-block mt-2">Changes are applied across the entire directory immediately.</small>
                </div>
            </div>
        </div>
    </form>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const descInput = document.getElementById('footerDescInput');
    const descCount = document.getElementById('footerDescCharCount');
    const previewDesc = document.getElementById('previewDescText');
    const btnResetDesc = document.getElementById('btnResetDesc');

    const catHeadingInput = document.getElementById('footerCategoriesTitleInput');
    const previewCatHeading = document.getElementById('previewCategoriesHeading');

    const pagesHeadingInput = document.getElementById('footerPagesTitleInput');
    const previewPagesHeading = document.getElementById('previewPagesHeading');

    const bizHeadingInput = document.getElementById('footerBizHeadingInput');
    const previewBizHeading = document.getElementById('previewBizHeading');

    const bizTextInput = document.getElementById('footerBizTextInput');
    const previewBizText = document.getElementById('previewBizText');

    const bizBtnInput = document.getElementById('footerBizButtonInput');
    const previewBizBtn = document.getElementById('previewBizButton');

    const copyrightInput = document.getElementById('footerCopyrightInput');
    const previewCopyright = document.getElementById('previewCopyrightText');

    const catCheckboxes = document.querySelectorAll('.cat-checkbox');
    const selectedBadge = document.getElementById('selectedCatCountBadge');
    const previewCatList = document.getElementById('previewCategoriesList');

    const defaultDesc = "A lightweight, fast, and modern business & service directory. Helping clients find trusted service providers, professionals, and verified ratings with ease.";

    // Update Description
    function updateDesc() {
        const val = descInput.value;
        descCount.textContent = val.length + ' chars';
        previewDesc.textContent = val || defaultDesc;
    }
    descInput.addEventListener('input', updateDesc);
    updateDesc();

    btnResetDesc.addEventListener('click', function() {
        descInput.value = defaultDesc;
        updateDesc();
    });

    // Update Titles
    catHeadingInput.addEventListener('input', function() {
        previewCatHeading.textContent = catHeadingInput.value || 'Categories';
    });

    pagesHeadingInput.addEventListener('input', function() {
        previewPagesHeading.textContent = pagesHeadingInput.value || 'Pages';
    });

    bizHeadingInput.addEventListener('input', function() {
        previewBizHeading.textContent = bizHeadingInput.value || 'For Business Owners';
    });

    bizTextInput.addEventListener('input', function() {
        previewBizText.textContent = bizTextInput.value;
    });

    bizBtnInput.addEventListener('input', function() {
        previewBizBtn.innerHTML = '<i class="bi bi-plus-lg me-1"></i>' + (bizBtnInput.value || 'List Your Business');
    });

    copyrightInput.addEventListener('input', function() {
        previewCopyright.innerHTML = copyrightInput.value;
    });

    // Update Categories Selector & Preview
    function renderSelectedCategories() {
        let count = 0;
        previewCatList.innerHTML = '';

        catCheckboxes.forEach(function(cb) {
            const card = cb.closest('.category-select-card');
            if (cb.checked) {
                count++;
                if (card) {
                    card.classList.add('border-primary', 'bg-primary-subtle');
                    card.classList.remove('bg-white');
                }

                // Add to preview
                const li = document.createElement('li');
                const icon = cb.dataset.icon || 'bi-chevron-right';
                li.innerHTML = '<span class="text-secondary"><i class="bi ' + icon + ' me-1 text-primary"></i>' + cb.dataset.name + '</span>';
                previewCatList.appendChild(li);
            } else {
                if (card) {
                    card.classList.remove('border-primary', 'bg-primary-subtle');
                    card.classList.add('bg-white');
                }
            }
        });

        selectedBadge.textContent = count + ' selected';

        if (count === 0) {
            previewCatList.innerHTML = '<li class="text-muted fst-italic">No categories selected</li>';
        }
    }

    catCheckboxes.forEach(function(cb) {
        cb.addEventListener('change', renderSelectedCategories);
    });
    renderSelectedCategories();

    // Quick selection buttons
    document.getElementById('btnSelectAllCats').addEventListener('click', function() {
        catCheckboxes.forEach(cb => cb.checked = true);
        renderSelectedCategories();
    });

    document.getElementById('btnClearCats').addEventListener('click', function() {
        catCheckboxes.forEach(cb => cb.checked = false);
        renderSelectedCategories();
    });

    document.getElementById('btnSelectTop5Cats').addEventListener('click', function() {
        catCheckboxes.forEach((cb, idx) => {
            cb.checked = idx < 5;
        });
        renderSelectedCategories();
    });
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
