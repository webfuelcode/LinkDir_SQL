<?php
/**
 * linkdir - Admin Review Management
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';

auth_require_admin();
$db = get_db();

// Filters
$status = trim($_GET['status'] ?? '');
$search = trim($_GET['q'] ?? '');
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 20;
$offset = ($page - 1) * $perPage;

$where = ["1=1"];
$params = [];

if ($status !== '' && in_array($status, ['approved', 'pending', 'rejected'])) {
    $where[] = "r.status = ?";
    $params[] = $status;
}

if ($search !== '') {
    $where[] = "(b.business_name LIKE ? OR u.name LIKE ? OR u.email LIKE ? OR r.review_text LIKE ?)";
    $term = '%' . $search . '%';
    $params[] = $term;
    $params[] = $term;
    $params[] = $term;
    $params[] = $term;
}

$whereClause = implode(' AND ', $where);

// Count
$countStmt = $db->prepare("
    SELECT COUNT(r.id)
    FROM reviews r
    JOIN businesses b ON r.business_id = b.id
    JOIN users u ON r.user_id = u.id
    WHERE {$whereClause}
");
$countStmt->execute($params);
$totalItems = (int)$countStmt->fetchColumn();
$totalPages = ceil($totalItems / $perPage);

// Data
$stmt = $db->prepare("
    SELECT r.*, b.business_name, b.slug as business_slug, u.name as reviewer_name, u.email as reviewer_email
    FROM reviews r
    JOIN businesses b ON r.business_id = b.id
    JOIN users u ON r.user_id = u.id
    WHERE {$whereClause}
    ORDER BY r.created_at DESC
    LIMIT {$perPage} OFFSET {$offset}
");
$stmt->execute($params);
$reviews = $stmt->fetchAll();

$pageTitle = 'Manage Reviews - Admin';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/includes/admin-nav.php';
?>

<div class="container mb-5">
    <?= flash_render() ?>

    <div class="d-flex justify-content-between align-items-center mb-3">
        <h2 class="h4 fw-bold mb-0">Customer Reviews (<?= number_format($totalItems) ?>)</h2>
    </div>

    <!-- Filter Card -->
    <div class="card shadow-sm border-1 p-3 mb-4 bg-light">
        <form action="/admin/reviews" method="GET" class="row g-2 align-items-end">
            <div class="col-md-6">
                <label class="form-label small fw-semibold text-muted mb-1">Search Keywords, Reviewer, or Business</label>
                <input type="text" name="q" class="form-control form-control-sm" placeholder="Reviewer name, business, content..." value="<?= e($search) ?>">
            </div>

            <div class="col-md-4">
                <label class="form-label small fw-semibold text-muted mb-1">Moderation Status</label>
                <select name="status" class="form-select form-select-sm">
                    <option value="">All Statuses</option>
                    <option value="pending" <?= ($status === 'pending' ? 'selected' : '') ?>>Pending Moderation</option>
                    <option value="approved" <?= ($status === 'approved' ? 'selected' : '') ?>>Approved / Published</option>
                    <option value="rejected" <?= ($status === 'rejected' ? 'selected' : '') ?>>Rejected</option>
                </select>
            </div>

            <div class="col-md-2 d-flex gap-1">
                <button type="submit" class="btn btn-primary btn-sm flex-grow-1">Filter</button>
                <a href="/admin/reviews" class="btn btn-outline-secondary btn-sm">Reset</a>
            </div>
        </form>
    </div>

    <!-- Reviews Table -->
    <div class="card shadow-sm border-1">
        <div class="card-body p-0">
            <?php if (!empty($reviews)): ?>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light small">
                            <tr>
                                <th>Business</th>
                                <th>Reviewer</th>
                                <th>Rating</th>
                                <th>Comment</th>
                                <th>Date</th>
                                <th>Status</th>
                                <th class="text-end">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($reviews as $rev): ?>
                                <tr id="admin-rev-row-<?= (int)$rev['id'] ?>">
                                    <td>
                                        <strong>
                                            <a href="/business/<?= e($rev['business_slug']) ?>" class="text-decoration-none text-dark" target="_blank">
                                                <?= e($rev['business_name']) ?>
                                            </a>
                                        </strong>
                                    </td>
                                    <td class="small">
                                        <?= e($rev['reviewer_name']) ?><br>
                                        <span class="text-muted"><?= e($rev['reviewer_email']) ?></span>
                                    </td>
                                    <td>
                                        <?= render_stars((float)$rev['rating'], false) ?>
                                    </td>
                                    <td class="small" style="max-width: 280px;">
                                        <?= e($rev['review_text']) ?>
                                    </td>
                                    <td class="small text-muted">
                                        <?= format_date($rev['created_at']) ?>
                                    </td>
                                    <td>
                                        <div class="dropdown">
                                            <?php
                                            $badgeClass = match($rev['status']) {
                                                'approved' => 'badge-status-approved',
                                                'pending'  => 'badge-status-pending',
                                                'rejected' => 'badge-status-rejected',
                                                default    => 'bg-secondary'
                                            };
                                            ?>
                                            <button class="btn btn-sm dropdown-toggle p-0 border-0" type="button" data-bs-toggle="dropdown">
                                                <span class="badge <?= $badgeClass ?> px-2 py-1" id="rev-status-badge-<?= (int)$rev['id'] ?>">
                                                    <?= ucfirst(e($rev['status'])) ?>
                                                </span>
                                            </button>
                                            <ul class="dropdown-menu shadow-sm">
                                                <li>
                                                    <button class="dropdown-item small text-success"
                                                            hx-post="/admin/actions.php"
                                                            hx-vals='{"action": "review_status", "id": <?= (int)$rev['id'] ?>, "status": "approved"}'
                                                            hx-target="#rev-status-badge-<?= (int)$rev['id'] ?>"
                                                            hx-swap="outerHTML">
                                                        <i class="bi bi-check-circle me-1"></i> Approve
                                                    </button>
                                                </li>
                                                <li>
                                                    <button class="dropdown-item small text-warning"
                                                            hx-post="/admin/actions.php"
                                                            hx-vals='{"action": "review_status", "id": <?= (int)$rev['id'] ?>, "status": "pending"}'
                                                            hx-target="#rev-status-badge-<?= (int)$rev['id'] ?>"
                                                            hx-swap="outerHTML">
                                                        <i class="bi bi-hourglass-split me-1"></i> Mark Pending
                                                    </button>
                                                </li>
                                                <li>
                                                    <button class="dropdown-item small text-danger"
                                                            hx-post="/admin/actions.php"
                                                            hx-vals='{"action": "review_status", "id": <?= (int)$rev['id'] ?>, "status": "rejected"}'
                                                            hx-target="#rev-status-badge-<?= (int)$rev['id'] ?>"
                                                            hx-swap="outerHTML">
                                                        <i class="bi bi-x-circle me-1"></i> Reject
                                                    </button>
                                                </li>
                                            </ul>
                                        </div>
                                    </td>
                                    <td class="text-end">
                                        <button class="btn btn-outline-danger btn-sm" title="Delete Review"
                                                hx-post="/admin/actions.php"
                                                hx-vals='{"action": "review_delete", "id": <?= (int)$rev['id'] ?>}'
                                                hx-confirm="Delete this customer review?"
                                                hx-target="#admin-rev-row-<?= (int)$rev['id'] ?>"
                                                hx-swap="outerHTML">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <?php if ($totalPages > 1): ?>
                    <div class="card-footer bg-white py-3">
                        <ul class="pagination justify-content-center mb-0">
                            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                                <li class="page-item <?= ($page == $i ? 'active' : '') ?>">
                                    <a class="page-link" href="/admin/reviews?page=<?= $i ?>&status=<?= urlencode($status) ?>&q=<?= urlencode($search) ?>">
                                        <?= $i ?>
                                    </a>
                                </li>
                            <?php endfor; ?>
                        </ul>
                    </div>
                <?php endif; ?>
            <?php else: ?>
                <div class="p-5 text-center text-muted">
                    <p class="mb-0">No reviews found matching your search.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
