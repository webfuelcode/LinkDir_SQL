<?php
/**
 * linkdir - Admin Action Endpoint
 * 
 * Handles administrative state updates (Businesses, Reviews, Users, Categories)
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';

auth_require_admin();
$db = get_db();

$action = $_GET['action'] ?? ($_POST['action'] ?? '');
csrf_require();

switch ($action) {
    // -------------------------------------------------------------
    // BUSINESS ACTIONS
    // -------------------------------------------------------------
    case 'business_status':
        $bizId = (int)($_POST['id'] ?? 0);
        $status = $_POST['status'] ?? 'pending';

        if (!in_array($status, ['approved', 'pending', 'rejected', 'suspended'])) {
            http_response_code(400);
            die('Invalid status');
        }

        $stmt = $db->prepare("UPDATE businesses SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?");
        $stmt->execute([$status, $bizId]);

        if (is_htmx()) {
            $badgeClass = match($status) {
                'approved'  => 'badge-status-approved',
                'pending'   => 'badge-status-pending',
                'rejected'  => 'badge-status-rejected',
                'suspended' => 'badge-status-suspended',
                default     => 'bg-secondary'
            };
            echo '<span class="badge ' . $badgeClass . ' px-2 py-1">' . ucfirst(e($status)) . '</span>';
            exit;
        }

        flash_set('success', 'Business status updated to ' . ucfirst($status) . '.');
        header('Location: /admin/businesses');
        exit;

    case 'business_delete':
        $bizId = (int)($_POST['id'] ?? ($_GET['id'] ?? 0));

        $bStmt = $db->prepare("SELECT logo FROM businesses WHERE id = ?");
        $bStmt->execute([$bizId]);
        $logo = $bStmt->fetchColumn();

        if (!empty($logo)) {
            $logoPath = UPLOAD_DIR . '/businesses/' . $logo;
            if (file_exists($logoPath)) @unlink($logoPath);
        }

        $db->prepare("DELETE FROM reviews WHERE business_id = ?")->execute([$bizId]);
        $db->prepare("DELETE FROM businesses WHERE id = ?")->execute([$bizId]);

        if (is_htmx()) {
            exit(''); // Removes row from table
        }

        flash_set('success', 'Business listing removed permanently.');
        header('Location: /admin/businesses');
        exit;

    // -------------------------------------------------------------
    // REVIEW ACTIONS
    // -------------------------------------------------------------
    case 'review_status':
        $revId = (int)($_POST['id'] ?? 0);
        $status = $_POST['status'] ?? 'pending';

        if (!in_array($status, ['approved', 'pending', 'rejected'])) {
            http_response_code(400);
            die('Invalid status');
        }

        $stmt = $db->prepare("UPDATE reviews SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?");
        $stmt->execute([$status, $revId]);

        if (is_htmx()) {
            $badgeClass = match($status) {
                'approved' => 'badge-status-approved',
                'pending'  => 'badge-status-pending',
                'rejected' => 'badge-status-rejected',
                default    => 'bg-secondary'
            };
            echo '<span class="badge ' . $badgeClass . ' px-2 py-1">' . ucfirst(e($status)) . '</span>';
            exit;
        }

        flash_set('success', 'Review status updated to ' . ucfirst($status) . '.');
        header('Location: /admin/reviews');
        exit;

    case 'review_delete':
        $revId = (int)($_POST['id'] ?? ($_GET['id'] ?? 0));
        $db->prepare("DELETE FROM reviews WHERE id = ?")->execute([$revId]);

        if (is_htmx()) {
            exit('');
        }

        flash_set('success', 'Review deleted successfully.');
        header('Location: /admin/reviews');
        exit;

    // -------------------------------------------------------------
    // USER ACTIONS
    // -------------------------------------------------------------
    case 'user_toggle_status':
        $userId = (int)($_POST['id'] ?? 0);
        $status = $_POST['status'] ?? 'active';

        // Cannot suspend self
        if ($userId == auth_id()) {
            http_response_code(400);
            die('Cannot modify own account status');
        }

        $stmt = $db->prepare("UPDATE users SET status = ? WHERE id = ?");
        $stmt->execute([$status, $userId]);

        flash_set('success', 'User status updated to ' . ucfirst($status) . '.');
        header('Location: /admin/users');
        exit;

    case 'user_toggle_role':
        $userId = (int)($_POST['id'] ?? 0);
        $role = $_POST['role'] ?? 'user';

        // Cannot demote self
        if ($userId == auth_id()) {
            http_response_code(400);
            die('Cannot demote own account');
        }

        $stmt = $db->prepare("UPDATE users SET role = ? WHERE id = ?");
        $stmt->execute([$role, $userId]);

        flash_set('success', 'User role updated to ' . ucfirst($role) . '.');
        header('Location: /admin/users');
        exit;

    // -------------------------------------------------------------
    // CATEGORY ACTIONS
    // -------------------------------------------------------------
    case 'category_toggle_status':
        $catId = (int)($_POST['id'] ?? ($_GET['id'] ?? 0));
        $stmt = $db->prepare("SELECT status FROM categories WHERE id = ?");
        $stmt->execute([$catId]);
        $currStatus = $stmt->fetchColumn();

        if ($currStatus) {
            $newStatus = ($currStatus === 'active') ? 'inactive' : 'active';
            $db->prepare("UPDATE categories SET status = ? WHERE id = ?")->execute([$newStatus, $catId]);
            flash_set('success', 'Category status updated to ' . ucfirst($newStatus) . '.');
        }

        header('Location: /admin/categories');
        exit;

    case 'category_delete':
        $catId = (int)($_POST['id'] ?? ($_GET['id'] ?? 0));

        // Check if businesses are assigned
        $chk = $db->prepare("SELECT COUNT(*) FROM businesses WHERE category_id = ?");
        $chk->execute([$catId]);
        $count = (int)$chk->fetchColumn();

        if ($count > 0) {
            flash_set('danger', 'Cannot delete category: ' . $count . ' business listing(s) are currently assigned to it.');
            header('Location: /admin/categories');
            exit;
        }

        $db->prepare("DELETE FROM categories WHERE id = ?")->execute([$catId]);

        if (is_htmx()) {
            exit('');
        }

        flash_set('success', 'Category deleted successfully.');
        header('Location: /admin/categories');
        exit;

    default:
        http_response_code(400);
        die('Unrecognized action');
}
