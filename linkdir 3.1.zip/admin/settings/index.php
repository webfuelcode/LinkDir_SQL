<?php
/**
 * linkdir - Admin Settings Index Forwarder
 */
require_once __DIR__ . '/../settings.php';
