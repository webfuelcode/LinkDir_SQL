<?php
/**
 * linkdir - Admin Category Management
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';

auth_require_admin();
$db = get_db();

$errors = [];
$editCategory = null;

// Handle Edit Mode Request
$editId = (int)($_GET['edit'] ?? 0);
if ($editId > 0) {
    $eStmt = $db->prepare("SELECT * FROM categories WHERE id = ? LIMIT 1");
    $eStmt->execute([$editId]);
    $editCategory = $eStmt->fetch();
}

// Handle Add / Edit Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_require();

    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $icon = trim($_POST['icon'] ?? 'bi-tag');
    $status = in_array($_POST['status'] ?? 'active', ['active', 'inactive']) ? $_POST['status'] : 'active';
    $catId = (int)($_POST['id'] ?? 0);

    if (empty($name)) {
        $errors[] = 'Category name is required.';
    }

    if (empty($icon)) {
        $icon = 'bi-tag';
    }

    if (empty($errors)) {
        $baseSlug = slugify($name);
        $slug = $baseSlug;

        if ($catId > 0) {
            // Update
            $uStmt = $db->prepare("SELECT slug FROM categories WHERE id = ?");
            $uStmt->execute([$catId]);
            $currentSlug = $uStmt->fetchColumn();

            // Only change slug if name changed significantly
            $targetSlug = $currentSlug ?: $slug;

            $upd = $db->prepare("UPDATE categories SET name = ?, slug = ?, description = ?, icon = ?, status = ? WHERE id = ?");
            $upd->execute([$name, $targetSlug, $description, $icon, $status, $catId]);
            flash_set('success', 'Category updated successfully.');
            header('Location: /admin/categories');
            exit;
        } else {
            // Check slug collision
            $chk = $db->prepare("SELECT id FROM categories WHERE slug = ?");
            $chk->execute([$slug]);
            if ($chk->fetch()) {
                $slug .= '-' . rand(10, 99);
            }

            $ins = $db->prepare("INSERT INTO categories (name, slug, description, icon, status, created_at) VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)");
            $ins->execute([$name, $slug, $description, $icon, $status]);
            flash_set('success', 'Category added successfully.');
            header('Location: /admin/categories');
            exit;
        }
    }
}

// Fetch categories with counts
$categories = $db->query("
    SELECT c.*, COUNT(b.id) as business_count
    FROM categories c
    LEFT JOIN businesses b ON b.category_id = c.id
    GROUP BY c.id
    ORDER BY c.name ASC
")->fetchAll();

$pageTitle = 'Manage Categories - Admin';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/includes/admin-nav.php';
?>

<div class="container mb-5">
    <?= flash_render() ?>

    <div class="row g-4">
        <!-- Form: Add or Edit Category -->
        <div class="col-lg-4">
            <div class="card shadow-sm border-1 p-4 sticky-top" style="top: 80px;">
                <h5 class="fw-bold mb-3 border-bottom pb-2">
                    <?= $editCategory ? 'Edit Category' : 'Add New Category' ?>
                </h5>

                <?php if (!empty($errors)): ?>
                    <div class="alert alert-danger py-2 small mb-3">
                        <ul class="mb-0 ps-3">
                            <?php foreach ($errors as $err): ?>
                                <li><?= e($err) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form action="/admin/categories" method="POST">
                    <?= csrf_field() ?>
                    <?php if ($editCategory): ?>
                        <input type="hidden" name="id" value="<?= (int)$editCategory['id'] ?>">
                    <?php endif; ?>

                    <div class="mb-3">
                        <label for="name" class="form-label small fw-semibold text-muted">Category Name *</label>
                        <input type="text" class="form-control" id="name" name="name" value="<?= e($editCategory['name'] ?? '') ?>" required placeholder="e.g. Legal Services">
                    </div>

                    <div class="mb-3">
                        <label for="icon" class="form-label small fw-semibold text-muted">Category Icon</label>
                        <div class="input-group mb-2">
                            <span class="input-group-text bg-light" id="icon-preview"><i class="bi <?= e($editCategory['icon'] ?? 'bi-tag') ?>"></i></span>
                            <input type="text" class="form-control font-monospace" id="icon" name="icon" value="<?= e($editCategory['icon'] ?? 'bi-tag') ?>" placeholder="e.g. bi-tools" oninput="document.querySelector('#icon-preview i').className = 'bi ' + this.value;">
                        </div>
                        <div class="small text-muted mb-1">Quick pick popular icons:</div>
                        <div class="d-flex flex-wrap gap-1 mb-2">
                            <?php 
                            $popularIcons = [
                                'bi-tools' => 'Trades',
                                'bi-laptop' => 'Tech',
                                'bi-heart-pulse' => 'Health',
                                'bi-cup-hot' => 'Dining',
                                'bi-car-front' => 'Auto',
                                'bi-briefcase' => 'Legal/Pro',
                                'bi-house-door' => 'Real Estate',
                                'bi-bag' => 'Retail',
                                'bi-scissors' => 'Beauty',
                                'bi-shield-check' => 'Security',
                                'bi-mortarboard' => 'Education',
                                'bi-camera' => 'Media'
                            ];
                            foreach ($popularIcons as $icClass => $icLabel): 
                            ?>
                                <button type="button" class="btn btn-outline-secondary btn-sm py-0 px-2" style="font-size:0.75rem;" onclick="document.getElementById('icon').value = '<?= $icClass ?>'; document.querySelector('#icon-preview i').className = 'bi <?= $icClass ?>';" title="<?= $icLabel ?>">
                                    <i class="bi <?= $icClass ?> me-1"></i><?= $icLabel ?>
                                </button>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="description" class="form-label small fw-semibold text-muted">Short Description</label>
                        <textarea class="form-control" id="description" name="description" rows="3" placeholder="Brief overview of services in this category..."><?= e($editCategory['description'] ?? '') ?></textarea>
                    </div>

                    <div class="mb-3">
                        <label for="status" class="form-label small fw-semibold text-muted">Visibility Status</label>
                        <select class="form-select" id="status" name="status">
                            <option value="active" <?= (($editCategory['status'] ?? 'active') === 'active' ? 'selected' : '') ?>>Active (Visible publicly)</option>
                            <option value="inactive" <?= (($editCategory['status'] ?? '') === 'inactive' ? 'selected' : '') ?>>Inactive (Hidden from public)</option>
                        </select>
                    </div>

                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-primary flex-grow-1">
                            <i class="bi bi-check-lg me-1"></i><?= $editCategory ? 'Update Category' : 'Save Category' ?>
                        </button>
                        <?php if ($editCategory): ?>
                            <a href="/admin/categories" class="btn btn-outline-secondary">Cancel</a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>

        <!-- Categories List -->
        <div class="col-lg-8">
            <div class="card shadow-sm border-1">
                <div class="card-header bg-white py-3">
                    <h5 class="fw-bold mb-0">Directory Categories (<?= count($categories) ?>)</h5>
                </div>

                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light small">
                                <tr>
                                    <th style="width: 40px;">Icon</th>
                                    <th>Category Name</th>
                                    <th>Slug</th>
                                    <th>Businesses</th>
                                    <th>Status</th>
                                    <th class="text-end">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($categories as $cat): ?>
                                    <tr id="admin-cat-row-<?= (int)$cat['id'] ?>">
                                        <td class="text-center text-primary fs-5">
                                            <i class="bi <?= e($cat['icon']) ?>"></i>
                                        </td>
                                        <td>
                                            <strong><?= e($cat['name']) ?></strong>
                                            <?php if (!empty($cat['description'])): ?>
                                                <div class="text-muted small text-truncate" style="max-width: 250px;"><?= e($cat['description']) ?></div>
                                            <?php endif; ?>
                                        </td>
                                        <td class="small text-muted font-monospace">
                                            /category/<?= e($cat['slug']) ?>
                                        </td>
                                        <td>
                                            <span class="badge bg-light text-dark border">
                                                <?= (int)$cat['business_count'] ?> <?= ((int)$cat['business_count'] === 1 ? 'listing' : 'listings') ?>
                                            </span>
                                        </td>
                                        <td>
                                            <form action="/admin/actions.php" method="POST" class="d-inline">
                                                <?= csrf_field() ?>
                                                <input type="hidden" name="action" value="category_toggle_status">
                                                <input type="hidden" name="id" value="<?= (int)$cat['id'] ?>">
                                                <button type="submit" class="badge <?= ($cat['status'] === 'active' ? 'badge-status-approved' : 'badge-status-suspended') ?> border-0 px-2 py-1" style="cursor: pointer;" title="Click to switch status">
                                                    <?= ucfirst(e($cat['status'])) ?> <i class="bi bi-arrow-repeat ms-1" style="font-size:0.7rem;"></i>
                                                </button>
                                            </form>
                                        </td>
                                        <td class="text-end">
                                            <div class="btn-group btn-group-sm">
                                                <a href="/category/<?= e($cat['slug']) ?>" class="btn btn-outline-secondary" target="_blank" title="View Public Category">
                                                    <i class="bi bi-eye"></i>
                                                </a>
                                                <a href="/admin/categories?edit=<?= (int)$cat['id'] ?>" class="btn btn-outline-primary" title="Edit Category">
                                                    <i class="bi bi-pencil"></i>
                                                </a>
                                                <?php if ((int)$cat['business_count'] === 0): ?>
                                                    <button class="btn btn-outline-danger" title="Delete Category"
                                                            hx-post="/admin/actions.php"
                                                            hx-vals='{"action": "category_delete", "id": <?= (int)$cat['id'] ?>}'
                                                            hx-confirm="Permanently delete category '<?= e($cat['name']) ?>'?"
                                                            hx-target="#admin-cat-row-<?= (int)$cat['id'] ?>"
                                                            hx-swap="outerHTML">
                                                        <i class="bi bi-trash"></i>
                                                    </button>
                                                <?php else: ?>
                                                    <button class="btn btn-outline-secondary" disabled title="Cannot delete: listings exist">
                                                        <i class="bi bi-trash"></i>
                                                    </button>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
