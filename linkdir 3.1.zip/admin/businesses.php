<?php
/**
 * linkdir - Admin Business Management
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';

auth_require_admin();
$db = get_db();

// Handle quick update of user listing limit
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'quick_update_limit') {
    csrf_require();
    $newLimit = max(0, (int)($_POST['user_listing_limit'] ?? 5));
    set_user_listing_limit($newLimit);
    flash_set('success', 'User entry limit updated to ' . ($newLimit === 0 ? 'Unlimited' : $newLimit . ' listings per user') . '.');
    header('Location: /admin/businesses');
    exit;
}

$currentLimit = get_user_listing_limit();

// Filters
$search = trim($_GET['q'] ?? '');
$categorySlug = trim($_GET['category'] ?? '');
$status = trim($_GET['status'] ?? '');
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 20;
$offset = ($page - 1) * $perPage;

// Fetch categories
$categories = $db->query("SELECT id, name, slug FROM categories ORDER BY name ASC")->fetchAll();

// Build query
$where = ["1=1"];
$params = [];

if ($search !== '') {
    $where[] = "(b.business_name LIKE ? OR b.country LIKE ? OR u.email LIKE ? OR u.name LIKE ?)";
    $term = '%' . $search . '%';
    $params[] = $term;
    $params[] = $term;
    $params[] = $term;
    $params[] = $term;
}

if ($categorySlug !== '') {
    $where[] = "c.slug = ?";
    $params[] = $categorySlug;
}

if ($status !== '' && in_array($status, ['approved', 'pending', 'rejected', 'suspended'])) {
    $where[] = "b.status = ?";
    $params[] = $status;
}

$whereClause = implode(' AND ', $where);

// Count
$countStmt = $db->prepare("
    SELECT COUNT(b.id)
    FROM businesses b
    JOIN categories c ON b.category_id = c.id
    LEFT JOIN users u ON b.user_id = u.id
    WHERE {$whereClause}
");
$countStmt->execute($params);
$totalItems = (int)$countStmt->fetchColumn();
$totalPages = ceil($totalItems / $perPage);

// Fetch data
$stmt = $db->prepare("
    SELECT b.*, c.name as category_name, c.slug as category_slug,
           u.name as owner_name, u.email as owner_email
    FROM businesses b
    JOIN categories c ON b.category_id = c.id
    LEFT JOIN users u ON b.user_id = u.id
    WHERE {$whereClause}
    ORDER BY b.created_at DESC
    LIMIT {$perPage} OFFSET {$offset}
");
$stmt->execute($params);
$businesses = $stmt->fetchAll();

$pageTitle = 'Manage Businesses - Admin';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/includes/admin-nav.php';
?>

<div class="container mb-5">
    <?= flash_render() ?>

    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-2 mb-3">
        <h2 class="h4 fw-bold mb-0">Business Listings (<?= number_format($totalItems) ?>)</h2>
        <div class="d-flex gap-2 align-items-center">
            <button type="button" class="btn btn-outline-secondary btn-sm d-inline-flex align-items-center gap-1 shadow-xs" data-bs-toggle="modal" data-bs-target="#userLimitModal" title="Configure how many listings standard users can add">
                <i class="bi bi-speedometer2 text-primary"></i>
                <span>User Entry Limit: <strong class="text-dark"><?= $currentLimit === 0 ? 'Unlimited' : $currentLimit . ' per user' ?></strong></span>
                <i class="bi bi-pencil-square text-muted ms-1 small"></i>
            </button>
            <a href="/admin/settings" class="btn btn-outline-primary btn-sm d-inline-flex align-items-center gap-1 shadow-xs" title="Directory & System Settings">
                <i class="bi bi-sliders"></i>
                <span class="d-none d-sm-inline">Settings</span>
            </a>
            <a href="/dashboard/business/add" class="btn btn-primary btn-sm d-inline-flex align-items-center gap-1 shadow-xs">
                <i class="bi bi-plus-lg"></i><span>Add New Listing</span>
            </a>
        </div>
    </div>

    <!-- Filter Card -->
    <div class="card shadow-sm border-1 p-3 mb-4 bg-light">
        <form action="/admin/businesses" method="GET" class="row g-2 align-items-end">
            <div class="col-md-4">
                <label class="form-label small fw-semibold text-muted mb-1">Search Keyword / Owner</label>
                <input type="text" name="q" class="form-control form-control-sm" placeholder="Name, region, owner email..." value="<?= e($search) ?>">
            </div>

            <div class="col-md-3">
                <label class="form-label small fw-semibold text-muted mb-1">Category</label>
                <select name="category" class="form-select form-select-sm">
                    <option value="">All Categories</option>
                    <?php foreach ($categories as $cat): ?>
                        <option value="<?= e($cat['slug']) ?>" <?= ($categorySlug === $cat['slug'] ? 'selected' : '') ?>><?= e($cat['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-md-3">
                <label class="form-label small fw-semibold text-muted mb-1">Status</label>
                <select name="status" class="form-select form-select-sm">
                    <option value="">All Statuses</option>
                    <option value="pending" <?= ($status === 'pending' ? 'selected' : '') ?>>Pending Approval</option>
                    <option value="approved" <?= ($status === 'approved' ? 'selected' : '') ?>>Approved</option>
                    <option value="rejected" <?= ($status === 'rejected' ? 'selected' : '') ?>>Rejected</option>
                    <option value="suspended" <?= ($status === 'suspended' ? 'selected' : '') ?>>Suspended</option>
                </select>
            </div>

            <div class="col-md-2 d-flex gap-1">
                <button type="submit" class="btn btn-primary btn-sm flex-grow-1">Filter</button>
                <a href="/admin/businesses" class="btn btn-outline-secondary btn-sm">Reset</a>
            </div>
        </form>
    </div>

    <!-- Businesses Table -->
    <div class="card shadow-sm border-1">
        <div class="card-body p-0">
            <?php if (!empty($businesses)): ?>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light small">
                            <tr>
                                <th style="width: 50px;">Logo</th>
                                <th>Business Name</th>
                                <th>Category</th>
                                <th>Location</th>
                                <th>Owner</th>
                                <th>Status</th>
                                <th class="text-end">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($businesses as $b): ?>
                                <tr id="admin-biz-row-<?= (int)$b['id'] ?>">
                                    <td>
                                        <?php if (!empty($b['logo'])): ?>
                                            <img src="/uploads/businesses/<?= e($b['logo']) ?>" alt="" class="rounded" style="width: 38px; height: 38px; object-fit: cover;">
                                        <?php else: ?>
                                            <div class="rounded bg-light text-muted d-flex align-items-center justify-content-center fw-bold" style="width: 38px; height: 38px; font-size: 0.8rem;">
                                                <?= strtoupper(substr($b['business_name'], 0, 2)) ?>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <strong>
                                            <a href="/business/<?= e($b['slug']) ?>" class="text-decoration-none text-dark" target="_blank">
                                                <?= e($b['business_name']) ?> <i class="bi bi-box-arrow-up-right small text-muted"></i>
                                            </a>
                                        </strong>
                                        <div class="text-muted small">Added: <?= format_date($b['created_at']) ?></div>
                                    </td>
                                    <td>
                                        <span class="badge bg-light text-dark border"><?= e($b['category_name']) ?></span>
                                    </td>
                                    <td class="small">
                                        <?= !empty($b['country']) ? e($b['country']) : '—' ?>
                                    </td>
                                    <td class="small">
                                        <?= e($b['owner_name'] ?? 'System') ?><br>
                                        <span class="text-muted"><?= e($b['owner_email'] ?? '') ?></span>
                                    </td>
                                    <td>
                                        <div class="dropdown">
                                            <?php
                                            $badgeClass = match($b['status']) {
                                                'approved'  => 'badge-status-approved',
                                                'pending'   => 'badge-status-pending',
                                                'rejected'  => 'badge-status-rejected',
                                                'suspended' => 'badge-status-suspended',
                                                default     => 'bg-secondary'
                                            };
                                            ?>
                                            <button class="btn btn-sm dropdown-toggle p-0 border-0" type="button" data-bs-toggle="dropdown">
                                                <span class="badge <?= $badgeClass ?> px-2 py-1" id="status-badge-<?= (int)$b['id'] ?>">
                                                    <?= ucfirst(e($b['status'])) ?>
                                                </span>
                                            </button>
                                            <ul class="dropdown-menu shadow-sm">
                                                <li>
                                                    <button class="dropdown-item small text-success"
                                                            hx-post="/admin/actions.php"
                                                            hx-vals='{"action": "business_status", "id": <?= (int)$b['id'] ?>, "status": "approved"}'
                                                            hx-target="#status-badge-<?= (int)$b['id'] ?>"
                                                            hx-swap="outerHTML">
                                                        <i class="bi bi-check-circle me-1"></i> Approve
                                                    </button>
                                                </li>
                                                <li>
                                                    <button class="dropdown-item small text-warning"
                                                            hx-post="/admin/actions.php"
                                                            hx-vals='{"action": "business_status", "id": <?= (int)$b['id'] ?>, "status": "pending"}'
                                                            hx-target="#status-badge-<?= (int)$b['id'] ?>"
                                                            hx-swap="outerHTML">
                                                        <i class="bi bi-hourglass-split me-1"></i> Mark Pending
                                                    </button>
                                                </li>
                                                <li>
                                                    <button class="dropdown-item small text-danger"
                                                            hx-post="/admin/actions.php"
                                                            hx-vals='{"action": "business_status", "id": <?= (int)$b['id'] ?>, "status": "rejected"}'
                                                            hx-target="#status-badge-<?= (int)$b['id'] ?>"
                                                            hx-swap="outerHTML">
                                                        <i class="bi bi-x-circle me-1"></i> Reject
                                                    </button>
                                                </li>
                                                <li>
                                                    <button class="dropdown-item small text-secondary"
                                                            hx-post="/admin/actions.php"
                                                            hx-vals='{"action": "business_status", "id": <?= (int)$b['id'] ?>, "status": "suspended"}'
                                                            hx-target="#status-badge-<?= (int)$b['id'] ?>"
                                                            hx-swap="outerHTML">
                                                        <i class="bi bi-slash-circle me-1"></i> Suspend
                                                    </button>
                                                </li>
                                            </ul>
                                        </div>
                                    </td>
                                    <td class="text-end">
                                        <div class="btn-group btn-group-sm">
                                            <a href="/dashboard/business/edit/<?= (int)$b['id'] ?>" class="btn btn-outline-primary" title="Edit Listing">
                                                <i class="bi bi-pencil"></i>
                                            </a>
                                            <button class="btn btn-outline-danger" title="Permanently Delete"
                                                    hx-post="/admin/actions.php"
                                                    hx-vals='{"action": "business_delete", "id": <?= (int)$b['id'] ?>}'
                                                    hx-confirm="Permanently remove '<?= e($b['business_name']) ?>' and all its reviews?"
                                                    hx-target="#admin-biz-row-<?= (int)$b['id'] ?>"
                                                    hx-swap="outerHTML">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <?php if ($totalPages > 1): ?>
                    <div class="card-footer bg-white py-3">
                        <ul class="pagination justify-content-center mb-0">
                            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                                <li class="page-item <?= ($page == $i ? 'active' : '') ?>">
                                    <a class="page-link" href="/admin/businesses?page=<?= $i ?>&status=<?= urlencode($status) ?>&q=<?= urlencode($search) ?>&category=<?= urlencode($categorySlug) ?>">
                                        <?= $i ?>
                                    </a>
                                </li>
                            <?php endfor; ?>
                        </ul>
                    </div>
                <?php endif; ?>
            <?php else: ?>
                <div class="p-5 text-center text-muted">
                    <p class="mb-0">No business listings match your criteria.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Quick User Listing Limit Modal -->
<div class="modal fade" id="userLimitModal" tabindex="-1" aria-labelledby="userLimitModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow">
            <form action="/admin/businesses" method="POST">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="quick_update_limit">
                
                <div class="modal-header bg-light border-bottom">
                    <h5 class="modal-title fw-bold" id="userLimitModalLabel">
                        <i class="bi bi-speedometer2 text-primary me-2"></i>Set User Entry Limit
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body p-4">
                    <p class="text-secondary small mb-3">
                        Set the maximum number of business listings that any standard registered user can add to the directory.
                    </p>

                    <div class="mb-3">
                        <label for="modalLimitInput" class="form-label fw-bold">Maximum Allowed Listings</label>
                        <div class="input-group">
                            <input type="number" name="user_listing_limit" id="modalLimitInput" class="form-control form-control-lg fw-bold text-primary" min="0" max="9999" value="<?= (int)$currentLimit ?>" required>
                            <span class="input-group-text bg-light text-muted">listings per user</span>
                        </div>
                        <div class="form-text mt-1 text-muted">
                            Enter any number (e.g., <strong>5</strong> or <strong>10</strong>). Enter <strong>0</strong> for unlimited listings.
                        </div>
                    </div>

                    <!-- Quick buttons -->
                    <div class="mb-3">
                        <label class="form-label small fw-bold text-muted text-uppercase mb-1" style="font-size:0.75rem;">Quick Presets</label>
                        <div class="d-flex flex-wrap gap-2">
                            <button type="button" class="btn btn-sm btn-outline-secondary modal-preset" data-num="1">1</button>
                            <button type="button" class="btn btn-sm btn-outline-secondary modal-preset" data-num="3">3</button>
                            <button type="button" class="btn btn-sm btn-outline-primary fw-bold modal-preset" data-num="5">5</button>
                            <button type="button" class="btn btn-sm btn-outline-secondary modal-preset" data-num="10">10</button>
                            <button type="button" class="btn btn-sm btn-outline-dark modal-preset" data-num="0">Unlimited (0)</button>
                        </div>
                    </div>

                    <div class="p-3 bg-light rounded small text-muted border">
                        <i class="bi bi-info-circle text-primary me-1"></i>
                        When a user reaches this number, they cannot create additional listings until an existing listing is deleted. Administrators are never restricted.
                    </div>
                </div>
                <div class="modal-footer bg-light border-top">
                    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary btn-sm fw-bold">
                        <i class="bi bi-check2 me-1"></i>Save Entry Limit
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const input = document.getElementById('modalLimitInput');
    const presets = document.querySelectorAll('.modal-preset');
    if (input && presets) {
        presets.forEach(btn => {
            btn.addEventListener('click', function() {
                input.value = this.dataset.num;
                input.focus();
            });
        });
    }
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
