<?php
/**
 * linkdir - Admin System & Listing Settings
 * 
 * Allows administrators to configure:
 * - User entry limit (Maximum listings a user can create, e.g. 5)
 * - Directory moderation policies (Approval requirements)
 * - Navigation to Footer & Branding settings
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';

auth_require_admin();
$db = get_db();

// Handle Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_require();

    $action = $_POST['action'] ?? 'save_settings';

    if ($action === 'save_settings') {
        $userLimit = max(0, (int)($_POST['user_listing_limit'] ?? 5));
        set_user_listing_limit($userLimit);

        $bizApproval = !empty($_POST['require_business_approval']) ? '1' : '0';
        $revApproval = !empty($_POST['require_review_approval']) ? '1' : '0';
        set_setting('require_business_approval', $bizApproval);
        set_setting('require_review_approval', $revApproval);

        flash_set('success', 'Directory settings updated successfully. User listing limit is now set to ' . ($userLimit === 0 ? 'Unlimited' : $userLimit . ' listings per user') . '.');
        header('Location: /admin/settings');
        exit;
    }
}

// Current Settings
$currentLimit = get_user_listing_limit();
$requireBizApproval = get_setting('require_business_approval', REQUIRE_BUSINESS_APPROVAL ? '1' : '0') === '1';
$requireRevApproval = get_setting('require_review_approval', REQUIRE_REVIEW_APPROVAL ? '1' : '0') === '1';

// Statistics for admin overview
$totalUsers = (int)$db->query("SELECT COUNT(*) FROM users WHERE role = 'user'")->fetchColumn();
$totalBusinesses = (int)$db->query("SELECT COUNT(*) FROM businesses")->fetchColumn();

// Count users who have reached the limit
$usersAtLimit = 0;
if ($currentLimit > 0) {
    $atLimitStmt = $db->prepare("
        SELECT COUNT(*) FROM (
            SELECT user_id, COUNT(id) as cnt 
            FROM businesses 
            GROUP BY user_id 
            HAVING cnt >= ?
        ) sub
    ");
    $atLimitStmt->execute([$currentLimit]);
    $usersAtLimit = (int)$atLimitStmt->fetchColumn();
}

$avgListings = ($totalUsers > 0) ? round($totalBusinesses / $totalUsers, 1) : 0;

$pageTitle = 'Directory & Listing Settings - Admin';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/includes/admin-nav.php';
?>

<div class="container mb-5">
    <?= flash_render() ?>

    <!-- Page Header -->
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
        <div>
            <h2 class="h4 fw-bold text-dark mb-1">
                <i class="bi bi-sliders text-primary me-2"></i>Directory &amp; Listing Settings
            </h2>
            <p class="text-secondary small mb-0">
                Configure user listing entry limits, approval workflows, and general directory policies.
            </p>
        </div>
        <div class="d-flex gap-2">
            <a href="/admin/footer" class="btn btn-outline-secondary btn-sm d-inline-flex align-items-center gap-1">
                <i class="bi bi-layout-text-window-reverse"></i>
                <span>Footer &amp; Branding Settings</span>
            </a>
            <a href="/admin/businesses" class="btn btn-outline-primary btn-sm d-inline-flex align-items-center gap-1">
                <i class="bi bi-buildings"></i>
                <span>Manage Listings</span>
            </a>
        </div>
    </div>

    <!-- Quick Stats Overview -->
    <div class="row g-3 mb-4">
        <div class="col-6 col-md-3">
            <div class="card p-3 border shadow-xs">
                <div class="text-muted small fw-semibold">Current User Limit</div>
                <div class="fs-4 fw-bold text-primary">
                    <?= ($currentLimit === 0) ? 'Unlimited' : $currentLimit . ' <small class="fs-6 fw-normal text-muted">per user</small>' ?>
                </div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="card p-3 border shadow-xs">
                <div class="text-muted small fw-semibold">Standard Users</div>
                <div class="fs-4 fw-bold text-dark"><?= $totalUsers ?></div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="card p-3 border shadow-xs">
                <div class="text-muted small fw-semibold">Users at Max Limit</div>
                <div class="fs-4 fw-bold <?= $usersAtLimit > 0 ? 'text-warning' : 'text-success' ?>"><?= $usersAtLimit ?></div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="card p-3 border shadow-xs">
                <div class="text-muted small fw-semibold">Avg Listings / User</div>
                <div class="fs-4 fw-bold text-secondary"><?= $avgListings ?></div>
            </div>
        </div>
    </div>

    <div class="row g-4">
        <!-- Main Form Column -->
        <div class="col-lg-8">
            <form action="/admin/settings" method="POST">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="save_settings">

                <!-- Feature 1: User Listing Entry Limit -->
                <div class="card border shadow-xs mb-4">
                    <div class="card-header bg-white py-3 border-bottom d-flex justify-content-between align-items-center">
                        <h5 class="card-title fw-bold mb-0 text-dark">
                            <i class="bi bi-speedometer2 text-primary me-2"></i>User Entry Limit (Listing Allowance)
                        </h5>
                        <span class="badge bg-primary-subtle text-primary border border-primary-subtle">Core Policy</span>
                    </div>
                    <div class="card-body p-4">
                        <div class="mb-4">
                            <label for="userLimitInput" class="form-label fw-bold text-dark">
                                Maximum Listings Per User
                            </label>
                            <div class="input-group input-group-lg" style="max-width: 320px;">
                                <input type="number" name="user_listing_limit" id="userLimitInput" class="form-control fw-bold text-primary" min="0" max="9999" value="<?= (int)$currentLimit ?>" required>
                                <span class="input-group-text bg-light text-muted">listings</span>
                            </div>
                            <div class="form-text text-muted mt-2">
                                Enter the exact number of businesses or services each registered user is permitted to create (e.g. <strong>5</strong>, <strong>10</strong>, or <strong>1</strong>). Enter <strong>0</strong> for unlimited listings.
                            </div>
                        </div>

                        <!-- Quick Preset Buttons -->
                        <div class="mb-4">
                            <label class="form-label small fw-bold text-muted text-uppercase mb-2" style="font-size:0.75rem; letter-spacing:0.5px;">Quick Presets</label>
                            <div class="d-flex flex-wrap gap-2">
                                <button type="button" class="btn btn-outline-secondary btn-sm preset-btn" data-val="1">1 Listing</button>
                                <button type="button" class="btn btn-outline-secondary btn-sm preset-btn" data-val="3">3 Listings</button>
                                <button type="button" class="btn btn-outline-primary btn-sm preset-btn fw-bold" data-val="5">5 Listings (Default)</button>
                                <button type="button" class="btn btn-outline-secondary btn-sm preset-btn" data-val="10">10 Listings</button>
                                <button type="button" class="btn btn-outline-secondary btn-sm preset-btn" data-val="25">25 Listings</button>
                                <button type="button" class="btn btn-outline-dark btn-sm preset-btn" data-val="0">Unlimited (0)</button>
                            </div>
                        </div>

                        <!-- Live Behavior Explanation Box -->
                        <div class="p-3 bg-light rounded border">
                            <div class="d-flex gap-2">
                                <i class="bi bi-info-circle-fill text-primary fs-5 mt-1"></i>
                                <div class="small text-secondary">
                                    <strong class="text-dark d-block mb-1">How this limit is enforced:</strong>
                                    <ul class="mb-0 ps-3">
                                        <li>Standard users who have created their maximum allowance cannot submit new businesses until an existing one is deleted.</li>
                                        <li>Users will see their real-time allowance indicator in their dashboard (e.g., <em>"3 of 5 listings used"</em>).</li>
                                        <li><strong>Administrators are always exempt</strong> and can add unlimited listings without restriction.</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Feature 2: Directory Moderation & Approvals -->
                <div class="card border shadow-xs mb-4">
                    <div class="card-header bg-white py-3 border-bottom">
                        <h5 class="card-title fw-bold mb-0 text-dark">
                            <i class="bi bi-shield-check text-primary me-2"></i>Moderation &amp; Publishing Approvals
                        </h5>
                    </div>
                    <div class="card-body p-4">
                        <div class="mb-3">
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" name="require_business_approval" id="requireBizCheck" value="1" <?= $requireBizApproval ? 'checked' : '' ?>>
                                <label class="form-check-label fw-bold text-dark" for="requireBizCheck">
                                    Require Administrator Approval for New Businesses
                                </label>
                            </div>
                            <div class="text-muted small ms-4 ps-2">
                                When enabled, submitted businesses remain in <code>pending</code> status until an administrator reviews and approves them in the admin panel.
                            </div>
                        </div>

                        <hr class="my-3">

                        <div class="mb-0">
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" name="require_review_approval" id="requireRevCheck" value="1" <?= $requireRevApproval ? 'checked' : '' ?>>
                                <label class="form-check-label fw-bold text-dark" for="requireRevCheck">
                                    Require Administrator Approval for Reviews
                                </label>
                            </div>
                            <div class="text-muted small ms-4 ps-2">
                                When enabled, customer reviews remain pending until vetted by an administrator.
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Submit Button -->
                <div class="d-flex gap-2">
                    <button type="submit" class="btn btn-primary btn-lg fw-bold shadow-xs px-4">
                        <i class="bi bi-check2-circle me-1"></i>Save Directory Settings
                    </button>
                    <a href="/admin" class="btn btn-outline-secondary btn-lg">Cancel</a>
                </div>
            </form>
        </div>

        <!-- Right Side: Helpful Guidance & Navigation -->
        <div class="col-lg-4">
            <div class="d-flex flex-column gap-4">
                <!-- Footer Management Link Card -->
                <div class="card border shadow-xs">
                    <div class="card-body p-4">
                        <div class="d-flex align-items-center gap-2 mb-2">
                            <i class="bi bi-layout-text-window-reverse text-primary fs-4"></i>
                            <h6 class="fw-bold mb-0 text-dark">Footer &amp; Pages</h6>
                        </div>
                        <p class="small text-muted mb-3">
                            Customize the brand description below the logo, select which categories appear in the footer, and manage custom legal or info pages.
                        </p>
                        <div class="d-grid gap-2">
                            <a href="/admin/footer" class="btn btn-outline-secondary btn-sm">
                                <i class="bi bi-gear me-1"></i>Manage Footer Settings
                            </a>
                            <a href="/admin/pages" class="btn btn-outline-secondary btn-sm">
                                <i class="bi bi-file-earmark-text me-1"></i>Manage Custom Pages
                            </a>
                        </div>
                    </div>
                </div>

                <!-- User Management Shortcut Card -->
                <div class="card border shadow-xs">
                    <div class="card-body p-4">
                        <div class="d-flex align-items-center gap-2 mb-2">
                            <i class="bi bi-people text-primary fs-4"></i>
                            <h6 class="fw-bold mb-0 text-dark">User Accounts</h6>
                        </div>
                        <p class="small text-muted mb-3">
                            Inspect registered users, check how many listings each user has created, and adjust user roles or account statuses.
                        </p>
                        <a href="/admin/users" class="btn btn-light border btn-sm w-100">
                            <i class="bi bi-box-arrow-right me-1"></i>View All Users
                        </a>
                    </div>
                </div>

                <!-- Offline Documentation Reminder -->
                <div class="card border-info border-2 bg-info-subtle shadow-xs p-4">
                    <h6 class="fw-bold text-dark mb-2"><i class="bi bi-book me-1"></i>Admin Guide Available</h6>
                    <p class="small text-secondary mb-2">
                        For server deployment instructions, database credential setup, and cPanel configuration, refer to the offline guide in:
                    </p>
                    <code class="small d-block mb-0 bg-white p-2 rounded border">docs/ADMIN_SETUP_GUIDE.md</code>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const limitInput = document.getElementById('userLimitInput');
    const presetBtns = document.querySelectorAll('.preset-btn');

    presetBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            limitInput.value = this.dataset.val;
            limitInput.focus();
            
            // Highlight active preset
            presetBtns.forEach(b => b.classList.replace('btn-primary', 'btn-outline-secondary'));
            this.classList.replace('btn-outline-secondary', 'btn-primary');
        });
    });
});
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
