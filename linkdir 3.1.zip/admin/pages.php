<?php
/**
 * linkdir - Admin Custom Pages Management
 * 
 * Allows system administrators to create, edit, manage, and toggle pages displayed in the website footer.
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';

auth_require_admin();
$db = get_db();

$errors = [];
$editPage = null;

// Handle Delete Request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete') {
    csrf_require();
    $deleteId = (int)($_POST['id'] ?? 0);

    if ($deleteId > 0) {
        $delStmt = $db->prepare("DELETE FROM pages WHERE id = ?");
        $delStmt->execute([$deleteId]);
        flash_set('success', 'Page successfully deleted.');
        header('Location: /admin/pages');
        exit;
    }
}

// Handle Add / Edit Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && in_array($_POST['action'], ['create', 'update'])) {
    csrf_require();

    $pageId = (int)($_POST['id'] ?? 0);
    $title = trim($_POST['title'] ?? '');
    $customSlug = trim($_POST['slug'] ?? '');
    $metaDescription = trim($_POST['meta_description'] ?? '');
    $content = trim($_POST['content'] ?? '');
    $status = in_array($_POST['status'] ?? 'published', ['published', 'draft']) ? $_POST['status'] : 'published';
    $showInFooter = !empty($_POST['show_in_footer']) ? 1 : 0;
    $sortOrder = (int)($_POST['sort_order'] ?? 0);

    if (empty($title)) {
        $errors[] = 'Page title is required.';
    }

    if (empty($content)) {
        $errors[] = 'Page content cannot be empty.';
    }

    // Process Slug
    $slug = !empty($customSlug) ? slugify($customSlug) : slugify($title);
    if (empty($slug)) {
        $slug = 'page-' . time();
    }

    // Slug uniqueness check
    if ($pageId > 0) {
        $checkStmt = $db->prepare("SELECT id FROM pages WHERE slug = ? AND id != ? LIMIT 1");
        $checkStmt->execute([$slug, $pageId]);
        if ($checkStmt->fetch()) {
            $slug .= '-' . rand(10, 99);
        }
    } else {
        $checkStmt = $db->prepare("SELECT id FROM pages WHERE slug = ? LIMIT 1");
        $checkStmt->execute([$slug]);
        if ($checkStmt->fetch()) {
            $slug .= '-' . rand(10, 99);
        }
    }

    if (empty($errors)) {
        if ($pageId > 0) {
            $stmt = $db->prepare("
                UPDATE pages 
                SET title = ?, slug = ?, content = ?, meta_description = ?, status = ?, show_in_footer = ?, sort_order = ?, updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
            ");
            $stmt->execute([$title, $slug, $content, $metaDescription, $status, $showInFooter, $sortOrder, $pageId]);
            flash_set('success', 'Page "' . e($title) . '" updated successfully.');
        } else {
            $stmt = $db->prepare("
                INSERT INTO pages (title, slug, content, meta_description, status, show_in_footer, sort_order, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
            ");
            $stmt->execute([$title, $slug, $content, $metaDescription, $status, $showInFooter, $sortOrder]);
            flash_set('success', 'New page "' . e($title) . '" created successfully.');
        }
        header('Location: /admin/pages');
        exit;
    }
}

// Check Edit Mode
$editId = (int)($_GET['edit'] ?? 0);
if ($editId > 0) {
    $eStmt = $db->prepare("SELECT * FROM pages WHERE id = ? LIMIT 1");
    $eStmt->execute([$editId]);
    $editPage = $eStmt->fetch();
}

// Fetch stats
$totalCount = (int)$db->query("SELECT COUNT(*) FROM pages")->fetchColumn();
$publishedCount = (int)$db->query("SELECT COUNT(*) FROM pages WHERE status = 'published'")->fetchColumn();
$draftCount = (int)$db->query("SELECT COUNT(*) FROM pages WHERE status = 'draft'")->fetchColumn();
$footerCount = (int)$db->query("SELECT COUNT(*) FROM pages WHERE show_in_footer = 1 AND status = 'published'")->fetchColumn();

// Fetch filter & search
$filter = trim($_GET['filter'] ?? 'all');
$search = trim($_GET['search'] ?? '');

$sql = "SELECT * FROM pages WHERE 1=1";
$params = [];

if ($filter === 'published') {
    $sql .= " AND status = 'published'";
} elseif ($filter === 'draft') {
    $sql .= " AND status = 'draft'";
} elseif ($filter === 'footer') {
    $sql .= " AND show_in_footer = 1";
}

if (!empty($search)) {
    $sql .= " AND (title LIKE ? OR slug LIKE ?)";
    $params[] = '%' . $search . '%';
    $params[] = '%' . $search . '%';
}

$sql .= " ORDER BY sort_order ASC, id DESC";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$pages = $stmt->fetchAll();

$pageTitle = 'Custom Pages Management - Admin';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/includes/admin-nav.php';
?>

<div class="container mb-5">
    <?= flash_render() ?>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-danger shadow-xs mb-4">
            <ul class="mb-0 ps-3">
                <?php foreach ($errors as $err): ?>
                    <li><?= e($err) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <!-- Header / Quick Info -->
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3 mb-4">
        <div>
            <h2 class="h4 fw-bold text-dark mb-1">
                <i class="bi bi-file-earmark-text text-primary me-2"></i>Custom Pages &amp; Footer Links
            </h2>
            <p class="text-secondary small mb-0">
                Create informational pages (About Us, Privacy Policy, Terms, Help) and choose which appear as links in your website footer.
            </p>
        </div>
        <div class="d-flex gap-2">
            <a href="/admin/footer" class="btn btn-outline-secondary btn-sm d-inline-flex align-items-center gap-1">
                <i class="bi bi-layout-text-window-reverse"></i>
                <span>Footer Settings</span>
            </a>
            <?php if (!$editPage): ?>
                <a href="#pageFormCard" class="btn btn-primary btn-sm d-inline-flex align-items-center gap-1">
                    <i class="bi bi-plus-lg"></i>
                    <span>Create New Page</span>
                </a>
            <?php else: ?>
                <a href="/admin/pages" class="btn btn-light btn-sm border d-inline-flex align-items-center gap-1">
                    <i class="bi bi-x-circle"></i>
                    <span>Cancel Editing</span>
                </a>
            <?php endif; ?>
        </div>
    </div>

    <!-- Quick Stats Cards -->
    <div class="row g-3 mb-4">
        <div class="col-6 col-md-3">
            <div class="card p-3 border shadow-xs">
                <div class="text-muted small fw-semibold">Total Pages</div>
                <div class="fs-4 fw-bold text-dark"><?= $totalCount ?></div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="card p-3 border shadow-xs">
                <div class="text-muted small fw-semibold">Published</div>
                <div class="fs-4 fw-bold text-success"><?= $publishedCount ?></div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="card p-3 border shadow-xs">
                <div class="text-muted small fw-semibold">Drafts</div>
                <div class="fs-4 fw-bold text-secondary"><?= $draftCount ?></div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="card p-3 border shadow-xs border-primary-subtle bg-primary-subtle">
                <div class="text-primary small fw-semibold">Shown in Footer</div>
                <div class="fs-4 fw-bold text-primary"><?= $footerCount ?></div>
            </div>
        </div>
    </div>

    <div class="row g-4">
        <!-- Left Column: Pages List -->
        <div class="col-lg-7">
            <div class="card border shadow-xs">
                <div class="card-header bg-white py-3 border-bottom d-flex flex-column flex-sm-row justify-content-between align-items-sm-center gap-2">
                    <div class="d-flex align-items-center gap-2">
                        <span class="fw-bold text-dark">Directory Pages</span>
                        <span class="badge bg-secondary rounded-pill"><?= count($pages) ?></span>
                    </div>

                    <!-- Filter Links -->
                    <div class="btn-group btn-group-sm" role="group">
                        <a href="/admin/pages" class="btn btn-<?= $filter === 'all' ? 'primary' : 'outline-secondary' ?>">All</a>
                        <a href="/admin/pages?filter=published" class="btn btn-<?= $filter === 'published' ? 'primary' : 'outline-secondary' ?>">Published</a>
                        <a href="/admin/pages?filter=footer" class="btn btn-<?= $filter === 'footer' ? 'primary' : 'outline-secondary' ?>">In Footer</a>
                        <a href="/admin/pages?filter=draft" class="btn btn-<?= $filter === 'draft' ? 'primary' : 'outline-secondary' ?>">Drafts</a>
                    </div>
                </div>

                <!-- Search form -->
                <div class="p-3 bg-light border-bottom">
                    <form action="/admin/pages" method="GET" class="d-flex gap-2">
                        <?php if ($filter !== 'all'): ?>
                            <input type="hidden" name="filter" value="<?= e($filter) ?>">
                        <?php endif; ?>
                        <div class="input-group input-group-sm">
                            <span class="input-group-text bg-white border-end-0"><i class="bi bi-search text-muted"></i></span>
                            <input type="text" name="search" class="form-control border-start-0" placeholder="Search by title or slug..." value="<?= e($search) ?>">
                        </div>
                        <button type="submit" class="btn btn-secondary btn-sm">Filter</button>
                        <?php if (!empty($search)): ?>
                            <a href="/admin/pages<?= $filter !== 'all' ? '?filter=' . urlencode($filter) : '' ?>" class="btn btn-outline-secondary btn-sm">Clear</a>
                        <?php endif; ?>
                    </form>
                </div>

                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light small text-muted text-uppercase">
                            <tr>
                                <th style="width: 40px;" class="text-center">Order</th>
                                <th>Page Details</th>
                                <th style="width: 100px;">Footer</th>
                                <th style="width: 90px;">Status</th>
                                <th style="width: 110px;" class="text-end">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($pages)): ?>
                                <tr>
                                    <td colspan="5" class="text-center py-5 text-muted">
                                        <i class="bi bi-file-earmark-x fs-1 d-block mb-2 text-secondary opacity-50"></i>
                                        <p class="mb-0">No pages found matching criteria.</p>
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($pages as $p): ?>
                                    <tr class="<?= ($editPage && (int)$editPage['id'] === (int)$p['id']) ? 'table-primary' : '' ?>">
                                        <td class="text-center text-muted fw-semibold small">
                                            <?= (int)$p['sort_order'] ?>
                                        </td>
                                        <td>
                                            <div class="fw-bold text-dark">
                                                <?= e($p['title']) ?>
                                            </div>
                                            <div class="small text-muted d-flex align-items-center gap-1">
                                                <code class="text-muted" style="font-size: 0.75rem;">/page/<?= e($p['slug']) ?></code>
                                                <a href="/page/<?= e($p['slug']) ?>" target="_blank" class="text-primary text-decoration-none" title="Open live page in new tab">
                                                    <i class="bi bi-box-arrow-up-right" style="font-size: 0.75rem;"></i>
                                                </a>
                                            </div>
                                        </td>
                                        <td>
                                            <?php if ((int)$p['show_in_footer'] === 1): ?>
                                                <span class="badge bg-primary-subtle text-primary border border-primary-subtle d-inline-flex align-items-center gap-1" style="font-size:0.7rem;">
                                                    <i class="bi bi-check-circle-fill"></i> In Footer
                                                </span>
                                            <?php else: ?>
                                                <span class="badge bg-light text-muted border d-inline-flex align-items-center gap-1" style="font-size:0.7rem;">
                                                    <i class="bi bi-dash-circle"></i> Hidden
                                                </span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if ($p['status'] === 'published'): ?>
                                                <span class="badge bg-success-subtle text-success border border-success-subtle" style="font-size:0.7rem;">Published</span>
                                            <?php else: ?>
                                                <span class="badge bg-secondary-subtle text-secondary border border-secondary-subtle" style="font-size:0.7rem;">Draft</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-end">
                                            <div class="btn-group btn-group-sm">
                                                <a href="/admin/pages?edit=<?= (int)$p['id'] ?>" class="btn btn-outline-primary" title="Edit Page">
                                                    <i class="bi bi-pencil"></i>
                                                </a>
                                                <button type="button" class="btn btn-outline-danger" title="Delete Page" data-bs-toggle="modal" data-bs-target="#deleteModal<?= (int)$p['id'] ?>">
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                            </div>

                                            <!-- Delete Confirmation Modal -->
                                            <div class="modal fade" id="deleteModal<?= (int)$p['id'] ?>" tabindex="-1" aria-hidden="true">
                                                <div class="modal-dialog modal-dialog-centered">
                                                    <div class="modal-content text-start">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title fw-bold text-danger"><i class="bi bi-exclamation-triangle me-2"></i>Delete Page</h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <p>Are you sure you want to permanently delete the page <strong>"<?= e($p['title']) ?>"</strong>?</p>
                                                            <p class="small text-muted mb-0">This will remove it from the directory and any footer links immediately.</p>
                                                        </div>
                                                        <div class="modal-footer bg-light">
                                                            <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>
                                                            <form action="/admin/pages" method="POST" class="d-inline">
                                                                <?= csrf_field() ?>
                                                                <input type="hidden" name="action" value="delete">
                                                                <input type="hidden" name="id" value="<?= (int)$p['id'] ?>">
                                                                <button type="submit" class="btn btn-danger btn-sm">Confirm Delete</button>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Right Column: Add / Edit Form -->
        <div class="col-lg-5" id="pageFormCard">
            <div class="card border shadow-xs sticky-top" style="top: 20px; z-index: 10;">
                <div class="card-header bg-white py-3 border-bottom d-flex justify-content-between align-items-center">
                    <h5 class="card-title fw-bold mb-0 text-dark">
                        <?php if ($editPage): ?>
                            <i class="bi bi-pencil-square text-primary me-2"></i>Edit Page #<?= (int)$editPage['id'] ?>
                        <?php else: ?>
                            <i class="bi bi-plus-circle-fill text-success me-2"></i>Create New Page
                        <?php endif; ?>
                    </h5>
                    <?php if ($editPage): ?>
                        <a href="/admin/pages" class="btn btn-outline-secondary btn-sm py-0 px-2" style="font-size:0.75rem;">New Page</a>
                    <?php endif; ?>
                </div>

                <div class="card-body p-4">
                    <form action="/admin/pages" method="POST" id="customPageForm">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="<?= $editPage ? 'update' : 'create' ?>">
                        <?php if ($editPage): ?>
                            <input type="hidden" name="id" value="<?= (int)$editPage['id'] ?>">
                        <?php endif; ?>

                        <!-- Title -->
                        <div class="mb-3">
                            <label for="pageTitleInput" class="form-label small fw-bold text-dark">Page Title <span class="text-danger">*</span></label>
                            <input type="text" name="title" id="pageTitleInput" class="form-control" placeholder="e.g. About Us, Privacy Policy, Community Standards" value="<?= e($editPage['title'] ?? '') ?>" required>
                        </div>

                        <!-- Slug -->
                        <div class="mb-3">
                            <label for="pageSlugInput" class="form-label small fw-bold text-dark">URL Slug</label>
                            <div class="input-group input-group-sm">
                                <span class="input-group-text bg-light text-muted">/page/</span>
                                <input type="text" name="slug" id="pageSlugInput" class="form-control font-monospace" placeholder="e.g. about-us" value="<?= e($editPage['slug'] ?? '') ?>">
                            </div>
                            <small class="text-muted" style="font-size:0.75rem;">Leave empty or type custom slug. Auto-generates from title.</small>
                        </div>

                        <!-- Meta Description -->
                        <div class="mb-3">
                            <label for="metaDescInput" class="form-label small fw-bold text-dark">Meta / Search Description</label>
                            <textarea name="meta_description" id="metaDescInput" class="form-control" rows="2" placeholder="Brief summary for search engines and social sharing..."><?= e($editPage['meta_description'] ?? '') ?></textarea>
                            <div class="d-flex justify-content-between text-muted mt-1" style="font-size:0.72rem;">
                                <span>Recommended: 120-160 characters</span>
                                <span id="metaDescCount">0 chars</span>
                            </div>
                        </div>

                        <!-- Content Formatting Toolbar & Textarea -->
                        <div class="mb-3">
                            <div class="d-flex justify-content-between align-items-center mb-1">
                                <label for="pageContentArea" class="form-label small fw-bold text-dark mb-0">Page Content <span class="text-danger">*</span></label>
                                <div class="btn-group btn-group-sm" role="group">
                                    <button type="button" class="btn btn-light btn-sm border py-0 px-2 active" id="btnEditTab">Editor</button>
                                    <button type="button" class="btn btn-light btn-sm border py-0 px-2" id="btnPreviewTab">Live Preview</button>
                                </div>
                            </div>

                            <!-- Formatting buttons -->
                            <div class="bg-light p-1 border border-bottom-0 rounded-top d-flex gap-1 flex-wrap" id="editorToolbar">
                                <button type="button" class="btn btn-white btn-sm border py-0 px-2 bg-white" title="Bold" onclick="insertTag('<strong>', '</strong>')"><b>B</b></button>
                                <button type="button" class="btn btn-white btn-sm border py-0 px-2 bg-white" title="Italic" onclick="insertTag('<em>', '</em>')"><i>I</i></button>
                                <button type="button" class="btn btn-white btn-sm border py-0 px-2 bg-white" title="Heading 3" onclick="insertTag('<h3>', '</h3>')">H3</button>
                                <button type="button" class="btn btn-white btn-sm border py-0 px-2 bg-white" title="Heading 4" onclick="insertTag('<h4>', '</h4>')">H4</button>
                                <button type="button" class="btn btn-white btn-sm border py-0 px-2 bg-white" title="Paragraph" onclick="insertTag('<p>', '</p>')">&para;</button>
                                <button type="button" class="btn btn-white btn-sm border py-0 px-2 bg-white" title="List Item" onclick="insertTag('<ul>\n  <li>', '</li>\n</ul>')"><i class="bi bi-list-ul"></i></button>
                                <button type="button" class="btn btn-white btn-sm border py-0 px-2 bg-white" title="Link" onclick="insertTag('<a href=\x22#\x22>', '</a>')"><i class="bi bi-link-45deg"></i></button>
                                <button type="button" class="btn btn-white btn-sm border py-0 px-2 bg-white" title="Blockquote" onclick="insertTag('<blockquote class=\x22blockquote\x22><p>', '</p></blockquote>')"><i class="bi bi-quote"></i></button>
                            </div>

                            <textarea name="content" id="pageContentArea" class="form-control rounded-top-0 font-monospace" rows="10" placeholder="Write page content here (HTML or plain text supported)..." required style="font-size:0.85rem;"><?= e($editPage['content'] ?? '') ?></textarea>

                            <div id="pagePreviewArea" class="p-3 border rounded-top-0 bg-white d-none overflow-auto" style="min-height: 230px; max-height: 380px;">
                                <!-- Live render container -->
                            </div>
                        </div>

                        <!-- Settings: Status, Show In Footer, Sort Order -->
                        <div class="row g-2 mb-4 p-3 bg-light rounded border">
                            <div class="col-sm-6">
                                <label for="statusSelect" class="form-label small fw-bold text-dark">Publishing Status</label>
                                <select name="status" id="statusSelect" class="form-select form-select-sm">
                                    <option value="published" <?= (($editPage['status'] ?? 'published') === 'published' ? 'selected' : '') ?>>Published (Live)</option>
                                    <option value="draft" <?= (($editPage['status'] ?? '') === 'draft' ? 'selected' : '') ?>>Draft (Admin only)</option>
                                </select>
                            </div>

                            <div class="col-sm-6">
                                <label for="sortOrderInput" class="form-label small fw-bold text-dark">Sort Order</label>
                                <input type="number" name="sort_order" id="sortOrderInput" class="form-control form-control-sm" value="<?= (int)($editPage['sort_order'] ?? 0) ?>" min="0" max="999">
                                <small class="text-muted" style="font-size:0.7rem;">Lower numbers appear first</small>
                            </div>

                            <div class="col-12 mt-2">
                                <div class="form-check form-switch">
                                    <input class="form-check-input" type="checkbox" name="show_in_footer" value="1" id="showInFooterCheck" <?= (!isset($editPage) || (int)($editPage['show_in_footer'] ?? 1) === 1 ? 'checked' : '') ?>>
                                    <label class="form-check-label small fw-semibold text-dark" for="showInFooterCheck">
                                        <i class="bi bi-layout-text-window-reverse text-primary me-1"></i>Display link in Website Footer
                                    </label>
                                    <div class="text-muted" style="font-size:0.75rem;">When enabled, this page is listed under the "Pages / Quick Links" column in the footer.</div>
                                </div>
                            </div>
                        </div>

                        <!-- Submit Button -->
                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-primary flex-grow-1">
                                <i class="bi bi-check-lg me-1"></i>
                                <?= $editPage ? 'Save Changes' : 'Publish Page' ?>
                            </button>
                            <?php if ($editPage): ?>
                                <a href="/admin/pages" class="btn btn-outline-secondary">Cancel</a>
                            <?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const titleInput = document.getElementById('pageTitleInput');
    const slugInput = document.getElementById('pageSlugInput');
    const metaInput = document.getElementById('metaDescInput');
    const metaCount = document.getElementById('metaDescCount');
    const contentArea = document.getElementById('pageContentArea');
    const previewArea = document.getElementById('pagePreviewArea');
    const btnEditTab = document.getElementById('btnEditTab');
    const btnPreviewTab = document.getElementById('btnPreviewTab');
    const editorToolbar = document.getElementById('editorToolbar');

    // Auto slug generation if user hasn't explicitly customized slug
    let userEditedSlug = <?= !empty($editPage['slug']) ? 'true' : 'false' ?>;
    slugInput.addEventListener('input', function() {
        userEditedSlug = slugInput.value.trim() !== '';
    });

    titleInput.addEventListener('input', function() {
        if (!userEditedSlug) {
            slugInput.value = titleInput.value
                .toLowerCase()
                .trim()
                .replace(/[^\w\s-]/g, '')
                .replace(/[\s_-]+/g, '-')
                .replace(/^-+|-+$/g, '');
        }
    });

    // Character counter for meta description
    function updateMetaCount() {
        const len = metaInput.value.length;
        metaCount.textContent = len + ' chars';
        if (len > 160) {
            metaCount.classList.add('text-danger');
            metaCount.classList.remove('text-muted');
        } else {
            metaCount.classList.remove('text-danger');
            metaCount.classList.add('text-muted');
        }
    }
    metaInput.addEventListener('input', updateMetaCount);
    updateMetaCount();

    // Editor vs Preview Tabs
    btnPreviewTab.addEventListener('click', function() {
        btnPreviewTab.classList.add('active', 'btn-primary');
        btnPreviewTab.classList.remove('btn-light');
        btnEditTab.classList.remove('active', 'btn-primary');
        btnEditTab.classList.add('btn-light');

        editorToolbar.classList.add('d-none');
        contentArea.classList.add('d-none');
        previewArea.classList.remove('d-none');

        // Render preview
        previewArea.innerHTML = contentArea.value || '<p class="text-muted fst-italic">No content entered yet.</p>';
    });

    btnEditTab.addEventListener('click', function() {
        btnEditTab.classList.add('active', 'btn-primary');
        btnEditTab.classList.remove('btn-light');
        btnPreviewTab.classList.remove('active', 'btn-primary');
        btnPreviewTab.classList.add('btn-light');

        editorToolbar.classList.remove('d-none');
        contentArea.classList.remove('d-none');
        previewArea.classList.add('d-none');
    });
});

function insertTag(openTag, closeTag) {
    const textarea = document.getElementById('pageContentArea');
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const text = textarea.value;
    const selected = text.substring(start, end);
    const replacement = openTag + (selected || 'Sample Text') + closeTag;

    textarea.value = text.substring(0, start) + replacement + text.substring(end);
    textarea.focus();
    textarea.setSelectionRange(start + openTag.length, start + openTag.length + (selected ? selected.length : 11));
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
