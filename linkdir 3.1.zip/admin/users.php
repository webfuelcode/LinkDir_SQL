<?php
/**
 * linkdir - Admin User Management
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';

auth_require_admin();
$db = get_db();

// Search & filter
$search = trim($_GET['q'] ?? '');
$role = trim($_GET['role'] ?? '');
$status = trim($_GET['status'] ?? '');
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 25;
$offset = ($page - 1) * $perPage;

$where = ["1=1"];
$params = [];

if ($search !== '') {
    $where[] = "(name LIKE ? OR email LIKE ?)";
    $term = '%' . $search . '%';
    $params[] = $term;
    $params[] = $term;
}

if ($role !== '' && in_array($role, ['admin', 'user'])) {
    $where[] = "role = ?";
    $params[] = $role;
}

if ($status !== '' && in_array($status, ['active', 'suspended'])) {
    $where[] = "status = ?";
    $params[] = $status;
}

$whereClause = implode(' AND ', $where);

// Count
$countStmt = $db->prepare("SELECT COUNT(*) FROM users WHERE {$whereClause}");
$countStmt->execute($params);
$totalItems = (int)$countStmt->fetchColumn();
$totalPages = ceil($totalItems / $perPage);

// Fetch users with business and review counts
$sql = "
    SELECT u.*,
           COUNT(DISTINCT b.id) as business_count,
           COUNT(DISTINCT r.id) as review_count
    FROM users u
    LEFT JOIN businesses b ON b.user_id = u.id
    LEFT JOIN reviews r ON r.user_id = u.id
    WHERE {$whereClause}
    GROUP BY u.id
    ORDER BY u.created_at DESC
    LIMIT {$perPage} OFFSET {$offset}
";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$users = $stmt->fetchAll();

$currentUserId = auth_id();
$currentLimit = get_user_listing_limit();

$pageTitle = 'Manage Users - Admin';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/includes/admin-nav.php';
?>

<div class="container mb-5">
    <?= flash_render() ?>

    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-2 mb-3">
        <h2 class="h4 fw-bold mb-0">Registered Users (<?= number_format($totalItems) ?>)</h2>
        <div class="d-flex gap-2 align-items-center">
            <span class="badge bg-light text-dark border p-2 d-inline-flex align-items-center gap-1">
                <i class="bi bi-speedometer2 text-primary"></i>
                <span>Entry Limit: <strong><?= get_user_listing_limit() === 0 ? 'Unlimited' : get_user_listing_limit() . ' listings / user' ?></strong></span>
            </span>
            <a href="/admin/settings" class="btn btn-outline-primary btn-sm d-inline-flex align-items-center gap-1">
                <i class="bi bi-sliders"></i>
                <span>Adjust Limit</span>
            </a>
        </div>
    </div>

    <!-- Filter Card -->
    <div class="card shadow-sm border-1 p-3 mb-4 bg-light">
        <form action="/admin/users" method="GET" class="row g-2 align-items-end">
            <div class="col-md-5">
                <label class="form-label small fw-semibold text-muted mb-1">Search by Name or Email</label>
                <input type="text" name="q" class="form-control form-control-sm" placeholder="User name or email..." value="<?= e($search) ?>">
            </div>

            <div class="col-md-3">
                <label class="form-label small fw-semibold text-muted mb-1">Role</label>
                <select name="role" class="form-select form-select-sm">
                    <option value="">All Roles</option>
                    <option value="admin" <?= ($role === 'admin' ? 'selected' : '') ?>>Administrator</option>
                    <option value="user" <?= ($role === 'user' ? 'selected' : '') ?>>Standard User</option>
                </select>
            </div>

            <div class="col-md-2">
                <label class="form-label small fw-semibold text-muted mb-1">Status</label>
                <select name="status" class="form-select form-select-sm">
                    <option value="">All Statuses</option>
                    <option value="active" <?= ($status === 'active' ? 'selected' : '') ?>>Active</option>
                    <option value="suspended" <?= ($status === 'suspended' ? 'selected' : '') ?>>Suspended</option>
                </select>
            </div>

            <div class="col-md-2 d-flex gap-1">
                <button type="submit" class="btn btn-primary btn-sm flex-grow-1">Filter</button>
                <a href="/admin/users" class="btn btn-outline-secondary btn-sm">Reset</a>
            </div>
        </form>
    </div>

    <!-- Users Table -->
    <div class="card shadow-sm border-1">
        <div class="card-body p-0">
            <?php if (!empty($users)): ?>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light small">
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Role</th>
                                <th>Status</th>
                                <th>Listings</th>
                                <th>Reviews</th>
                                <th>Joined</th>
                                <th class="text-end">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($users as $u): ?>
                                <tr>
                                    <td>
                                        <strong><?= e($u['name']) ?></strong>
                                        <?php if ($u['id'] == $currentUserId): ?>
                                            <span class="badge bg-secondary ms-1 small">You</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="small text-muted font-monospace">
                                        <?= e($u['email']) ?>
                                    </td>
                                    <td>
                                        <?php if ($u['role'] === 'admin'): ?>
                                            <span class="badge bg-danger">Admin</span>
                                        <?php else: ?>
                                            <span class="badge bg-secondary">User</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if ($u['status'] === 'active'): ?>
                                            <span class="badge badge-status-approved">Active</span>
                                        <?php else: ?>
                                            <span class="badge badge-status-suspended">Suspended</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="small">
                                        <?php if ($u['role'] === 'admin'): ?>
                                            <span class="badge bg-light text-secondary border">
                                                <i class="bi bi-infinity me-1"></i><?= (int)$u['business_count'] ?>
                                            </span>
                                        <?php elseif ($currentLimit === 0): ?>
                                            <span class="fw-semibold"><?= (int)$u['business_count'] ?></span>
                                            <span class="text-muted small">(&infin;)</span>
                                        <?php elseif ((int)$u['business_count'] >= $currentLimit): ?>
                                            <span class="badge bg-warning-subtle text-warning-emphasis border border-warning" title="User has reached maximum allowed listing limit">
                                                <?= (int)$u['business_count'] ?> / <?= $currentLimit ?> (Max)
                                            </span>
                                        <?php else: ?>
                                            <span class="fw-semibold text-dark"><?= (int)$u['business_count'] ?></span>
                                            <span class="text-muted small">/ <?= $currentLimit ?></span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="small">
                                        <?= (int)$u['review_count'] ?>
                                    </td>
                                    <td class="small text-muted">
                                        <?= format_date($u['created_at']) ?>
                                    </td>
                                    <td class="text-end">
                                        <?php if ($u['id'] != $currentUserId): ?>
                                            <div class="btn-group btn-group-sm">
                                                <!-- Toggle Role -->
                                                <form action="/admin/actions.php" method="POST" class="d-inline">
                                                    <?= csrf_field() ?>
                                                    <input type="hidden" name="action" value="user_toggle_role">
                                                    <input type="hidden" name="id" value="<?= (int)$u['id'] ?>">
                                                    <input type="hidden" name="role" value="<?= ($u['role'] === 'admin' ? 'user' : 'admin') ?>">
                                                    <button type="submit" class="btn btn-outline-secondary" title="<?= ($u['role'] === 'admin' ? 'Demote to User' : 'Promote to Admin') ?>">
                                                        <i class="bi <?= ($u['role'] === 'admin' ? 'bi-person-down' : 'bi-shield-check') ?>"></i>
                                                    </button>
                                                </form>

                                                <!-- Toggle Status -->
                                                <form action="/admin/actions.php" method="POST" class="d-inline ms-1">
                                                    <?= csrf_field() ?>
                                                    <input type="hidden" name="action" value="user_toggle_status">
                                                    <input type="hidden" name="id" value="<?= (int)$u['id'] ?>">
                                                    <input type="hidden" name="status" value="<?= ($u['status'] === 'active' ? 'suspended' : 'active') ?>">
                                                    <button type="submit" class="btn <?= ($u['status'] === 'active' ? 'btn-outline-warning' : 'btn-outline-success') ?>" title="<?= ($u['status'] === 'active' ? 'Suspend Account' : 'Activate Account') ?>">
                                                        <i class="bi <?= ($u['status'] === 'active' ? 'bi-slash-circle' : 'bi-check-circle') ?>"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        <?php else: ?>
                                            <span class="text-muted small">—</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <?php if ($totalPages > 1): ?>
                    <div class="card-footer bg-white py-3">
                        <ul class="pagination justify-content-center mb-0">
                            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                                <li class="page-item <?= ($page == $i ? 'active' : '') ?>">
                                    <a class="page-link" href="/admin/users?page=<?= $i ?>&status=<?= urlencode($status) ?>&role=<?= urlencode($role) ?>&q=<?= urlencode($search) ?>">
                                        <?= $i ?>
                                    </a>
                                </li>
                            <?php endfor; ?>
                        </ul>
                    </div>
                <?php endif; ?>
            <?php else: ?>
                <div class="p-5 text-center text-muted">
                    <p class="mb-0">No users found matching your search.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
