<?php
/**
 * linkdir - Admin Pages Index Route Forwarder
 */
require_once __DIR__ . '/../pages.php';
