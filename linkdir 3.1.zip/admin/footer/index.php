<?php
/**
 * linkdir - Admin Footer Settings Index Forwarder
 */
require_once __DIR__ . '/../footer.php';
