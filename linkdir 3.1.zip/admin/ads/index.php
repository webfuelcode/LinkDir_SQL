<?php
/**
 * linkdir - Directory wrapper for Admin Ads & Banners management
 * Ensures compatibility across Apache servers with or without mod_rewrite.
 */
require_once __DIR__ . '/../ads.php';
