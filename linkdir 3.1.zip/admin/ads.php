<?php
/**
 * linkdir - Admin Ad Placements & Banners Management
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';

auth_require_admin();
$db = get_db();

$errors = [];
$success = '';

// Handle Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_require();

    $action = trim($_POST['action'] ?? 'update');

    if ($action === 'update') {
        $slotKey = trim($_POST['slot_key'] ?? '');
        $title = trim($_POST['title'] ?? '');
        $type = in_array($_POST['type'] ?? 'image', ['image', 'script']) ? $_POST['type'] : 'image';
        $status = in_array($_POST['status'] ?? 'active', ['active', 'disabled']) ? $_POST['status'] : 'active';
        $imageUrl = trim($_POST['image_url'] ?? '');
        $linkUrl = trim($_POST['link_url'] ?? '');
        $scriptCode = trim($_POST['script_code'] ?? '');

        if ($slotKey === '') {
            $errors[] = 'Slot key is required.';
        }
        if ($title === '') {
            $errors[] = 'Ad title/label is required.';
        }

        if (empty($errors)) {
            // Check if slot exists
            $checkStmt = $db->prepare("SELECT id FROM ads WHERE slot_key = ? LIMIT 1");
            $checkStmt->execute([$slotKey]);
            $existing = $checkStmt->fetch();

            if ($existing) {
                $stmt = $db->prepare("
                    UPDATE ads 
                    SET title = ?, type = ?, image_url = ?, link_url = ?, script_code = ?, status = ?, updated_at = CURRENT_TIMESTAMP
                    WHERE slot_key = ?
                ");
                $stmt->execute([$title, $type, $imageUrl, $linkUrl, $scriptCode, $status, $slotKey]);
            } else {
                $stmt = $db->prepare("
                    INSERT INTO ads (slot_key, title, type, image_url, link_url, script_code, status, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                ");
                $stmt->execute([$slotKey, $title, $type, $imageUrl, $linkUrl, $scriptCode, $status]);
            }

            flash_set('success', 'Ad placement "' . htmlspecialchars($title) . '" has been updated successfully.');
            header('Location: /admin/ads');
            exit;
        }
    }
}

// Fetch all ad slots
$adStmt = $db->query("SELECT * FROM ads ORDER BY id ASC");
$ads = $adStmt->fetchAll();

// If table is empty for any reason, re-bootstrap
if (empty($ads)) {
    $seedAds = [
        ['leaderboard_top', 'Directory Top Leaderboard (728x90)', 'image', 'https://placehold.co/728x90/e2e8f0/334155?text=Advertise+Here+-+Premium+Leaderboard+Banner+(728x90)', '#', '', 'active'],
        ['sidebar_directory', 'Directory Sidebar Ad (300x250)', 'image', 'https://placehold.co/300x250/e2e8f0/334155?text=Feature+Your+Business+Here+(300x250)', '#', '', 'active'],
        ['sidebar_business', 'Business Detail Sidebar Ad (300x250)', 'image', 'https://placehold.co/300x250/e2e8f0/334155?text=Partner+Promotion+Banner+(300x250)', '#', '', 'active'],
        ['leaderboard_business', 'Business Detail Bottom Leaderboard (728x90)', 'image', 'https://placehold.co/728x90/e2e8f0/334155?text=Sponsor+Placement+Area+(728x90)', '#', '', 'active']
    ];
    $ins = $db->prepare("INSERT INTO ads (slot_key, title, type, image_url, link_url, script_code, status) VALUES (?, ?, ?, ?, ?, ?, ?)");
    foreach ($seedAds as $sa) {
        $ins->execute($sa);
    }
    $adStmt = $db->query("SELECT * FROM ads ORDER BY id ASC");
    $ads = $adStmt->fetchAll();
}

$pageTitle = 'Ad Placements & Banners - Admin';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/includes/admin-nav.php';
?>

<div class="container py-4 mb-5">
    <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
        <div>
            <h1 class="h3 fw-bold text-dark mb-1">Ad Placement Areas</h1>
            <p class="text-muted small mb-0">Configure leaderboard banners and sidebar advertisements with image links or custom ad scripts.</p>
        </div>
        <div>
            <a href="/businesses" target="_blank" class="btn btn-outline-primary btn-sm">
                <i class="bi bi-box-arrow-up-right me-1"></i>View Live Directory
            </a>
        </div>
    </div>

    <?= flash_render() ?>

    <?php if (!empty($errors)): ?>
        <div class="alert alert-danger mb-4">
            <ul class="mb-0 small">
                <?php foreach ($errors as $err): ?>
                    <li><?= e($err) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <div class="row g-4">
        <?php foreach ($ads as $ad): ?>
            <?php 
                $isLeaderboard = str_contains($ad['slot_key'], 'leaderboard');
                $recommendedSize = $isLeaderboard ? '728x90 (Horizontal Banner)' : '300x250 (Medium Rectangle)';
            ?>
            <div class="col-12 <?= $isLeaderboard ? 'col-xl-12' : 'col-xl-6' ?>">
                <div class="card shadow-sm border-1 h-100">
                    <div class="card-header bg-white py-3 border-bottom d-flex justify-content-between align-items-center flex-wrap gap-2">
                        <div>
                            <span class="badge <?= $ad['status'] === 'active' ? 'bg-success-subtle text-success border border-success-subtle' : 'bg-secondary-subtle text-secondary border' ?> me-2">
                                <?= ucfirst(e($ad['status'])) ?>
                            </span>
                            <strong class="text-dark fs-6"><?= e($ad['title']) ?></strong>
                            <span class="badge bg-light text-muted border ms-1 font-monospace small">slot: <?= e($ad['slot_key']) ?></span>
                        </div>
                        <span class="text-muted small"><i class="bi bi-aspect-ratio me-1"></i>Size: <?= $recommendedSize ?></span>
                    </div>

                    <div class="card-body p-4">
                        <!-- Live Preview Box -->
                        <div class="mb-4">
                            <label class="form-label small fw-bold text-muted text-uppercase mb-2">Live Preview in Slot</label>
                            <div class="p-3 bg-light rounded border text-center" style="min-height: 110px; display: flex; align-items: center; justify-content: center;">
                                <?php if ($ad['status'] !== 'active'): ?>
                                    <div class="text-muted fst-italic small">
                                        <i class="bi bi-eye-slash me-1"></i>This ad slot is currently <strong>disabled</strong> (will not render to public visitors).
                                    </div>
                                <?php elseif ($ad['type'] === 'script' && !empty($ad['script_code'])): ?>
                                    <div class="w-100 overflow-hidden">
                                        <span class="badge bg-dark mb-2">Script / HTML Embed</span>
                                        <div class="small text-secondary bg-white p-2 border rounded font-monospace text-start overflow-auto" style="max-height: 90px;">
                                            <?= htmlspecialchars($ad['script_code']) ?>
                                        </div>
                                    </div>
                                <?php elseif (!empty($ad['image_url'])): ?>
                                    <a href="<?= e($ad['link_url'] ?: '#') ?>" target="_blank" rel="noopener noreferrer nofollow" class="d-inline-block">
                                        <img src="<?= e($ad['image_url']) ?>" alt="<?= e($ad['title']) ?>" class="img-fluid rounded shadow-xs" style="max-height: 120px; object-fit: contain;" onerror="this.onerror=null; this.src='https://placehold.co/400x100?text=Invalid+Image+URL';">
                                    </a>
                                <?php else: ?>
                                    <div class="text-muted small">No image or script configured for this slot yet.</div>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- Edit Form -->
                        <form method="POST" action="/admin/ads">
                            <?= csrf_field() ?>
                            <input type="hidden" name="action" value="update">
                            <input type="hidden" name="slot_key" value="<?= e($ad['slot_key']) ?>">

                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label small fw-semibold text-muted">Slot Label / Title *</label>
                                    <input type="text" name="title" class="form-control form-control-sm" value="<?= e($ad['title']) ?>" required>
                                </div>

                                <div class="col-md-3">
                                    <label class="form-label small fw-semibold text-muted">Ad Type *</label>
                                    <select name="type" class="form-select form-select-sm" id="type-select-<?= e($ad['id']) ?>" onchange="toggleAdTypeFields(<?= (int)$ad['id'] ?>)">
                                        <option value="image" <?= $ad['type'] === 'image' ? 'selected' : '' ?>>Image Banner (Link)</option>
                                        <option value="script" <?= $ad['type'] === 'script' ? 'selected' : '' ?>>Custom Script / HTML</option>
                                    </select>
                                </div>

                                <div class="col-md-3">
                                    <label class="form-label small fw-semibold text-muted">Slot Status *</label>
                                    <select name="status" class="form-select form-select-sm">
                                        <option value="active" <?= $ad['status'] === 'active' ? 'selected' : '' ?>>Active (Visible)</option>
                                        <option value="disabled" <?= $ad['status'] === 'disabled' ? 'selected' : '' ?>>Disabled (Hidden)</option>
                                    </select>
                                </div>

                                <!-- Image Type Fields -->
                                <div class="col-12 ad-field-image-<?= e($ad['id']) ?>" style="<?= $ad['type'] === 'script' ? 'display:none;' : '' ?>">
                                    <div class="row g-3">
                                        <div class="col-md-7">
                                            <label class="form-label small fw-semibold text-muted">Banner Image URL</label>
                                            <input type="url" name="image_url" class="form-control form-control-sm" value="<?= e($ad['image_url'] ?? '') ?>" placeholder="https://example.com/banner.jpg or /uploads/...">
                                            <div class="form-text small">Recommended dimensions: <?= $recommendedSize ?></div>
                                        </div>
                                        <div class="col-md-5">
                                            <label class="form-label small fw-semibold text-muted">Destination Link URL</label>
                                            <input type="url" name="link_url" class="form-control form-control-sm" value="<?= e($ad['link_url'] ?? '') ?>" placeholder="https://partner-website.com">
                                        </div>
                                    </div>
                                </div>

                                <!-- Script Type Fields -->
                                <div class="col-12 ad-field-script-<?= e($ad['id']) ?>" style="<?= $ad['type'] === 'image' ? 'display:none;' : '' ?>">
                                    <label class="form-label small fw-semibold text-muted">Custom Script / AdSense / Embed HTML</label>
                                    <textarea name="script_code" class="form-control form-control-sm font-monospace" rows="4" placeholder="<script async src='https://pagead2.googlesyndication.com/...'></script>"><?= htmlspecialchars($ad['script_code'] ?? '') ?></textarea>
                                    <div class="form-text small">Paste your ad network snippet, Google AdSense tag, or raw tracking embed.</div>
                                </div>

                                <div class="col-12 text-end pt-2">
                                    <button type="submit" class="btn btn-primary btn-sm px-4">
                                        <i class="bi bi-check2-circle me-1"></i>Save Placement
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<script>
function toggleAdTypeFields(adId) {
    const typeSelect = document.getElementById('type-select-' + adId);
    if (!typeSelect) return;
    const isScript = typeSelect.value === 'script';
    
    const imgFields = document.querySelector('.ad-field-image-' + adId);
    const scriptFields = document.querySelector('.ad-field-script-' + adId);
    
    if (imgFields) imgFields.style.display = isScript ? 'none' : 'block';
    if (scriptFields) scriptFields.style.display = isScript ? 'block' : 'none';
}
</script>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
