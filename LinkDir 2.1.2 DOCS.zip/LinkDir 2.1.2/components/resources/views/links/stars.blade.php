@extends('layouts.app')

@section('linkrel')
    <link rel="stylesheet" href="{{asset('css/star-comment.css')}}">
@endsection
@section('content')
    <div class="container">
        <form action="{{route('comment.update', $comment->id)}}" method="POST">
            @csrf
            @method('PUT')
                  <div class="modal-body form-group">
                    
                    <div class="star-edit">
                        @for ($i = 5; $i > 0; $i--)
                            @if ($i > $comment->stars)
                              <input type="radio" name="stars" id="r-{{$i}}" value="{{$i}}">
                              <label for="r-{{$i}}" class="fa fa-star">{{$i}}</label>
                              {{-- <input type="radio" name="" id="r-{{$i}}"> --}}
                            @else
                              <input type="radio" name="stars" id="r{{$i}}" value="{{$i}}" @if ($i == $comment->stars)
                                  checked
                              @endif>
                              <label for="r-{{$i}}" class="fa fa-star">{{$i}}</label>
                              {{-- <input type="radio" name="" id="r-{{$i}}"> --}}
                            @endif
                        @endfor
                      
                      
                        <header></header>
                        <input type="hidden" name="link_id" value="">
                        <textarea name="body" id="" cols="30" rows="10" class="form-control">{{$comment->body}}</textarea>
                    </div>
                  </div>
          </form>                              
                  
          {{-- </form> --}}
    </div>
@endsection