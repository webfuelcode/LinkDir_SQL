<?php $__env->startSection('title', 'Welcome home'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="card border-0 w-100 p-5">
            <div class="row">
                <div class="col-md-5 my-auto">
                    <p><?php echo e($admin->sitemsg); ?></p>
                    <?php echo $__env->make('layouts.searchform', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="col-md-7">
                    <img class="img-fluid" src="/images/linkdir/linkdir.png" alt="LinkDir">
                </div>
            </div>
        </div>
    </div>
    
        <div class="text-center bg-light py-2">
            <?php echo $admin->leaderads; ?>

        </div>

    <div class="container">
        <div class="text-center mt-2">
            <h4>Categories</h4>
            <hr>
            <p class="text-muted">Go through the categories to find amazing products and services.</p>
        </div>
        <div class="row">
            <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-sm-6 col-md-6 col-lg-3">
                    <div class="card bg-dark text-white text-center my-2">
                        
                        <div class="card-body">
                            <div><?php echo e($category->name); ?> (<?php echo e($category->links()->count()); ?>)</div>
                            <div class="my-1">
                                <a class="btn btn-dark" href="<?php echo e(route('category.show', $category->name)); ?>">Visit</a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="col-md-12 bg-warning py-2 text-center text-light rounded">There are no categories yet !</p>
            <?php endif; ?>
        </div>

        <div class="row">
            <?php $__empty_1 = true; $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-md-6">
                    <?php echo $__env->make('partials.item_list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppi\htdocs\LinkDir\resources\views/welcome.blade.php ENDPATH**/ ?>