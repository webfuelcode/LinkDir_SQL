<form class="form-inline my-2 my-lg-0" action="/search" method="GET" role="search">
    <div class="input-group">
        <input type="text" class="form-control mr-md-2" name="q"
            placeholder="Search directory...">
            <div class="input-group-append">
                <button type="submit" class="btn btn-warning my-2 my-sm-0">
                    Search
                </button>
            </div>
    </div>
</form><?php /**PATH C:\xamppi\htdocs\LinkDir\resources\views/layouts/searchform.blade.php ENDPATH**/ ?>