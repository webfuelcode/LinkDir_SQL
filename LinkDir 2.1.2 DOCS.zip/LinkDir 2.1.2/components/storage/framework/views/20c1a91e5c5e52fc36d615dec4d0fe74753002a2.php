

<?php $__env->startSection('title', 'Category Management'); ?>
<?php $__env->startSection('head', 'Category Management'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo $__env->make('partials.msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('partials.errormsg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row">
            <div class="col-md-9">
                <h2>Categories</h2>
                <table class="table table-hover">
                    <thead class="bg-warning">
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->index + 1); ?></td>
                            <td><a href="<?php echo e(route('category.show', $category->name)); ?>"><?php echo e($category->name); ?></a></td>
                            <td>
                                <!-- Edit & delete button -->
                                <div class="float-left">
                                    <button type="button" class="btn btn-success" data-toggle="modal" data-target="#modal<?php echo e($category->id); ?>">
                                        Edit
                                    </button>

                                    <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#delete<?php echo e($category->id); ?>">
                                        Delete
                                    </button>
                                </div>
                                <?php echo $__env->make('admin.partials.edit_category', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php echo $__env->make('admin.partials.delete_category', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                
            </div>
            
            <div class="col-md-3">
                <form action="<?php echo e(route('category.store')); ?>" method="POST" class="card bg-danger text-white p-2">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                      <label for="name">Category name</label>
                      <input type="text" name="name" class="form-control" placeholder="Enter new category">
                    </div>
                    <button type="submit" class="btn btn-outline-light btn-lg btn-block">Submit</button>
                </form>
                
                <div class="card my-3">
                    <div class="card-header">
                        Cheap hosting
                    </div>
                    <div class="card-body">
                        <p>Shared hosting under $3/m. Or get VPS/Dedicated server for large projects.</p>
                        <a class="btn btn-success btn-block" href="https://www.wall-spot.com/web-hosting-starters/" target="_blank" rel="noopener noreferrer">Hit here</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.adminmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xamppi\htdocs\LinkDir\resources\views/admin/create_category.blade.php ENDPATH**/ ?>