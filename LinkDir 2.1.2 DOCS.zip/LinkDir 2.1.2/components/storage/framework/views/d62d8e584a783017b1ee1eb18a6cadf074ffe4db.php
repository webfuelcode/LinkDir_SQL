<!-- Modal for edit -->
<div class="modal fade" id="modal<?php echo e($link->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Edit link</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            
            
                <form action="<?php echo e(route('upsite', $link->slug)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="category_id">Site title:</label>
                            <input type="text" class="form-control" name="title" value="<?php echo e($link->title); ?>">
                            <small>Character required is min. 5 and max. 150</small>                        
                        </div>
                        <div class="form-group">
                            <label for="category_id">Site URL:</label>
                            <input type="text" class="form-control" name="url" value="<?php echo e($link->url); ?>">
                            <small>Character required is max. 50</small> 
                        </div>
                        <div class="form-group">
                            <label for="category_id">Category:</label>
                            <select name="category_id" class="custom-select">
                              <option selected="">Select a category</option>
                              <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>" <?php echo e($category->id === $link->category_id ? ' selected' : ''); ?>><?php echo e($category->name); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                      
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="category_id">Description:</label>
                            <textarea class="form-control" name="description"><?php echo e($link->description); ?></textarea>
                            <small>Character required is min. 20</small> 
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save changes</button>
                    </div>                              
                    
                </form>
            
            
        </div>
    </div>
</div><?php /**PATH C:\xamppi\htdocs\LinkDir\resources\views/admin/partials/edit_site.blade.php ENDPATH**/ ?>