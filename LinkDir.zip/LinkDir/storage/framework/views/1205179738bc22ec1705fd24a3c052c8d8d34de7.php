<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="title_left">
        <h3>Fixed Footer <small> Just add class <strong>footer_fixed</strong></small></h3>
        <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php echo e($category->name); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            There is no category yet.
        <?php endif; ?>
      </div>
    </div>
  </div>
</div><?php /**PATH C:\xampp\htdocs\LinkDir\resources\views\admin\layouts\home.blade.php ENDPATH**/ ?>