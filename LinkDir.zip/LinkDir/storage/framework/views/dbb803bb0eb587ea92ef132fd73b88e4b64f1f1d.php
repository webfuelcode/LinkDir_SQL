<?php $__env->startComponent('mail::message'); ?>
# Welcome

We are glad to have you here.

Now you are a proud member of <?php echo e(config('app.name')); ?>. Visit the site and start posting. Hope you will get advantages from our side.

For any help, please visit the pages.

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\LinkDir\resources\views/emails/welcome.blade.php ENDPATH**/ ?>