<?php $__env->startSection('title', 'Member dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <?php echo $__env->make('partials.msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>
<?php echo e($admin->sidead); ?>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    
                    <p class="card-text">
                        <strong><?php echo e(Auth::user()->name); ?></strong> <?php echo e(__('Welcome to the dashboard!')); ?>

                    </p>

                </div>
            </div>

            <div class="card my-2">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h4>
                        <?php echo e(__('Posts count')); ?>

                    </h4>

                    <h6 class="card-subtitle text-muted">
                        <?php if( Auth::user()->links()->count() < 5): ?>
                            You have <?php echo e(Auth::user()->links->count()); ?>/5 sites.
                        <?php else: ?>
                            Ohh! All fives are filled.
                        <?php endif; ?>
                    </h6>
                </div>

                <div class="">
                    <ul class="list-group list-group-flush">
                        <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item d-flex justify-content-between">
                                <div>
                                    <?php echo e($link->title); ?>

                                </div>
                                <div>
                                    <small class="mr-2">
                                        Category - <?php echo e($link->category->name); ?>

                                    </small>
                                    <a href="<?php echo e(route('link.show', $link->id)); ?>" class="btn btn-warning btn-sm">
                                        See
                                    </a>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                        
                    </ul>
                </div>                
            </div>
            <?php echo e($links->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LinkDir\resources\views/home.blade.php ENDPATH**/ ?>