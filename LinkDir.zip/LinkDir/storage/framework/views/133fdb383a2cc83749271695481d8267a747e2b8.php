<?php if(session('message')): ?>
    <div class="alert alert-success">
        <?php echo e(session('message')); ?>

    </div>        
<?php endif; ?>

<script>
    window.setTimeout(function() {
    $(".alert-success").fadeTo(500, 0).slideUp(500, function(){
        $(this).remove(); 
    });
}, 5000);
</script><?php /**PATH C:\xampp\htdocs\LinkDir\resources\views\partials\msg.blade.php ENDPATH**/ ?>