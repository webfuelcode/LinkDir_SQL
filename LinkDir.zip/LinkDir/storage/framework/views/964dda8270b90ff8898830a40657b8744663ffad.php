<!-- Modal for edit -->
<div class="modal fade" id="modal<?php echo e($user->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Site records of <span class="text-success"><em><?php echo e($user->name); ?></em></span></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            
            <div class="modal-body form-group">
                <table class="table table-hover">
                    <thead class="bg-warning">
                        <tr>
                            <th>#</th>
                            <th>Site Title</th>
                            <th>Category</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $user->links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php echo e($loop->index + 1); ?>

                                </td>
                                <td>
                                    <?php echo e($link->title); ?>

                                </td>
                                <td>
                                    <?php echo e($link->category->name); ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                        
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-success" data-dismiss="modal">Okay!</button>
            </div>
            
            
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\LinkDir\resources\views\admin\partials\see_user.blade.php ENDPATH**/ ?>