

<?php $__env->startSection('title', 'Categories'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <h2 class="pb-2">
                    Categories
                </h2>
                
                <ul class="list-group">
                    <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            
                        <a class="list-group-item d-flex justify-content-between align-item-center" href="<?php echo e(route('category.show', $category->name)); ?>"><?php echo e($category->name); ?> <span class="badge-info badge-pill"><?php echo e($category->links()->count()); ?></span></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    There is no categories yet.
                        
                    <?php endif; ?>
                </ul>
            </div>

            <div class="col-md-9">
                <div class="pb-2">
                    <h2>
                        Site lists
                    </h2>
                    
                </div>
                <div class="">
                    <?php $__empty_1 = true; $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="card bg-light border-0 mb-2">                                
                                <div class="card-body">
                                    <h5><i class="fa fa-hand-o-right"></i> <a href="<?php echo e(route('link.show', $link->id)); ?>"><?php echo e($link->title); ?></a></h5>
                                    <p class="card-text">
                                        <?php echo e(substr($link->description, 0, 250)); ?>

                                    </p>
                                </div>                              
                            </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                Currently, there are no records.
                            
                    <?php endif; ?>
                    
                </div>
                <?php echo e($links->links()); ?>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LinkDir\resources\views\links\category.blade.php ENDPATH**/ ?>