<?php $__env->startSection('title', 'User Management'); ?>
<?php $__env->startSection('head', 'User Management'); ?>

<?php $__env->startSection('content'); ?>
  <div class="container">
    <?php echo $__env->make('partials.msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.errormsg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row mb-4">
        <div class="col-md-12">
            <h2>Users</h2>
            <?php if(Auth::user()->type == 'Owner'): ?>
                <div class="card bg-dark p-4 my-2 text-light">
                    <p class="text-secondary"><span class="text-light"><?php echo e(Auth::user()->name); ?></span>, only you see this box. Visit the list of <a class="text-warning" href="<?php echo e(route('admins')); ?>">
                        Admins
                    </a></p>
                </div>
            <?php endif; ?>
            <table class="table table-hover">
                <thead class="bg-warning">
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Posts</th>
                        <th>Actions</th>                        
                        <th>Moderate user</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($loop->index + 1); ?></td>
                        <td><?php echo e($user->name); ?></td>
                        <td><span class="badge-pill badge-warning"><?php echo e($user->links()->count()); ?></span></td>
                        <td>
                            <!-- Edit & delete button -->
                            <div class="float-left">
                                <button type="button" class="btn btn-info" data-toggle="modal" data-target="#modal<?php echo e($user->id); ?>">
                                    See
                                </button>

                                <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#delete<?php echo e($user->id); ?>">
                                    Delete
                                </button>
                            </div>
                            
                            <?php echo $__env->make('admin.partials.see_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php echo $__env->make('admin.partials.delete_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </td>
                        
                        <td>
                            <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#edit<?php echo e($user->id); ?>">
                                Assign
                            </button>
                            <?php echo $__env->make('admin.partials.edit_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        There is no records available now.
                    <?php endif; ?>
                </tbody>
            </table>
            <?php echo e($users->links()); ?>

        </div>
        
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.adminmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LinkDir\resources\views/admin/users.blade.php ENDPATH**/ ?>