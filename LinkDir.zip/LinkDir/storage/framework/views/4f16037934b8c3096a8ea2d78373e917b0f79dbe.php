

<?php $__env->startSection('title', 'Post Management'); ?>
<?php $__env->startSection('head', 'Post Management'); ?>

<?php $__env->startSection('content'); ?>
  <div class="container">
    <?php echo $__env->make('partials.msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.errormsg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row">
        <div class="col-md-9">
            <h2>Posts</h2>
            <table class="table table-hover">
                <thead class="bg-warning">
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Details</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><p><?php echo e($loop->index + 1); ?></p></td>
                        <td><p><?php echo e($link->title); ?></p></td>
                        <td>
                            <p>in <span class="text-warning"><?php echo e($link->category->name); ?></span> <em>by</em> <span class="text-success"><em><?php echo e($link->user->name); ?></em></span></p>
                        </td>
                        <td>
                            <!-- Edit & delete button -->
                            <div class="float-left">
                                <button type="button" class="btn btn-info" data-toggle="modal" data-target="#modal<?php echo e($link->id); ?>">
                                    Edit
                                </button>

                                <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#delete<?php echo e($link->id); ?>">
                                    Delete
                                </button>
                            </div>
                            
                            <?php echo $__env->make('admin.partials.edit_site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php echo $__env->make('admin.partials.delete_site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo e($links->links()); ?>

        </div>
        
        <div class="col-md-3">
            
            <div class="card border-info my-2">
                <div class="card-header">
                    Site operation
                </div>
                <div class="card-body">
                    
                    <div class="card-link">
                      <a class="btn btn-outline-info btn-lg btn-block" href="#" data-toggle="modal" data-target="#modaladd">Add new post</a>
            
                      <?php echo $__env->make('admin.partials.add_site', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
              </div>

        </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.adminmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LinkDir\resources\views\admin\sites.blade.php ENDPATH**/ ?>