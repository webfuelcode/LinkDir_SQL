

<?php $__env->startSection('title', 'Page Management'); ?>
<?php $__env->startSection('head', 'Page Management'); ?>

<?php $__env->startSection('content'); ?>
  <div class="container">
    <?php echo $__env->make('partials.msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.errormsg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row">
        <div class="col-md-9">
            <h2>Pages</h2>
            <table class="table table-hover">
                <thead class="bg-warning">
                    <tr>
                        <th>#</th>
                        <th>Title</th>
                        <th>Visible in footer</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><p><?php echo e($loop->index + 1); ?></p></td>
                        <td><p><?php echo e($page->title); ?></p></td>
                        <td><p><?php echo e($page->visibility); ?></p></td>
                        <td>
                            <!-- Edit & delete button -->
                            <div class="float-left">
                                <button type="button" class="btn btn-info" data-toggle="modal" data-target="#modal<?php echo e($page->id); ?>">
                                    Edit
                                </button>

                                <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#delete<?php echo e($page->id); ?>">
                                    Delete
                                </button>
                            </div>
                            
                            <?php echo $__env->make('admin.partials.edit_page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php echo $__env->make('admin.partials.delete_page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo e($pages->links()); ?>

        </div>
        
        <div class="col-md-3">
            
            <div class="card border-info my-2">
                <div class="card-header">
                    Admin operation
                </div>
                <div class="card-body">
                    
                    <div class="card-link">
                      <a class="btn btn-outline-info btn-lg btn-block" href="#" data-toggle="modal" data-target="#modaladd">Add new post</a>
            
                      <?php echo $__env->make('admin.partials.add_page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
              </div>

        </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.adminmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LinkDir\resources\views\admin\pages.blade.php ENDPATH**/ ?>