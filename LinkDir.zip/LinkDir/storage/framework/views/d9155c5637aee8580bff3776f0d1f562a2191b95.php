<!-- Modal for edit -->
<div class="modal fade" id="modaladd" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Add new record</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            
            
                <form action="<?php echo e(route('addnew')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="category_id">Site title:</label>
                            <input type="text" class="form-control" name="title" placeholder="Enter the title">
                        </div>
                        <div class="form-group">
                            <label for="category_id">Site URL:</label>
                            <input type="text" class="form-control" name="url" placeholder="Enter the URL">                            
                        </div>
                        <div class="form-group">
                            <label for="category_id">Category:</label>
                            <select name="category_id" class="custom-select">
                              <option selected="">Select a category</option>
                              <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                      
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="category_id">Description:</label>
                            <textarea class="form-control" name="description" placeholder="Description here..."></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save changes</button>
                    </div>                              
                    
                </form>
            
            
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\LinkDir\resources\views\admin\partials\add_site.blade.php ENDPATH**/ ?>