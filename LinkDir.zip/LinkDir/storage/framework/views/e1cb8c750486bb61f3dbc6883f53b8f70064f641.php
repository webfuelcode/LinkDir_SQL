<?php $__env->startSection('title', 'Admin Management'); ?>
<?php $__env->startSection('head', 'Admin Management'); ?>

<?php $__env->startSection('content'); ?>
  <div class="container">
    <?php echo $__env->make('partials.msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.errormsg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row mb-4">
        <div class="col-md-12">
            <h2>Admins</h2>
            <div class="alert alert-dismissible bg-dark text-secondary p-4 my-2">
                <button type="button" class="close" data-dismiss="alert">&times;</button>
                This page is only visible to you as the owner of the site.<br> Here you manage the admins of your site, who can "edit" & "delete" the posts.
            </div>
            <table class="table table-hover">
                <thead class="bg-warning">
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Posts</th>
                        <th>Actions</th>
                        <th>Moderate user</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->index + 1); ?></td>
                        <td><?php echo e($user->name); ?></td>
                        <td><span class="badge-pill badge-warning"><?php echo e($user->links()->count()); ?></span></td>
                        <td>
                            <!-- Edit & delete button -->
                            <div class="float-left">
                                <button type="button" class="btn btn-info" data-toggle="modal" data-target="#modal<?php echo e($user->id); ?>">
                                    See
                                </button>
                                    <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#delete<?php echo e($user->id); ?>">
                                        Delete
                                    </button>
                            </div>
                            
                            <?php echo $__env->make('admin.partials.see_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php echo $__env->make('admin.partials.delete_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </td>
                        
                        <td>
                            <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#edit<?php echo e($user->id); ?>">
                                Assign
                            </button>
                            <?php echo $__env->make('admin.partials.edit_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo e($users->links()); ?>

        </div>
        
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.adminmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LinkDir\resources\views/admin/admins.blade.php ENDPATH**/ ?>