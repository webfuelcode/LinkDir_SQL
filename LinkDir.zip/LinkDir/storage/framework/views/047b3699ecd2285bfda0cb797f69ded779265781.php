<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="title" content="<?php echo e($admin->title); ?>">
    <meta name="description" content="<?php echo e($admin->description); ?>">

    <title><?php echo e(config('app.name', 'LinkDir')); ?> | <?php echo $__env->yieldContent('title'); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Font Awesome -->
    <link href="<?php echo e(asset('css/admin/font-awesome.min.css')); ?>" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/socialicons.css')); ?>" rel="stylesheet">

    <!-- Bootstrap JS file -->
    <script src="<?php echo e(asset('js/admin/bootstrap.bundle.min.js')); ?>"></script>

</head>
<body>
    <div id="app">
        <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
    <div class="container">
        <div class="text-center">
            <?php echo $admin->leaderads; ?>

        </div>
    </div>
    <footer class="bg-dark py-4 text-light">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h4><?php echo e(config('app.name', 'LinkDir')); ?></h4>
                    <p><?php echo e($admin->description); ?></p>
                </div>
                <div class="col-md-2">
                    <h4>Pages</h4>
                    <ul class="list-unstyled">                        
                        
                            <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="<?php echo e(route('page.show', $page->id)); ?>" class="text-light"><?php echo e($page->title); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </ul>
                </div>
                <div class="col-md-4 text-right">
                    <h4><?php echo e($admin->rtitle); ?></h4>
                    <p><?php echo e($admin->rmsg); ?></p>
                    <?php if(!empty($admin->facebook)): ?>
                        <a href="https://facebook.com/<?php echo e($admin->facebook); ?>" class="fa fa-facebook so"></a>
                    <?php endif; ?>
                    <?php if(!empty($admin->twitter)): ?>
                        <a href="https://twitter.com/<?php echo e($admin->twitter); ?>" class="fa fa-twitter so"></a>
                    <?php endif; ?>
                    <?php if(!empty($admin->linkedin)): ?>
                        <a href="https://linkedin.com/<?php echo e($admin->linkedin); ?>" class="fa fa-linkedin so"></a>
                    <?php endif; ?>
                    <?php if(!empty($admin->blog)): ?>
                        <a href="<?php echo e($admin->blog); ?>" class="fa fa-book so"></a>
                    <?php endif; ?>
                                    
                </div>
            </div>
        </div>
    </footer>
</body>
</html><?php /**PATH C:\xampp\htdocs\LinkDir\resources\views\layouts\app.blade.php ENDPATH**/ ?>