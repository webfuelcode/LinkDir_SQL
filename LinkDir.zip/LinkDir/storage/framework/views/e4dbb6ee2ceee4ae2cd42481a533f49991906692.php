

<?php $__env->startSection('title', 'Advertisement Settings'); ?>
<?php $__env->startSection('head', 'Advertisement Settings'); ?>

<?php $__env->startSection('content'); ?>
    <div class="">
        <?php echo $__env->make('partials.msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('partials.errormsg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
            
        

            <div class="card border-success p-4 mt-4 mb-4">
                <h4 class="card-title">Leaderboard & side ad code</h4>
                <small class="text-info"><em>Use HTML link or get Google Adsense code here.</em></small>
                <div class="card-body">
                    <form action="<?php echo e(route('upads', $ads->id)); ?>" class="form-horizontal form-label-left" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="form-group row">
                            <label class="control-label col-md-3" for="leaderads">Leaderboard ad<br>
                                <small>It will appear on homepage to all visitors.</small>
                            </label>
                            <div class="col-md-7">                                
                                <textarea name="leaderads" class="resizable_textarea form-control"><?php echo e(old('leaderads', $ads->leaderads)); ?></textarea>
                            </div>
                        </div>
                        
                        <div class="form-group row">
                            <label class="control-label col-md-3" for="sideads">Side ad<br>
                                <small>It will appear on homepage to all visitors.</small>
                            </label>
                            <div class="col-md-7">
                                <textarea name="sideads" class="resizable_textarea form-control" rows="4"><?php echo e(old('sideads', $ads->sideads)); ?></textarea>
                            </div>
                        </div>
                        
                        
                        
                        <div class="item form-group">
                            <div class="col-md-6 col-sm-6 offset-md-3">
                                <button class="btn btn-primary" type="reset">Reset</button>
                                <button type="submit" class="btn btn-success">Submit</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
                
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.adminmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LinkDir\resources\views\admin\ads.blade.php ENDPATH**/ ?>