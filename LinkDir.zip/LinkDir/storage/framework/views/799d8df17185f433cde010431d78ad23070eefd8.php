

<?php $__env->startSection('title', 'Site Settings'); ?>
<?php $__env->startSection('head', 'Site Settings'); ?>

<?php $__env->startSection('content'); ?>
    <div class="">
        <?php echo $__env->make('partials.msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('partials.errormsg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
            <div class="card border-success p-4 my-2">
                <h4 class="card-title">Site settings</h4>
                <div class="card-body">
                    <form action="<?php echo e(route('upsettings', $settings->id)); ?>" class="form-horizontal form-label-left" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="form-group row">
                            <label class="control-label col-md-3" for="site-title">Site Title<br>
                                <small>Your site title or the company name.</small>
                            </label>
                            <div class="col-md-7">
                                <input type="text" name="title" class="form-control col-md-7" value="<?php echo e(old('title', $settings->title)); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="control-label col-md-3" for="site-description">Site Description<br>
                                <small>Provide a description for search engines.</small>
                            </label>
                            <div class="col-md-7">                                        
                                <textarea name="description" class="resizable_textarea form-control"><?php echo e(old('description', $settings->description)); ?></textarea>
                            </div>
                        </div>                        
                        <div class="form-group row">
                            <label class="control-label col-md-3" for="about">About<br>
                                <small>A short description for footer area.</small>
                            </label>
                            <div class="col-md-7">                                        
                                <textarea name="about" class="resizable_textarea form-control"><?php echo e(old('about', $settings->about)); ?></textarea>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="control-label col-md-3" for="site-message">Site Message<br>
                                <small>It will appear on homepage to all visitors.</small>
                            </label>
                            <div class="col-md-7">
                                <textarea name="sitemsg" class="resizable_textarea form-control"><?php echo e(old('sitemsg', $settings->sitemsg)); ?></textarea>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="control-label col-md-3" for="captcha">CAPTCHA Code<br>
                                <small>Google CAPTCHA code here</small>
                            </label>
                            <div class="col-md-7">                            
                                <textarea name="captcha" class="resizable_textarea form-control" value="<?php echo e(old('captcha', $settings->captcha)); ?>"></textarea>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="control-label col-md-3" for="right-footer-title">Footer title<br>
                                <small>Footer title on right side</small>
                            </label>
                            <div class="col-md-7">                            
                                <input type="text" name="rtitle" class="form-control col-md-7" value="<?php echo e(old('rtitle', $settings->rtitle)); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="control-label col-md-3" for="right-footer-msg">Footer message<br>
                                <small>Footer message on right side</small>
                            </label>
                            <div class="col-md-7">                            
                                <input type="text" name="rmsg" class="form-control col-md-7" value="<?php echo e(old('rmsg', $settings->rmsg)); ?>">
                            </div>
                        </div>

                        
                        
                            <div class="item form-group">
                                <div class="col-md-6 col-sm-6 offset-md-3">
                                    <button class="btn btn-primary" type="reset">Reset</button>
                                    <button type="submit" class="btn btn-success">Submit</button>
                                </div>
                            </div>                        
                    </form>
                </div>
            </div>

        
        

            <div class="card border-success p-4 mt-4 mb-4">
                <h4 class="card-title">Social pages</h4>
                <div class="card-body">
                    <form action="<?php echo e(route('upsocial', $settings->id)); ?>" class="form-horizontal form-label-left" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="form-group row">
                            <label class="control-label col-md-3" for="facebook">Facebook<br>
                                <small>Enter your Facebook username.</small>
                            </label>
                            <div class="col-md-7">
                                <input type="text" name="facebook" class="form-control col-md-7" value="<?php echo e(old('facebook', $settings->facebook)); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="control-label col-md-3" for="twitter">Twitter<br>
                                <small>Enter your Twitter handle.</small>
                            </label>
                            <div class="col-md-7">
                                <input type="text" name="twitter" class="form-control col-md-7" value="<?php echo e(old('twitter', $settings->twitter)); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="control-label col-md-3" for="linkedin">Linkedin<br>
                                <small>Enter your Linkedin username.</small>
                            </label>
                            <div class="col-md-7">
                                <input type="text" name="linkedin" class="form-control col-md-7" value="<?php echo e(old('linkedin', $settings->linkedin)); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="control-label col-md-3" for="blog">Blog<br>
                                <small>Include <span class="text-info">http://</span> or <span class="text-info">https://</span> with the address.</small>
                            </label>
                            <div class="col-md-7">
                                <input type="text" name="blog" class="form-control col-md-7" value="<?php echo e(old('blog', $settings->blog)); ?>">
                            </div>
                        </div>

                        
                        
                        
                        <div class="item form-group">
                            <div class="col-md-6 col-sm-6 offset-md-3">
                                <button class="btn btn-primary" type="reset">Reset</button>
                                <button type="submit" class="btn btn-success">Submit</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
                
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.adminmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LinkDir\resources\views\admin\settings.blade.php ENDPATH**/ ?>