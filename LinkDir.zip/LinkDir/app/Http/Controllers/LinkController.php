<?php

namespace App\Http\Controllers;

use App\Link;
use App\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class LinkController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $categories = Category::all();
        $links = Link::paginate(10);

        return view('links.category', compact('categories', 'links'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $categories = Category::all();
        $links = Link::all();
        return view('links.create', compact('categories', 'links'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validated = $this->validate($request, [
            'title' => 'required|min:5|max:150',
            'url' => 'max:50',
            'category_id' => 'required',
            'description' => 'required|min:20'
        ]);

        $validated['user_id'] = Auth::id();

        $link = Link::create($validated);

        return redirect()->route('link.show', ['link' => $link->id])->withMessage('Site added successfully!');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Link  $link
     * @return \Illuminate\Http\Response
     */
    public function show(Link $link)
    {
        $link->load('category');
        return view('links.single', compact('link'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Link  $link
     * @return \Illuminate\Http\Response
     */
    public function edit(Link $link)
    {
        $categories = Category::all();
        return view('links.edit', compact('link', 'categories'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Link  $link
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Link $link)
    {
        if(auth()->user()->id !== $link->user_id){
            abort(401, "unauthorized");
        }
        
        //validate
        $this->validate($request, [
            'title' => 'required|min:5|max:150',
            'url' => 'max:50',
            'category_id' => 'required',
            'description' => 'required|min:20'
        ]);

        //update
        $link->update($request->all());

        //redirect
        return redirect()->route('link.show', $link->id)->withMessage('Site description has updated successfully!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Link  $link
     * @return \Illuminate\Http\Response
     */
    public function destroy(Link $link)
    {
        $link->delete();
        return redirect()->route('home')->withMessage('Record deleted successfully!');
    }
}
