<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AdminSet extends Model
{
    protected $fillable = [
        'title',
        'description',
        'keywords',
        'about',
        'sitemsg',
        'rtitle',
        'rmsg',
        'captcha',
        'leaderad',
        'sideads',
        'facebook',
        'twitter',
        'linkedin',
        'blog'
    ];
}
