@extends('layouts.app')

@section('title', 'Categories')

@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <h2 class="pb-2">
                    Categories
                </h2>
                
                <ul class="list-group">
                    <a class="list-group-item" href="{{ route('link.index') }}">View all</a>
                    @forelse ($categories as $category)
                            
                        <a class="list-group-item d-flex justify-content-between align-item-center" href="{{route('category.show', $category->name)}}">{{$category->name}}</a>
                    @empty
                    There is no categories yet.
                        
                    @endforelse
                </ul>

                <div class="p-4">
                    {!! $admin->sideads !!}
                </div>
            </div>            

            <div class="col-md-9">
                <div class="pb-2">
                    <h2>
                        Site lists
                    </h2>
                    
                </div>
                <div class="">
                    @forelse ($links as $link)
                            <div class="card bg-light border-0 mb-2">                                
                                <div class="card-body">
                                    <h5><i class="fa fa-hand-o-right"></i> <a href="{{ route('link.show', $link->id) }}">{{ $link->title }}</a></h5>
                                    <p class="card-text">
                                        {{ substr($link->description, 0, 250) }}
                                    </p>
                                </div>                              
                            </div>
                    @empty
                                Currently, there are no records.
                            
                    @endforelse
                    
                </div>
                {{ $links->links() }}
            </div>
        </div>
    </div>
@endsection