@extends('layouts.app')

@section('title', 'Search directory')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card border-0 mb-2 d-flex justify-content-between">
                <div class="form-inline mb-4">
                    <h4 class="form-group mr-4">Search results</h4>
                    <span class="form-group">
                        @include('layouts.searchform')</span>                
                </div>
            </div>
                @forelse ($links as $link)
                <div>
                    <p><a href="{{ route('link.show', $link->id) }}">{{$link->title}}</a><br>
                    {{$link->description}}</p>
                </div>
                @empty
                    No results on your query.
                @endforelse
                {{ $links->links() }}

        </div>
    </div>
</div>
@endsection