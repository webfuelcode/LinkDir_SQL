<!-- Modal for edit -->
<div class="modal fade" id="modal{{$user->id}}" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Site records of <span class="text-success"><em>{{ $user->name }}</em></span></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            
            <div class="modal-body form-group">
                <table class="table table-hover">
                    <thead class="bg-warning">
                        <tr>
                            <th>#</th>
                            <th>Site Title</th>
                            <th>Category</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($user->links as $link)
                            <tr>
                                <td>
                                    {{ $loop->index + 1 }}
                                </td>
                                <td>
                                    {{$link->title}}
                                </td>
                                <td>
                                    {{$link->category->name ?? 'No category'}}
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
                        
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-success" data-dismiss="modal">Okay!</button>
            </div>
            
            
        </div>
    </div>
</div>