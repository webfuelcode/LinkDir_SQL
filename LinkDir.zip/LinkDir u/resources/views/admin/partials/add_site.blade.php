<!-- Modal for edit -->
<div class="modal fade" id="modaladd" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Add new record</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            
            
                <form action="{{route('addnew')}}" method="POST">
                        @csrf
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="category_id">Site title:</label>
                            <input type="text" class="form-control" name="title" placeholder="Enter the title">
                        </div>
                        <div class="form-group">
                            <label for="category_id">Site URL:</label>
                            <input type="text" class="form-control" name="url" placeholder="Enter the URL">                            
                        </div>
                        <div class="form-group">
                            <label for="category_id">Category:</label>
                            <select name="category_id" class="custom-select">
                              <option selected="">Select a category</option>
                              @foreach ($categories as $category)
                                <option value="{{ $category->id }}">{{ $category->name }}</option>
                              @endforeach                      
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="category_id">Description:</label>
                            <textarea class="form-control" name="description" placeholder="Description here..."></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save changes</button>
                    </div>                              
                    
                </form>
            
            
        </div>
    </div>
</div>