@extends('layouts.app')

@section('title', 'Edit entry')

@section('content')
    <div class="container">
      @include('partials.errormsg')
        
        <div class="row justify-content-center">
            <div class="col-md-8">
                <form action="{{route('link.update', $link->id)}}" method="POST">
                    @csrf
                    @method('PUT')
                    <div class="form-group">
                      <label for="title">Site title <span class="text-danger">*</span></label>
                      <input type="text" name="title" class="form-control" value="{{ old('title', $link->title) }}">
                    </div>
                    <div class="form-row">
                      <div class="form-group col-md-6">
                        <label for="url">Site URL</label>
                        <input type="text" name="url" class="form-control" value="{{ old('url', $link->url) }}">
                      </div>
                      <div class="form-group col-md-6">
                        <label for="category_id">Category <span class="text-danger">*</span></label>
                        <select name="category_id" class="custom-select">
                          <option selected="">Select a category</option>
                          @foreach ($categories as $category)
                            <option value="{{ $category->id }}" {{ $category->id === $link->category_id ? ' selected' : '' }}>{{ $category->name }}</option>
                          @endforeach                      
                        </select>
                      </div>
                    </div>
                      <div class="form-group">
                        <label for="description">Site description <span class="text-danger">*</span></label>
                        <textarea name="description" class="form-control" cols="30" rows="10">{{ old('description', $link->description) }}</textarea>
                      </div>
                    <button type="submit" class="btn btn-primary btn-block">Submit</button>
                  </form>
            </div>
        </div>
    </div>
@endsection