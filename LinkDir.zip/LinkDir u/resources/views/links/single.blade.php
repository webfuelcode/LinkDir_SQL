@extends('layouts.app')

@section('title', $link->title)

@section('content')
<div class="py-2 text-center">
    {!! $admin->leaderads !!}
</div>
    <div class="container">
        {{--Site messages--}}
        @include('partials.msg')
        {{--Site messages ends--}}

        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card border-0">
                    <h4 class="card-header">
                        {{ $link->title }}
                    </h4>
                    <div class="card-body">
                        <p class="card-text">
                            {!! nl2br($link->description) !!}
                        </p>
                        
                        <div class="card-text">
                            {{ $link->url }}
                        </div>
                        <div class="card-link">
                            <strong>In category:</strong> <a href="{{ route('category.show', $link->category->name) }}">{{ $link->category->name ?? 'Uncategorized' }}</a>
                        </div>
                        @auth
                        @if (auth()->user()->id == $link->user_id || auth()->user()->type == 'Owner' || auth()->user()->type == 'Admin')
                            
                        
                        <div class="card-link float-right">
                
                            <div class="actions form-inline">
                                <a href="{{route('link.edit', $link->id)}}" class="btn btn-success btn-sm badge form-group m-1">Edit</a>

                                <button type="submit" class="btn btn-danger badge m-1" data-toggle="modal" data-target="#delete{{$link->id}}">Delete</button>
                                @include('partials.delete_post')
                                
                            </div>
                            
                        </div>
                        
                        @endif
                        @endauth
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <div class="card-text">
                            {{ $link->url }}
                        </div>
                        <div class="card-link">
                            <strong>In category:</strong> <a href="{{ route('category.show', $link->category->name) }}">{{ $link->category->name ?? 'Uncategorized' }}</a>
                        </div>
                    </div>                    
                </div>
                <div class="p-4">
                    {!! $admin->sideads !!}
                </div>
            </div>
        </div>
    </div>
@endsection