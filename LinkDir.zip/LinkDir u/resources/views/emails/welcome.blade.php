@component('mail::message')
# Welcome

We are glad to have you here.

Now you are a proud member of {{ config('app.name') }}. Visit the site and start posting. Hope you will get advantages from our side.

For any help, please visit the pages.

Thanks,<br>
{{ config('app.name') }}
@endcomponent
