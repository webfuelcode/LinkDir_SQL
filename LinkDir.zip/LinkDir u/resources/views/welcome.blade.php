@extends('layouts.app')

@section('title', 'Welcome home')

@section('content')
    <div class="container">
        <div class="card border-0 w-100 p-5">
            <div class="row">
                <div class="col-md-5 my-auto">
                    <p>{{$admin->sitemsg}}</p>
                    @include('layouts.searchform')
                </div>
                <div class="col-md-7">
                    <img class="img-fluid" src="/images/linkdir.png" alt="LinkDir">
                </div>
            </div>
        </div>
        <div class="text-center">
            {!! $admin->leaderads !!}
        </div>

        <div>
            <p class="text-center">Find sites via suitable categories available below.</p>
        </div>
        <div class="row">
            @forelse ($categories as $category)
                <div class="col-sm-6 col-md-6 col-lg-3 my-4">
                    <div class="card bg-dark text-white text-center">
                        <div class="card-header">
                            {{ $category->name }} ({{ $category->links()->count() }})
                        </div>
                        <div class="card-body">
                            <a class="btn btn-dark" href="{{ route('category.show', $category->name) }}">See</a>
                        </div>
                    </div>
                </div>
            @empty
                No catrgories, in the record.
            @endforelse
        </div>        
    </div>
@endsection