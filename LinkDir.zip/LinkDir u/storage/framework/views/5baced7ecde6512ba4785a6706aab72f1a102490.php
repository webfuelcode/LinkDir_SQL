

<?php $__env->startSection('title', 'Search directory'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card border-0 mb-2 d-flex justify-content-between">
                <div class="form-inline mb-4">
                    <h4 class="form-group mr-4">Search results</h4>
                    <span class="form-group">
                        <?php echo $__env->make('layouts.searchform', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></span>                
                </div>
            </div>
                <?php $__empty_1 = true; $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div>
                    <p><a href="<?php echo e(route('link.show', $link->id)); ?>"><?php echo e($link->title); ?></a><br>
                    <?php echo e($link->description); ?></p>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    No results on your query.
                <?php endif; ?>
                <?php echo e($links->links()); ?>


        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LinkDir\resources\views\links\search.blade.php ENDPATH**/ ?>