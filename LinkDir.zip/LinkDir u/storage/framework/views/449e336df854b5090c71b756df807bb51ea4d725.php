<div class="right_col" role="main">
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3>Settings</h3>
            </div>
            <div class="x_panel">
                <div class="x_title">
                    <h2>General settings <small> Site settings for SEO and site visitors</small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                        </li>                                
                    </ul>
                    <div class="clearfix"></div>
                </div>

                <div class="x_content">
                    <form class="form-horizontal form-label-left">
                        <div class="form-group row">
                            <label class="control-label col-md-3" for="site-title">Site Title<br>
                                <small>Your site title or the company name.</small>
                            </label>
                            <div class="col-md-7">
                                <input type="text" name="title" class="form-control col-md-7 ">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="control-label col-md-3" for="site-description">Site Description<br>
                                <small>Provide a description for search engines.</small>
                            </label>
                            <div class="col-md-7">                                        
                                <textarea name="description" class="resizable_textarea form-control"></textarea>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="control-label col-md-3" for="site-keywords">Site Keywords<br>
                                <small>Add keywords which define your site.</small>
                            </label>
                            <div class="col-md-7">
                                <input type="text" name="keywords" class="form-control col-md-7 ">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="control-label col-md-3" for="about">About<br>
                                <small>A short description for footer area.</small>
                            </label>
                            <div class="col-md-7">                                        
                                <textarea name="about" class="resizable_textarea form-control"></textarea>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="control-label col-md-3" for="site-message">Site Message<br>
                                <small>It will appear on homepage to all visitors.</small>
                            </label>
                            <div class="col-md-7">
                                <input type="text" name="sitemsg" class="form-control col-md-7 ">
                            </div>
                        </div>

                        
                        <div class="ln_solid"></div>
                                <div class="item form-group">
                                    <div class="col-md-6 col-sm-6 offset-md-3">
                                        <button class="btn btn-primary" type="button">Cancel</button>
                                        <button class="btn btn-primary" type="reset">Reset</button>
                                        <button type="submit" class="btn btn-success">Submit</button>
                                    </div>
                                </div>
                        
                    </form>
                </div>

                
                
                
                <h4>extinfo</h4>

                
            </div>

            
            <div class="x_panel">
                <div class="x_title">
                    <h2>General settings <small> Site settings for SEO and site visitors</small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                        </li>                                
                    </ul>
                    <div class="clearfix"></div>
                </div>

                <div class="x_content">
                    <form class="form-horizontal form-label-left">    
                        <div class="form-group row">
                            <label class="control-label col-md-3" for="facebook">Facebook<br>
                                <small>It will appear on homepage to all visitors.</small>
                            </label>
                            <div class="col-md-7">
                                <input type="text" name="facebook" class="form-control col-md-7 ">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="control-label col-md-3" for="twitter">Twitter<br>
                                <small>It will appear on homepage to all visitors.</small>
                            </label>
                            <div class="col-md-7">
                                <input type="text" name="twitter" class="form-control col-md-7 ">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="control-label col-md-3" for="linkedin">Linkedin<br>
                                <small>It will appear on homepage to all visitors.</small>
                            </label>
                            <div class="col-md-7">
                                <input type="text" name="linkedin" class="form-control col-md-7 ">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="control-label col-md-3" for="blog">Blog<br>
                                <small>It will appear on homepage to all visitors.</small>
                            </label>
                            <div class="col-md-7">
                                <input type="text" name="blog" class="form-control col-md-7 ">
                            </div>
                        </div>

                        
                        
                        <div class="ln_solid"></div>
                        <div class="item form-group">
                            <div class="col-md-6 col-sm-6 offset-md-3">
                                <button class="btn btn-primary" type="button">Cancel</button>
                                <button class="btn btn-primary" type="reset">Reset</button>
                                <button type="submit" class="btn btn-success">Submit</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>

    </div>
</div><?php /**PATH C:\xampp\htdocs\LinkDir\resources\views\admin\form.blade.php ENDPATH**/ ?>