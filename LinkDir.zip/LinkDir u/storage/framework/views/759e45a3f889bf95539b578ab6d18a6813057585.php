<!-- Modal for edit -->
<div class="modal fade" id="edit<?php echo e($user->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Set user role</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            
            
                <form action="<?php echo e(route('admemup', $user->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                    <div class="modal-body">                        
                        <div class="form-group">
                            <label for="type">Assign admin role for <?php echo e($user->name); ?>?</label>
                            <select name="type" class="custom-select">
                              <option selected="">Select</option>
                              
                                <option value="Admin" <?php echo e($user->type === 'Admin' ? ' selected' : ''); ?>>Yes</option>
                                <option value="NULL" <?php echo e($user->type === 'NULL' ? ' selected' : ''); ?>>No</option>
                              
                            </select>
                        </div>
                        
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save changes</button>
                    </div>                              
                    
                </form>
            
            
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\LinkDir\resources\views\admin\partials\edit_user.blade.php ENDPATH**/ ?>