<!-- Modal for edit -->
<div class="modal fade" id="modal<?php echo e($category->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Edit category</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            
            
                <form action="<?php echo e(route('category.update', $category->name)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                    <div class="modal-body form-group">
                        <input type="text" class="form-control" name="name" value="<?php echo e($category->name); ?>">
                        <small>Character required is min. 3 and max. 50</small>
                        
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save changes</button>
                    </div>                              
                    
                </form>
            
            
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\LinkDir\resources\views/admin/partials/edit_category.blade.php ENDPATH**/ ?>