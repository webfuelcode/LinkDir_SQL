

<?php $__env->startSection('title', 'Edit personal data'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php echo $__env->make('partials.msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('partials.errormsg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header"><?php echo e(__('Edit personal data')); ?></div>
                    <div class="card-body p-4">
                        <form action="<?php echo e(route('users.update', $user)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
        
                            <div class="form-group">
                                <label for="Email">Email id <span class="text-danger">*</span></label>
                                <input type="email" name="email" class="form-control" value="<?php echo e($user->email); ?>">
                            </div>
        
                            <div class="form-group">
                                <label for="Password">New password <span class="text-danger">*</span></label>
                                <input type="password" name="password" class="form-control">
                            </div>
        
                            <div class="form-group">
                                <label for="Email">Repeat password <span class="text-danger">*</span></label>
                                <input type="password" name="password_confirmation" class="form-control">
                            </div>
                        
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </form>
                    </div>
                </div>
            </div>

            <div class="col-md-2">
                <div class="card bg-info text-light">
                    <div class="card-body">
                        <p>Use this form to change email or pawword.</p>
                        <p>On changing email, use the same password or new one.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LinkDir\resources\views/links/edit_user.blade.php ENDPATH**/ ?>