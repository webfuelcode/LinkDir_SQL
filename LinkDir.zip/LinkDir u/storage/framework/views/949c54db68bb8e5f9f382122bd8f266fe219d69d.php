

<?php $__env->startSection('title', $link->title); ?>

<?php $__env->startSection('content'); ?>
<div class="py-2 text-center">
    <?php echo $admin->leaderads; ?>

</div>
    <div class="container">
        
        <?php echo $__env->make('partials.msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        

        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card border-0">
                    <h4 class="card-header">
                        <?php echo e($link->title); ?>

                    </h4>
                    <div class="card-body">
                        <p class="card-text">
                            <?php echo nl2br($link->description); ?>

                        </p>
                        
                        <div class="card-text">
                            <?php echo e($link->url); ?>

                        </div>
                        <div class="card-link">
                            <strong>In category:</strong> <a href="<?php echo e(route('category.show', $link->category->name)); ?>"><?php echo e($link->category->name ?? 'Uncategorized'); ?></a>
                        </div>
                        <?php if(auth()->guard()->check()): ?>
                        <?php if(auth()->user()->id == $link->user_id || auth()->user()->type == 'Owner' || auth()->user()->type == 'Admin'): ?>
                            
                        
                        <div class="card-link float-right">
                
                            <div class="actions form-inline">
                                <a href="<?php echo e(route('link.edit', $link->id)); ?>" class="btn btn-success btn-sm badge form-group m-1">Edit</a>

                                <button type="submit" class="btn btn-danger badge m-1" data-toggle="modal" data-target="#delete<?php echo e($link->id); ?>">Delete</button>
                                <?php echo $__env->make('partials.delete_post', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                
                            </div>
                            
                        </div>
                        
                        <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <div class="card-text">
                            <?php echo e($link->url); ?>

                        </div>
                        <div class="card-link">
                            <strong>In category:</strong> <a href="<?php echo e(route('category.show', $link->category->name)); ?>"><?php echo e($link->category->name ?? 'Uncategorized'); ?></a>
                        </div>
                    </div>                    
                </div>
                <div class="p-4">
                    <?php echo $admin->sideads; ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LinkDir\resources\views/links/single.blade.php ENDPATH**/ ?>