<?php
/**
 * linkdir - Admin Dashboard Overview
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';

auth_require_admin();
$db = get_db();

// Metrics
$totalUsers = (int)$db->query("SELECT COUNT(*) FROM users")->fetchColumn();
$totalBiz = (int)$db->query("SELECT COUNT(*) FROM businesses")->fetchColumn();
$pendingBiz = (int)$db->query("SELECT COUNT(*) FROM businesses WHERE status = 'pending'")->fetchColumn();
$approvedBiz = (int)$db->query("SELECT COUNT(*) FROM businesses WHERE status = 'approved'")->fetchColumn();

$totalReviews = (int)$db->query("SELECT COUNT(*) FROM reviews")->fetchColumn();
$pendingReviews = (int)$db->query("SELECT COUNT(*) FROM reviews WHERE status = 'pending'")->fetchColumn();

$totalCategories = (int)$db->query("SELECT COUNT(*) FROM categories")->fetchColumn();
$totalAds = (int)$db->query("SELECT COUNT(*) FROM ads WHERE status = 'active'")->fetchColumn();

// Fetch 5 latest pending businesses
$pendingBizList = $db->query("
    SELECT b.*, c.name as category_name, u.name as owner_name, u.email as owner_email
    FROM businesses b
    JOIN categories c ON b.category_id = c.id
    LEFT JOIN users u ON b.user_id = u.id
    WHERE b.status = 'pending'
    ORDER BY b.created_at ASC
    LIMIT 5
")->fetchAll();

// Fetch 5 latest pending reviews
$pendingReviewList = $db->query("
    SELECT r.*, b.business_name, b.slug as business_slug, u.name as reviewer_name, u.email as reviewer_email
    FROM reviews r
    JOIN businesses b ON r.business_id = b.id
    JOIN users u ON r.user_id = u.id
    WHERE r.status = 'pending'
    ORDER BY r.created_at ASC
    LIMIT 5
")->fetchAll();

$pageTitle = 'Admin Dashboard';
require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/includes/admin-nav.php';
?>

<div class="container mb-5">
    <?= flash_render() ?>

    <!-- Quick Shortcuts Bar -->
    <div class="d-flex gap-2 mb-4 flex-wrap">
        <a href="/admin/ads" class="btn btn-white bg-white border shadow-xs btn-sm px-3 py-2 text-dark fw-semibold d-inline-flex align-items-center gap-2">
            <i class="bi bi-badge-ad text-primary fs-5"></i>
            <span>Ads &amp; Banners (<?= $totalAds ?> active)</span>
        </a>
        <a href="/admin/businesses?status=pending" class="btn btn-white bg-white border shadow-xs btn-sm px-3 py-2 text-dark fw-semibold d-inline-flex align-items-center gap-2">
            <i class="bi bi-hourglass-split text-warning fs-5"></i>
            <span>Pending Listings (<?= $pendingBiz ?>)</span>
        </a>
        <a href="/admin/reviews?status=pending" class="btn btn-white bg-white border shadow-xs btn-sm px-3 py-2 text-dark fw-semibold d-inline-flex align-items-center gap-2">
            <i class="bi bi-chat-quote text-info fs-5"></i>
            <span>Pending Reviews (<?= $pendingReviews ?>)</span>
        </a>
        <a href="/admin/categories" class="btn btn-white bg-white border shadow-xs btn-sm px-3 py-2 text-dark fw-semibold d-inline-flex align-items-center gap-2">
            <i class="bi bi-tags text-success fs-5"></i>
            <span>Categories (<?= $totalCategories ?>)</span>
        </a>
    </div>

    <!-- Overview Statistics -->
    <div class="row g-3 mb-4">
        <div class="col-sm-6 col-lg-3">
            <div class="card shadow-sm border-1 p-3">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <div class="text-muted small fw-semibold">Total Businesses</div>
                        <div class="fs-4 fw-bold text-dark"><?= $totalBiz ?></div>
                        <div class="small text-success"><?= $approvedBiz ?> approved</div>
                    </div>
                    <div class="fs-1 text-primary opacity-75">
                        <i class="bi bi-buildings"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm-6 col-lg-3">
            <div class="card shadow-sm border-1 p-3 <?= ($pendingBiz > 0 ? 'border-warning' : '') ?>">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <div class="text-muted small fw-semibold">Pending Listings</div>
                        <div class="fs-4 fw-bold <?= ($pendingBiz > 0 ? 'text-warning' : 'text-dark') ?>"><?= $pendingBiz ?></div>
                        <div class="small text-muted">Awaiting approval</div>
                    </div>
                    <div class="fs-1 text-warning opacity-75">
                        <i class="bi bi-hourglass-split"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm-6 col-lg-3">
            <div class="card shadow-sm border-1 p-3 <?= ($pendingReviews > 0 ? 'border-warning' : '') ?>">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <div class="text-muted small fw-semibold">Pending Reviews</div>
                        <div class="fs-4 fw-bold <?= ($pendingReviews > 0 ? 'text-warning' : 'text-dark') ?>"><?= $pendingReviews ?></div>
                        <div class="small text-muted"><?= $totalReviews ?> total reviews</div>
                    </div>
                    <div class="fs-1 text-info opacity-75">
                        <i class="bi bi-chat-quote"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm-6 col-lg-3">
            <div class="card shadow-sm border-1 p-3">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <div class="text-muted small fw-semibold">Registered Users</div>
                        <div class="fs-4 fw-bold text-dark"><?= $totalUsers ?></div>
                        <div class="small text-muted"><?= $totalCategories ?> categories</div>
                    </div>
                    <div class="fs-1 text-secondary opacity-75">
                        <i class="bi bi-people"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-4 mb-4">
        <!-- Pending Business Moderation Queue -->
        <div class="col-lg-7">
            <div class="card shadow-sm border-1 h-100">
                <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                    <h5 class="fw-bold mb-0">Listings Requiring Approval (<?= count($pendingBizList) ?>)</h5>
                    <a href="/admin/businesses?status=pending" class="btn btn-outline-primary btn-sm">View All Pending</a>
                </div>

                <div class="card-body p-0">
                    <?php if (!empty($pendingBizList)): ?>
                        <div class="table-responsive">
                            <table class="table table-hover align-middle mb-0">
                                <thead class="table-light small">
                                    <tr>
                                        <th>Business Name</th>
                                        <th>Category</th>
                                        <th>Owner</th>
                                        <th class="text-end">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($pendingBizList as $pb): ?>
                                        <tr id="pending-biz-<?= (int)$pb['id'] ?>">
                                            <td>
                                                <strong><?= e($pb['business_name']) ?></strong>
                                                <div class="text-muted small"><?= !empty($pb['country']) ? e($pb['country']) : '' ?></div>
                                            </td>
                                            <td class="small">
                                                <?= e($pb['category_name']) ?>
                                            </td>
                                            <td class="small text-muted">
                                                <?= e($pb['owner_name'] ?? 'Guest') ?><br>
                                                <small><?= e($pb['owner_email'] ?? '') ?></small>
                                            </td>
                                            <td class="text-end">
                                                <div class="btn-group btn-group-sm">
                                                    <a href="/business/<?= e($pb['slug']) ?>" class="btn btn-outline-secondary" target="_blank" title="Preview">
                                                        <i class="bi bi-eye"></i>
                                                    </a>
                                                    <form action="/admin/actions.php" method="POST" class="d-inline"
                                                          hx-post="/admin/actions.php"
                                                          hx-target="#pending-biz-<?= (int)$pb['id'] ?>"
                                                          hx-swap="outerHTML">
                                                        <?= csrf_field() ?>
                                                        <input type="hidden" name="action" value="business_status">
                                                        <input type="hidden" name="id" value="<?= (int)$pb['id'] ?>">
                                                        <input type="hidden" name="status" value="approved">
                                                        <button type="submit" class="btn btn-success" title="Approve">
                                                            <i class="bi bi-check-lg"></i>
                                                        </button>
                                                    </form>
                                                    <form action="/admin/actions.php" method="POST" class="d-inline"
                                                          hx-post="/admin/actions.php"
                                                          hx-target="#pending-biz-<?= (int)$pb['id'] ?>"
                                                          hx-swap="outerHTML">
                                                        <?= csrf_field() ?>
                                                        <input type="hidden" name="action" value="business_status">
                                                        <input type="hidden" name="id" value="<?= (int)$pb['id'] ?>">
                                                        <input type="hidden" name="status" value="rejected">
                                                        <button type="submit" class="btn btn-danger" title="Reject">
                                                            <i class="bi bi-x-lg"></i>
                                                        </button>
                                                    </form>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="p-4 text-center text-muted">
                            <i class="bi bi-check-circle-fill text-success fs-3 mb-2 d-block"></i>
                            <p class="mb-0">No business listings currently waiting for approval.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Pending Review Moderation Queue -->
        <div class="col-lg-5">
            <div class="card shadow-sm border-1 h-100">
                <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
                    <h5 class="fw-bold mb-0">Pending Reviews (<?= count($pendingReviewList) ?>)</h5>
                    <a href="/admin/reviews?status=pending" class="btn btn-outline-primary btn-sm">All Reviews</a>
                </div>

                <div class="card-body p-0">
                    <?php if (!empty($pendingReviewList)): ?>
                        <div class="list-group list-group-flush">
                            <?php foreach ($pendingReviewList as $pr): ?>
                                <div class="list-group-item p-3" id="pending-rev-<?= (int)$pr['id'] ?>">
                                    <div class="d-flex justify-content-between align-items-start mb-1">
                                        <strong><?= e($pr['business_name']) ?></strong>
                                        <div class="small"><?= render_stars((float)$pr['rating'], false) ?></div>
                                    </div>
                                    <p class="small text-secondary mb-2 fst-italic">"<?= e($pr['review_text']) ?>"</p>
                                    <div class="d-flex justify-content-between align-items-center">
                                        <small class="text-muted">By <?= e($pr['reviewer_name']) ?></small>
                                        <div class="btn-group btn-group-sm">
                                            <form action="/admin/actions.php" method="POST" class="d-inline"
                                                  hx-post="/admin/actions.php"
                                                  hx-target="#pending-rev-<?= (int)$pr['id'] ?>"
                                                  hx-swap="outerHTML">
                                                <?= csrf_field() ?>
                                                <input type="hidden" name="action" value="review_status">
                                                <input type="hidden" name="id" value="<?= (int)$pr['id'] ?>">
                                                <input type="hidden" name="status" value="approved">
                                                <button type="submit" class="btn btn-success btn-sm">Approve</button>
                                            </form>
                                            <form action="/admin/actions.php" method="POST" class="d-inline ms-1"
                                                  hx-post="/admin/actions.php"
                                                  hx-target="#pending-rev-<?= (int)$pr['id'] ?>"
                                                  hx-swap="outerHTML">
                                                <?= csrf_field() ?>
                                                <input type="hidden" name="action" value="review_status">
                                                <input type="hidden" name="id" value="<?= (int)$pr['id'] ?>">
                                                <input type="hidden" name="status" value="rejected">
                                                <button type="submit" class="btn btn-danger btn-sm">Reject</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div class="p-4 text-center text-muted">
                            <i class="bi bi-check-circle-fill text-success fs-3 mb-2 d-block"></i>
                            <p class="mb-0">No reviews waiting for moderation.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Server & Environment Information -->
    <div class="card shadow-sm border-1 p-4 bg-light">
        <h5 class="fw-bold mb-3">System &amp; Hosting Environment</h5>
        <div class="row g-3 small">
            <div class="col-md-3">
                <span class="text-muted d-block">PHP Version:</span>
                <strong>PHP <?= phpversion() ?></strong>
            </div>
            <div class="col-md-3">
                <span class="text-muted d-block">Database Driver:</span>
                <strong><?= $db->getAttribute(PDO::ATTR_DRIVER_NAME) ?></strong>
            </div>
            <div class="col-md-3">
                <span class="text-muted d-block">Upload Directory:</span>
                <strong class="<?= is_writable(UPLOAD_DIR) ? 'text-success' : 'text-danger' ?>">
                    <?= is_writable(UPLOAD_DIR) ? 'Writable (/uploads)' : 'Not Writable' ?>
                </strong>
            </div>
            <div class="col-md-3">
                <span class="text-muted d-block">Server Software:</span>
                <strong class="text-truncate d-block"><?= $_SERVER['SERVER_SOFTWARE'] ?? 'PHP CLI / Built-in' ?></strong>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
