<?php
/**
 * linkdir - Admin Sub-navigation Header
 */

$adminPath = parse_url($_SERVER['REQUEST_URI'] ?? '/admin', PHP_URL_PATH);
$db = get_db();

// Pending counts for badges
$pendingBizCount = (int)$db->query("SELECT COUNT(*) FROM businesses WHERE status = 'pending'")->fetchColumn();
$pendingRevCount = (int)$db->query("SELECT COUNT(*) FROM reviews WHERE status = 'pending'")->fetchColumn();
?>
<div class="bg-dark text-white border-bottom border-secondary py-3 mb-4" style="background: linear-gradient(135deg, #111827 0%, #1f2937 100%) !important;">
    <div class="container">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3">
            <div>
                <span class="badge bg-primary-subtle text-primary border border-primary-subtle text-uppercase mb-1" style="font-size:0.68rem; letter-spacing:0.75px; font-weight:700;">System Administrator</span>
                <h1 class="h4 fw-bold mb-0 text-white tracking-tight">linkdir Control Panel</h1>
            </div>

            <div class="d-flex gap-2">
                <a href="/" class="btn btn-outline-light btn-sm px-3"><i class="bi bi-box-arrow-up-right me-1"></i>View Site</a>
                <a href="/dashboard" class="btn btn-outline-primary btn-sm px-3"><i class="bi bi-speedometer2 me-1"></i>My Dashboard</a>
            </div>
        </div>

        <nav class="nav nav-pills mt-3 flex-wrap gap-1">
            <a class="nav-link text-white <?= ($adminPath === '/admin' || $adminPath === '/admin/' ? 'active bg-primary shadow-sm' : '') ?>" href="/admin">
                <i class="bi bi-speedometer me-1"></i>Overview
            </a>
            <a class="nav-link text-white position-relative <?= (str_starts_with($adminPath, '/admin/businesses') ? 'active bg-primary shadow-sm' : '') ?>" href="/admin/businesses">
                <i class="bi bi-buildings me-1"></i>Businesses
                <?php if ($pendingBizCount > 0): ?>
                    <span class="badge bg-warning text-dark ms-1"><?= $pendingBizCount ?></span>
                <?php endif; ?>
            </a>
            <a class="nav-link text-white position-relative <?= (str_starts_with($adminPath, '/admin/reviews') ? 'active bg-primary shadow-sm' : '') ?>" href="/admin/reviews">
                <i class="bi bi-chat-left-text me-1"></i>Reviews
                <?php if ($pendingRevCount > 0): ?>
                    <span class="badge bg-warning text-dark ms-1"><?= $pendingRevCount ?></span>
                <?php endif; ?>
            </a>
            <a class="nav-link text-white <?= (str_starts_with($adminPath, '/admin/categories') ? 'active bg-primary shadow-sm' : '') ?>" href="/admin/categories">
                <i class="bi bi-tags me-1"></i>Categories
            </a>
            <a class="nav-link text-white <?= (str_starts_with($adminPath, '/admin/ads') ? 'active bg-primary shadow-sm' : '') ?>" href="/admin/ads">
                <i class="bi bi-badge-ad me-1"></i>Ads &amp; Banners
            </a>
            <a class="nav-link text-white <?= (str_starts_with($adminPath, '/admin/users') ? 'active bg-primary shadow-sm' : '') ?>" href="/admin/users">
                <i class="bi bi-people me-1"></i>Users
            </a>
        </nav>
    </div>
</div>
