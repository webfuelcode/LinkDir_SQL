<?php
/**
 * linkdir - Modern Reusable Footer Component
 */
?>
</main>

<footer class="bg-dark text-light py-5 mt-auto border-top border-secondary">
    <div class="container">
        <div class="row g-4 mb-4">
            <div class="col-lg-4 col-md-6">
                <div class="d-flex align-items-center gap-2 mb-3">
                    <div class="brand-icon-box">
                        <i class="bi bi-compass-fill"></i>
                    </div>
                    <span class="fs-4 fw-bold text-white tracking-tight">linkdir</span>
                    <span class="brand-badge ms-1 text-light bg-dark border-secondary">Directory</span>
                </div>
                <p class="text-secondary small mb-3 lh-base">
                    A lightweight, fast, and modern business &amp; service directory. Helping clients find trusted service providers, professionals, and verified ratings with ease.
                </p>
                <div class="d-flex gap-3 text-secondary">
                    <a href="/businesses" class="text-secondary text-decoration-none small hover-white"><i class="bi bi-search me-1"></i>Search</a>
                    <a href="/sitemap.xml" class="text-secondary text-decoration-none small hover-white"><i class="bi bi-diagram-3 me-1"></i>Sitemap</a>
                </div>
            </div>

            <div class="col-lg-4 col-md-6">
                <h6 class="text-white text-uppercase fw-bold mb-3 small" style="letter-spacing: 0.05em;">Popular Categories</h6>
                <ul class="list-unstyled text-secondary small mb-0 d-flex flex-column gap-2">
                    <li><a href="/category/home-trade-services" class="text-secondary text-decoration-none hover-white"><i class="bi bi-chevron-right me-1 text-primary"></i>Home &amp; Trade Services</a></li>
                    <li><a href="/category/restaurants-dining" class="text-secondary text-decoration-none hover-white"><i class="bi bi-chevron-right me-1 text-primary"></i>Restaurants &amp; Dining</a></li>
                    <li><a href="/category/health-medical" class="text-secondary text-decoration-none hover-white"><i class="bi bi-chevron-right me-1 text-primary"></i>Health &amp; Medical Care</a></li>
                    <li><a href="/category/automotive-care" class="text-secondary text-decoration-none hover-white"><i class="bi bi-chevron-right me-1 text-primary"></i>Automotive Services</a></li>
                    <li><a href="/category/technology-web" class="text-secondary text-decoration-none hover-white"><i class="bi bi-chevron-right me-1 text-primary"></i>Technology &amp; Web</a></li>
                </ul>
            </div>

            <div class="col-lg-4 col-md-12">
                <h6 class="text-white text-uppercase fw-bold mb-3 small" style="letter-spacing: 0.05em;">For Business Owners</h6>
                <p class="text-secondary small mb-3 lh-base">
                    Submit your business or service in under two minutes. Get discovered by clients searching for verified providers.
                </p>
                <a href="<?= auth_check() ? '/dashboard/business/add' : '/register' ?>" class="btn btn-primary btn-sm">
                    <i class="bi bi-plus-lg me-1"></i>List Your Business
                </a>
            </div>
        </div>

        <div class="pt-4 mt-4 border-top border-secondary text-secondary small d-flex flex-column flex-md-row justify-content-between align-items-center gap-2">
            <div>
                &copy; <?= date('Y') ?> <strong class="text-light">linkdir</strong>. All rights reserved.
            </div>
            <div class="d-flex gap-2 align-items-center">
                <span class="text-secondary">Designed for Standard cPanel &amp; Shared Hosting</span>
                <span class="text-muted">&bull;</span>
                <span class="text-secondary">PHP 8.2 + HTMX</span>
            </div>
        </div>
    </div>
</footer>

<!-- Bootstrap 5 Bundle with Popper JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>
