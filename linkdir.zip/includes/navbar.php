<?php
/**
 * linkdir - Modern Main Navbar Component
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/auth.php';

$currentUser = auth_user();
$currentPath = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
?>
<nav class="navbar navbar-expand-lg modern-navbar sticky-top py-2">
    <div class="container">
        <a class="navbar-brand d-flex align-items-center gap-2" href="/">
            <div class="brand-icon-box">
                <i class="bi bi-compass-fill"></i>
            </div>
            <span class="text-dark fw-bold">linkdir</span>
            <span class="brand-badge d-none d-sm-inline-block">Directory</span>
        </a>

        <button class="navbar-toggler border-0 p-1" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMain" aria-controls="navbarMain" aria-expanded="false" aria-label="Toggle navigation">
            <i class="bi bi-list fs-2 text-dark"></i>
        </button>

        <div class="collapse navbar-collapse" id="navbarMain">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0 ms-lg-3 gap-1">
                <li class="nav-item">
                    <a class="nav-link <?= ($currentPath === '/' ? 'active' : '') ?>" href="/">
                        <i class="bi bi-house me-1"></i>Home
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= (str_starts_with($currentPath, '/businesses') || str_starts_with($currentPath, '/category') ? 'active' : '') ?>" href="/businesses">
                        <i class="bi bi-grid me-1"></i>Explore Directory
                    </a>
                </li>
                <?php if ($currentUser && $currentUser['role'] === 'admin'): ?>
                    <li class="nav-item">
                        <a class="nav-link <?= (str_starts_with($currentPath, '/admin') ? 'active' : '') ?> text-primary fw-semibold" href="/admin">
                            <i class="bi bi-shield-check me-1"></i>Admin Panel
                        </a>
                    </li>
                <?php endif; ?>
            </ul>

            <div class="d-flex align-items-center gap-2 flex-wrap pt-2 pt-lg-0">
                <a href="<?= auth_check() ? '/dashboard/business/add' : '/login?redirect=/dashboard/business/add' ?>" class="btn btn-primary btn-sm">
                    <i class="bi bi-plus-lg"></i>
                    <span>Add Listing</span>
                </a>

                <?php if ($currentUser): ?>
                    <div class="dropdown">
                        <button class="btn btn-outline-secondary btn-sm dropdown-toggle d-flex align-items-center gap-2" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="bi bi-person-circle text-primary"></i>
                            <span class="fw-semibold text-dark"><?= e($currentUser['name']) ?></span>
                            <?php if ($currentUser['role'] === 'admin'): ?>
                                <span class="badge bg-danger ms-1" style="font-size:0.65rem;">Admin</span>
                            <?php endif; ?>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end shadow-md border-1 mt-2">
                            <li class="dropdown-header">
                                <strong class="text-dark"><?= e($currentUser['name']) ?></strong><br>
                                <small class="text-muted"><?= e($currentUser['email']) ?></small>
                            </li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item py-2" href="/dashboard"><i class="bi bi-speedometer2 me-2 text-primary"></i>My Dashboard</a></li>
                            <li><a class="dropdown-item py-2" href="/dashboard/business/add"><i class="bi bi-plus-circle me-2 text-success"></i>Add Business</a></li>
                            <li><a class="dropdown-item py-2" href="/dashboard/reviews"><i class="bi bi-star me-2 text-warning"></i>My Reviews</a></li>
                            <li><a class="dropdown-item py-2" href="/dashboard/profile"><i class="bi bi-gear me-2 text-secondary"></i>Account Settings</a></li>
                            <?php if ($currentUser['role'] === 'admin'): ?>
                                <li><hr class="dropdown-divider"></li>
                                <li class="dropdown-header text-danger"><i class="bi bi-shield-lock me-1"></i>Administration</li>
                                <li><a class="dropdown-item py-2 fw-semibold text-danger" href="/admin"><i class="bi bi-shield-shaded me-2"></i>Admin Overview</a></li>
                                <li><a class="dropdown-item py-2" href="/admin/businesses"><i class="bi bi-buildings me-2"></i>Manage Listings</a></li>
                                <li><a class="dropdown-item py-2" href="/admin/categories"><i class="bi bi-tags me-2"></i>Manage Categories</a></li>
                                <li><a class="dropdown-item py-2" href="/admin/ads"><i class="bi bi-badge-ad me-2 text-primary"></i>Ads &amp; Banners</a></li>
                                <li><a class="dropdown-item py-2" href="/admin/reviews"><i class="bi bi-chat-left-text me-2"></i>Manage Reviews</a></li>
                                <li><a class="dropdown-item py-2" href="/admin/users"><i class="bi bi-people me-2"></i>Manage Users</a></li>
                            <?php endif; ?>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item py-2 text-danger" href="/logout"><i class="bi bi-box-arrow-right me-2"></i>Log Out</a></li>
                        </ul>
                    </div>
                <?php else: ?>
                    <a href="/login" class="btn btn-outline-secondary btn-sm">Log In</a>
                    <a href="/register" class="btn btn-light btn-sm text-dark">Register</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</nav>
