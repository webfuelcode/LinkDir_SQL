<?php
/**
 * linkdir - Database Connection via PDO
 * 
 * Supports both MySQL/MariaDB (default on cPanel) and SQLite
 * using strictly prepared statements and secure connection options.
 */

require_once __DIR__ . '/../config/config.php';

function get_db(): PDO {
    static $pdo = null;

    if ($pdo !== null) {
        return $pdo;
    }

    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];

    try {
        if (DB_DRIVER === 'mysql') {
            $dsn = sprintf(
                'mysql:host=%s;port=%s;dbname=%s;charset=%s',
                DB_HOST,
                DB_PORT,
                DB_NAME,
                DB_CHARSET
            );
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
            $pdo->exec("SET NAMES " . DB_CHARSET);
        } else {
            // SQLite driver (for instant portable zero-config run)
            $dbPath = DB_SQLITE_PATH;
            $dir = dirname($dbPath);
            if (!is_dir($dir)) {
                mkdir($dir, 0755, true);
            }
            $isNew = !file_exists($dbPath);
            $pdo = new PDO('sqlite:' . $dbPath, null, null, $options);
            $pdo->exec('PRAGMA foreign_keys = ON;');
            $pdo->exec('PRAGMA journal_mode = WAL;');

            if ($isNew) {
                bootstrap_sqlite_schema($pdo);
            }
        }
    } catch (PDOException $e) {
        error_log('Database Connection Error: ' . $e->getMessage());
        if (defined('APP_DEBUG') && APP_DEBUG) {
            die('Database Connection Error: Please check database configuration in config/config.php or run the installer at <a href="/install">/install</a>.');
        } else {
            die('Database error. Please try again later.');
        }
    }

    return $pdo;
}

/**
 * Bootstrap SQLite schema if sqlite driver is used and database file is new.
 */
function bootstrap_sqlite_schema(PDO $pdo): void {
    $schema = "
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'user',
        status TEXT NOT NULL DEFAULT 'active',
        failed_logins INTEGER NOT NULL DEFAULT 0,
        lock_until DATETIME NULL,
        last_login DATETIME NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS categories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        slug TEXT NOT NULL UNIQUE,
        description TEXT NULL,
        icon TEXT NOT NULL DEFAULT 'bi-briefcase',
        status TEXT NOT NULL DEFAULT 'active',
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS businesses (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        category_id INTEGER NOT NULL,
        business_name TEXT NOT NULL,
        slug TEXT NOT NULL UNIQUE,
        website_url TEXT NULL,
        logo TEXT NULL,
        about TEXT NOT NULL,
        phone TEXT NULL,
        email TEXT NULL,
        address TEXT NULL,
        city TEXT NOT NULL DEFAULT '',
        state TEXT NOT NULL DEFAULT '',
        country TEXT NOT NULL DEFAULT 'United States',
        status TEXT NOT NULL DEFAULT 'pending',
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE RESTRICT
    );

    CREATE TABLE IF NOT EXISTS reviews (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        business_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        rating INTEGER NOT NULL,
        review_text TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'approved',
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(business_id, user_id),
        FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS rate_limits (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        action_key TEXT NOT NULL,
        hits INTEGER NOT NULL DEFAULT 1,
        first_hit INTEGER NOT NULL,
        expire_time INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS ads (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        slot_key TEXT NOT NULL UNIQUE,
        title TEXT NOT NULL,
        type TEXT NOT NULL DEFAULT 'image',
        image_url TEXT NULL,
        link_url TEXT NULL,
        script_code TEXT NULL,
        status TEXT NOT NULL DEFAULT 'active',
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
    );

    CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
    CREATE INDEX IF NOT EXISTS idx_businesses_slug ON businesses(slug);
    CREATE INDEX IF NOT EXISTS idx_businesses_status ON businesses(status);
    CREATE INDEX IF NOT EXISTS idx_businesses_cat ON businesses(category_id);
    CREATE INDEX IF NOT EXISTS idx_businesses_city ON businesses(city);
    CREATE INDEX IF NOT EXISTS idx_reviews_biz ON reviews(business_id);
    ";

    $pdo->exec($schema);

    // Populate initial categories
    $stmt = $pdo->prepare("INSERT OR IGNORE INTO categories (id, name, slug, description, icon, status) VALUES (?, ?, ?, ?, ?, ?)");
    $cats = [
        [1, 'Restaurants & Dining', 'restaurants-dining', 'Cafes, bistros, bakeries, food trucks, and fine dining.', 'bi-cup-hot', 'active'],
        [2, 'Home & Trade Services', 'home-trade-services', 'Plumbing, electrical, roofing, HVAC, cleaning, and landscaping.', 'bi-tools', 'active'],
        [3, 'Health & Medical', 'health-medical', 'Doctors, dentists, physical therapists, clinics, and wellness centers.', 'bi-heart-pulse', 'active'],
        [4, 'Automotive Services', 'automotive-services', 'Auto repair, detailing, tire shops, towing, and dealerships.', 'bi-car-front', 'active'],
        [5, 'Professional & Legal', 'professional-legal', 'Lawyers, certified accountants, consultants, and financial advisors.', 'bi-briefcase', 'active'],
        [6, 'Beauty & Personal Care', 'beauty-personal-care', 'Hair salons, barbershops, spas, nail studios, and skincare.', 'bi-scissors', 'active'],
        [7, 'Technology & Web Services', 'technology-web-services', 'IT support, software agencies, computer repair, and web design.', 'bi-laptop', 'active'],
        [8, 'Real Estate & Property', 'real-estate-property', 'Realtors, property management, appraisals, and inspection.', 'bi-house-check', 'active'],
        [9, 'Education & Tutoring', 'education-tutoring', 'Music lessons, language schools, driving schools, and academic tutors.', 'bi-book', 'active'],
        [10, 'Fitness & Recreation', 'fitness-recreation', 'Gyms, martial arts, personal trainers, yoga, and dance studios.', 'bi-activity', 'active']
    ];
    foreach ($cats as $cat) {
        $stmt->execute($cat);
    }

    // Populate default ad slots
    $adStmt = $pdo->prepare("INSERT OR IGNORE INTO ads (slot_key, title, type, image_url, link_url, script_code, status) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $seedAds = [
        ['leaderboard_top', 'Directory Top Leaderboard (728x90)', 'image', 'https://placehold.co/728x90/e2e8f0/334155?text=Advertise+Here+-+Premium+Leaderboard+Banner+(728x90)', '#', '', 'active'],
        ['sidebar_directory', 'Directory Sidebar Ad (300x250)', 'image', 'https://placehold.co/300x250/e2e8f0/334155?text=Feature+Your+Business+Here+(300x250)', '#', '', 'active'],
        ['sidebar_business', 'Business Detail Sidebar Ad (300x250)', 'image', 'https://placehold.co/300x250/e2e8f0/334155?text=Partner+Promotion+Banner+(300x250)', '#', '', 'active'],
        ['leaderboard_business', 'Business Detail Bottom Leaderboard (728x90)', 'image', 'https://placehold.co/728x90/e2e8f0/334155?text=Sponsor+Placement+Area+(728x90)', '#', '', 'active']
    ];
    foreach ($seedAds as $sa) {
        $adStmt->execute($sa);
    }
}
