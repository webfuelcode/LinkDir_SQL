<?php
/**
 * linkdir - User Dashboard
 */

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../includes/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';

auth_require_login();
$user = auth_user();
$db = get_db();

// Fetch user's listings with review counts and ratings
$stmt = $db->prepare("
    SELECT b.*, c.name as category_name,
           COALESCE(AVG(r.rating), 0) as avg_rating,
           COUNT(r.id) as review_count
    FROM businesses b
    JOIN categories c ON b.category_id = c.id
    LEFT JOIN reviews r ON r.business_id = b.id AND r.status = 'approved'
    WHERE b.user_id = ?
    GROUP BY b.id, c.name
    ORDER BY b.created_at DESC
");
$stmt->execute([$user['id']]);
$businesses = $stmt->fetchAll();

// Count stats
$totalMyBiz = count($businesses);
$pendingCount = 0;
$approvedCount = 0;
foreach ($businesses as $b) {
    if ($b['status'] === 'pending') $pendingCount++;
    if ($b['status'] === 'approved') $approvedCount++;
}

// Fetch user's review count
$revCountStmt = $db->prepare("SELECT COUNT(*) FROM reviews WHERE user_id = ?");
$revCountStmt->execute([$user['id']]);
$userReviewsCount = (int)$revCountStmt->fetchColumn();

$pageTitle = 'My Dashboard';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="bg-light border-bottom py-4 mb-4">
    <div class="container">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3">
            <div>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb small mb-1">
                        <li class="breadcrumb-item"><a href="/" class="text-decoration-none">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
                    </ol>
                </nav>
                <h1 class="h3 fw-bold mb-0">Welcome, <?= e($user['name']) ?></h1>
            </div>

            <div class="d-flex gap-2">
                <a href="/dashboard/business/add" class="btn btn-primary btn-sm d-flex align-items-center gap-1">
                    <i class="bi bi-plus-lg"></i> Add New Business
                </a>
            </div>
        </div>
    </div>
</div>

<div class="container mb-5">
    <?= flash_render() ?>

    <!-- Overview Metrics Cards -->
    <div class="row g-3 mb-4">
        <div class="col-sm-6 col-lg-3">
            <div class="card shadow-sm border-1 p-3">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <div class="text-muted small fw-semibold">My Listings</div>
                        <div class="fs-4 fw-bold text-dark"><?= $totalMyBiz ?></div>
                    </div>
                    <div class="fs-2 text-primary opacity-75">
                        <i class="bi bi-buildings"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm-6 col-lg-3">
            <div class="card shadow-sm border-1 p-3">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <div class="text-muted small fw-semibold">Active &amp; Approved</div>
                        <div class="fs-4 fw-bold text-success"><?= $approvedCount ?></div>
                    </div>
                    <div class="fs-2 text-success opacity-75">
                        <i class="bi bi-check-circle"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm-6 col-lg-3">
            <div class="card shadow-sm border-1 p-3">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <div class="text-muted small fw-semibold">Pending Review</div>
                        <div class="fs-4 fw-bold text-warning"><?= $pendingCount ?></div>
                    </div>
                    <div class="fs-2 text-warning opacity-75">
                        <i class="bi bi-hourglass-split"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-sm-6 col-lg-3">
            <div class="card shadow-sm border-1 p-3">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <div class="text-muted small fw-semibold">My Reviews Written</div>
                        <div class="fs-4 fw-bold text-dark"><?= $userReviewsCount ?></div>
                    </div>
                    <div class="fs-2 text-info opacity-75">
                        <i class="bi bi-chat-quote"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- My Businesses Section -->
    <div class="card shadow-sm border-1 mb-4">
        <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
            <h5 class="fw-bold mb-0">My Business Listings</h5>
            <a href="/dashboard/business/add" class="btn btn-outline-primary btn-sm">
                <i class="bi bi-plus-lg me-1"></i>New Listing
            </a>
        </div>

        <div class="card-body p-0">
            <?php if (!empty($businesses)): ?>
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-light">
                            <tr>
                                <th style="width: 70px;">Logo</th>
                                <th>Business Name</th>
                                <th>Category</th>
                                <th>Location</th>
                                <th>Status</th>
                                <th>Rating</th>
                                <th class="text-end">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($businesses as $b): ?>
                                <tr id="business-row-<?= (int)$b['id'] ?>">
                                    <td>
                                        <?php if (!empty($b['logo'])): ?>
                                            <img src="/uploads/businesses/<?= e($b['logo']) ?>" alt="" class="rounded" style="width: 44px; height: 44px; object-fit: cover;">
                                        <?php else: ?>
                                            <div class="rounded bg-light text-muted d-flex align-items-center justify-content-center fw-bold" style="width: 44px; height: 44px;">
                                                <?= strtoupper(substr($b['business_name'], 0, 2)) ?>
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <strong><?= e($b['business_name']) ?></strong>
                                        <div class="text-muted small">Added: <?= format_date($b['created_at']) ?></div>
                                    </td>
                                    <td>
                                        <span class="badge bg-light text-dark border"><?= e($b['category_name']) ?></span>
                                    </td>
                                    <td class="small">
                                        <?= !empty($b['country']) ? e($b['country']) : '—' ?>
                                    </td>
                                    <td>
                                        <?php
                                        $badgeClass = match($b['status']) {
                                            'approved'  => 'badge-status-approved',
                                            'pending'   => 'badge-status-pending',
                                            'rejected'  => 'badge-status-rejected',
                                            'suspended' => 'badge-status-suspended',
                                            default     => 'bg-secondary'
                                        };
                                        ?>
                                        <span class="badge <?= $badgeClass ?> px-2 py-1">
                                            <?= ucfirst(e($b['status'])) ?>
                                        </span>
                                    </td>
                                    <td class="small">
                                        <?= render_stars((float)$b['avg_rating'], false) ?>
                                        <span class="text-muted ms-1">(<?= (int)$b['review_count'] ?>)</span>
                                    </td>
                                    <td class="text-end">
                                        <div class="btn-group btn-group-sm">
                                            <a href="/business/<?= e($b['slug']) ?>" class="btn btn-outline-secondary" title="View Public Page">
                                                <i class="bi bi-eye"></i>
                                            </a>
                                            <a href="/dashboard/business/edit/<?= (int)$b['id'] ?>" class="btn btn-outline-primary" title="Edit Listing">
                                                <i class="bi bi-pencil"></i>
                                            </a>
                                            <button type="button" class="btn btn-outline-danger"
                                                    title="Delete Listing"
                                                    hx-post="/actions/business.php?action=delete&id=<?= (int)$b['id'] ?>"
                                                    hx-confirm="Are you sure you want to permanently delete '<?= e($b['business_name']) ?>'?"
                                                    hx-target="#business-row-<?= (int)$b['id'] ?>"
                                                    hx-swap="outerHTML">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="text-center p-5">
                    <i class="bi bi-buildings text-muted fs-1 mb-2 d-block"></i>
                    <h5 class="fw-bold">You haven't listed any businesses yet</h5>
                    <p class="text-muted small mb-3">Add your service or shop to reach potential local clients today.</p>
                    <a href="/dashboard/business/add" class="btn btn-primary btn-sm">
                        <i class="bi bi-plus-circle me-1"></i> Add Your First Listing
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
